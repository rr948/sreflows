# Staff SRE Troubleshooting Handbook

## Major design

This version is not a cluttered all-components diagram.

It uses:

- Left hierarchical menu: Domain → Area → Repeated Issue
- Focused diagram per selected issue
- Only required components in the diagram
- Active primary component and dependency lines
- Right-side README.md runbook rendering
- Search across repeated incidents
- Mobile-friendly responsive layout

## Run locally

Markdown files are loaded through `fetch()`, so use a local server:

```bash
cd staff-sre-troubleshooting-handbook
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Edit

- Tree and diagrams: `data/handbook.json`
- UI: `assets/css/base.css`
- Behavior: `assets/js/app.js`
- Runbooks: `content/<domain>/<scenario>/README.md`


## V2 Enhancements

- Each scenario now has a unique dependency graph.
- Parent hierarchy is visible in the diagram.
- Parent → child relationship chain added.
- Focus component positioned centrally.
- Supporting dependencies arranged dynamically.
- Active dependency paths glow visually.
- Better mental mapping for Staff SRE troubleshooting.


## V3 Enhancements

- Center diagram is now flexible instead of fixed-width/fixed-height positioned boxes.
- Diagram uses hierarchy grid layout: parent chain on top, focus in center, signals on right, causes/context around focus.
- Sidebar can collapse from the top Menu button.
- Unrelated diagram components are hidden instead of dimmed.
- SVG links are recalculated from actual DOM positions.
- Better parent → child → focus troubleshooting mental model.


## V4 Enhancements

- Added visual hierarchy boxes inside the diagram.
- Kubernetes scenarios now show nested containers such as:
  - Kubernetes Cluster
  - Namespace
  - Workload Controller
  - Pod / Container
  - Worker Node
  - Traffic Path
  - Service Discovery
  - Pod Network / CNI
  - Storage Layer
- Abstract parent nodes are no longer shown as cluttered boxes; parent hierarchy is shown as nested containers.
- Focus and related components appear inside the right hierarchy container.
- Unrelated components remain hidden.


## V5 Fixes

- Fixed broken diagram rendering from V4.
- Component cards are clickable again.
- Replaced fixed equal-size boxes with flexible nested hierarchy containers.
- Topic/component cards now have variable size:
  - focus cards are larger
  - related cards are medium
  - signal/context cards are smaller
- Diagrams render as clean nested boxes rather than cluttered absolute-position layouts.
- Links are recalculated from rendered card positions.


## V7 Repair

- Removed fragile SVG overlay from the main rendering path.
- Diagram now always renders using safe HTML hierarchy boxes.
- Cards are clickable.
- Numbered relationships are shown as reliable HTML flow arrows.
- Arrow meanings are shown in a numbered legend.
- This version prioritizes stable rendering and usability.
