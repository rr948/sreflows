const state = { data:null, selected:null, scale:1, openDomains:new Set(), openAreas:new Set(), query:"" };
const $ = id => document.getElementById(id);

async function init(){
  const res = await fetch("data/handbook.json");
  state.data = await res.json();
  renderStats();
  renderTree();
  wire();
}
function wire(){
  $("searchBox").addEventListener("input", e=>{state.query=e.target.value.toLowerCase().trim(); renderTree(); renderRelated();});
  $("sidebarToggle").onclick=()=>document.body.classList.toggle("sidebar-collapsed");
  $("collapseAllBtn").onclick=()=>{state.openDomains.clear(); state.openAreas.clear(); renderTree();};
  $("detailsBtn").onclick=()=>$("details").classList.toggle("open");
  $("closeDetails").onclick=()=>$("details").classList.remove("open");
  $("fitBtn").onclick=()=>setScale(.86);
  $("zoomInBtn").onclick=()=>setScale(state.scale+.1);
  $("zoomOutBtn").onclick=()=>setScale(Math.max(.55,state.scale-.1));
  $("resetBtn").onclick=()=>{ if(state.selected) selectScenario(state.selected.domainId,state.selected.areaId,state.selected.scenarioId,false); };
  $("showLabels").onchange=()=>{ if(state.selected) renderGraph(state.selected.scenario); };
}
function setScale(v){ state.scale=Number(v.toFixed(2)); $("stage").style.transform=`scale(${state.scale})`; }
function allScenarios(){
  return state.data.domains.flatMap(d=>d.areas.flatMap(a=>a.scenarios.map(s=>({domain:d,area:a,scenario:s}))));
}
function renderStats(){
  const domains=state.data.domains.length;
  const scenarios=allScenarios().length;
  const components=new Set(allScenarios().flatMap(x=>x.scenario.graph.nodes.map(n=>n.title))).size;
  $("domainCount").textContent=domains; $("scenarioCount").textContent=scenarios; $("componentCount").textContent=components;
}
function renderTree(){
  const q=state.query;
  $("tree").innerHTML = state.data.domains.map(d=>{
    const domainOpen = state.openDomains.has(d.id) || q;
    const areasHtml = d.areas.map(a=>{
      const matchingScenarios=a.scenarios.filter(s=>!q || `${d.title} ${a.title} ${s.title} ${s.summary}`.toLowerCase().includes(q));
      if(q && !matchingScenarios.length) return "";
      const areaKey=`${d.id}:${a.id}`;
      const areaOpen=state.openAreas.has(areaKey) || q;
      return `<div class="area ${areaOpen?'open':''}">
        <button class="area-btn ${isAreaSelected(d.id,a.id)?'active':''}" onclick="toggleArea('${d.id}','${a.id}')">
          <span><strong>${a.title}</strong><small>${matchingScenarios.length || a.scenarios.length} issues</small></span><span class="chev">›</span>
        </button>
        <div class="scenario-list">
          ${matchingScenarios.map(s=>`<button class="scenario-btn ${isSelected(s.id)?'active':''}" onclick="selectScenario('${d.id}','${a.id}','${s.id}',true)">
            ${s.title}
          </button>`).join("")}
        </div>
      </div>`;
    }).join("");
    if(q && !areasHtml.trim()) return "";
    return `<div class="tree-domain ${domainOpen?'open':''}">
      <button class="domain-btn ${isDomainSelected(d.id)?'active':''}" onclick="toggleDomain('${d.id}')">
        <span><strong>${d.title}</strong><span class="domain-meta">${d.areas.length} areas</span></span><span class="chev">›</span>
      </button>
      <div class="area-list">${areasHtml}</div>
    </div>`;
  }).join("");
}
function toggleDomain(id){ state.openDomains.has(id)?state.openDomains.delete(id):state.openDomains.add(id); renderTree(); }
function toggleArea(did,aid){ const k=`${did}:${aid}`; state.openAreas.has(k)?state.openAreas.delete(k):state.openAreas.add(k); state.openDomains.add(did); renderTree(); }
function findScenario(did,aid,sid){
  const d=state.data.domains.find(x=>x.id===did); const a=d.areas.find(x=>x.id===aid); const s=a.scenarios.find(x=>x.id===sid);
  return {domain:d,area:a,scenario:s};
}
function isSelected(sid){ return state.selected && state.selected.scenarioId===sid; }
function isDomainSelected(did){ return state.selected && state.selected.domainId===did; }
function isAreaSelected(did,aid){ return state.selected && state.selected.domainId===did && state.selected.areaId===aid; }

async function selectScenario(did,aid,sid,loadMd=true){
  const found=findScenario(did,aid,sid);
  state.selected={domainId:did,areaId:aid,scenarioId:sid, ...found};
  state.openDomains.add(did); state.openAreas.add(`${did}:${aid}`);
  $("emptyState").classList.add("hidden"); $("stage").classList.remove("hidden");
  $("crumb").textContent=`${found.domain.title} / ${found.area.title}`;
  $("pageTitle").textContent=found.scenario.title;
  $("pageSummary").textContent=found.scenario.summary;
  renderTree(); renderGraph(found.scenario); renderRelated();
  if(loadMd) await loadReadme(found.scenario.graph.readme, found.scenario.title);
}
function renderGraph(scenario){
  const graph=scenario.graph;
  const nodes=$("nodes"), links=$("links");
  nodes.innerHTML="";
  links.innerHTML="";
  nodes.className = "nodes safe-diagram-mode";

  const visibleIds = getVisibleIds(graph);
  const visibleNodes = graph.nodes.filter(n => visibleIds.has(n.id) && !n.id.startsWith("parent-"));
  const hierarchy = graph.hierarchyBoxes || [];

  const wrapper = document.createElement("div");
  wrapper.className = "safe-diagram";

  wrapper.appendChild(renderActivePath(graph, visibleNodes));

  const root = hierarchy.find(h => h.level === 0);
  const rootBox = document.createElement("div");
  rootBox.className = "safe-box root";
  rootBox.innerHTML = `<div class="safe-box-title">${root ? root.title : "Platform Hierarchy"}</div>`;

  const childGrid = document.createElement("div");
  childGrid.className = "safe-child-grid";

  const childBoxes = hierarchy.filter(h => h.level > 0);
  if(childBoxes.length){
    childBoxes.forEach(box => {
      if(!boxHasConnectedCards(box, hierarchy, visibleNodes)) return;
      childGrid.appendChild(renderSafeBox(box, hierarchy, visibleNodes, graph));
    });
  } else {
    const fallback = document.createElement("div");
    fallback.className = "safe-card-grid";
    visibleNodes.forEach(n => fallback.appendChild(renderSafeCard(n, graph)));
    childGrid.appendChild(fallback);
  }

  rootBox.appendChild(childGrid);
  wrapper.appendChild(rootBox);
  nodes.appendChild(wrapper);

  requestAnimationFrame(() => {
    renderInDiagramArrows(graph, visibleNodes);

    // Remove empty hierarchy containers that survived recursion.
    document.querySelectorAll(".safe-box").forEach(box => {
      const hasCards = box.querySelector(".safe-card");
      const nestedBoxes = box.querySelectorAll(":scope > .safe-nested-grid > .safe-box, :scope > .safe-child-grid > .safe-box");

      // keep root always
      if(box.classList.contains("root")) return;

      if(!hasCards && nestedBoxes.length === 0){
        box.remove();
      }
    });
  });
}

function getVisibleIds(graph){
  // Show only boxes/cards that are connected by arrows.
  // Rule:
  // 1. Keep direct focus relationships.
  // 2. Keep validation relationships to symptom, recent-change, metrics, logs/events only if connected.
  // 3. Do not render isolated/context-only cards.
  const ids = new Set();
  graph.links.forEach(([a,b])=>{
    if(a.startsWith("parent-") || b.startsWith("parent-")) return;

    const directlyUseful =
      a === "focus" || b === "focus" ||
      a === "symptom" || b === "symptom" ||
      a === "recent-change" || b === "recent-change" ||
      a === "metrics" || b === "metrics" ||
      a === "logs-events" || b === "logs-events";

    if(directlyUseful){
      ids.add(a);
      ids.add(b);
    }
  });

  // Always keep focus if present, but only because every scenario should connect arrows to it.
  if(graph.nodes.some(n => n.id === "focus")) ids.add("focus");
  return ids;
}

function hasVisibleDescendant(box, hierarchy, visibleNodes){
  const descendants = hierarchy.filter(h => h.level > box.level);
  const visibleContainers = new Set(visibleNodes.map(n => n.container));
  return descendants.some(d => visibleContainers.has(d.id));
}

function boxHasConnectedCards(box, hierarchy, visibleNodes){
  // Show ONLY boxes that actually participate in connected relationships.
  const visibleContainers = new Set(visibleNodes.map(n => n.container));

  // Direct cards inside this box
  if(visibleContainers.has(box.id)) return true;

  // Only recurse into direct children, not all descendants.
  const directChildren = hierarchy.filter(
    h => h.level === box.level + 1
  );

  return directChildren.some(child => boxHasConnectedCards(child, hierarchy, visibleNodes));
}

function renderSafeBox(box, hierarchy, visibleNodes, graph){
  if(!boxHasConnectedCards(box, hierarchy, visibleNodes)){
    const empty = document.createElement("template");
    return empty.content;
  }
  const el = document.createElement("div");
  el.className = `safe-box level-${box.level} box-${box.class || "default"}`;
  el.innerHTML = `<div class="safe-box-title">${box.title}</div>`;

  const direct = visibleNodes.filter(n => n.container === box.id);
  const directWrap = document.createElement("div");
  directWrap.className = "safe-card-grid";
  direct.forEach(n => directWrap.appendChild(renderSafeCard(n, graph)));
  el.appendChild(directWrap);

  const childBoxes = hierarchy
    .filter(h => h.level === box.level + 1)
    .filter(h => boxHasConnectedCards(h, hierarchy, visibleNodes));

  if(childBoxes.length){
    const nested = document.createElement("div");
    nested.className = "safe-nested-grid";
    childBoxes.forEach(child => nested.appendChild(renderSafeBox(child, hierarchy, visibleNodes, graph)));
    el.appendChild(nested);
  }

  return el;
}

function renderSafeCard(n, graph){
  const btn = document.createElement("button");
  const role = n.id === "focus" ? "primary" :
    isConnectedToFocus(graph,n.id) ? "related" :
    ["symptom","recent-change","metrics","logs-events"].includes(n.id) ? "signal" : "context";

  btn.className = `safe-card ${role} type-${n.type || "platform"}`;
  btn.dataset.id = n.id;
  const labels = $("showLabels").checked;
  btn.innerHTML = `
    <span class="safe-chip">${n.type || "component"}</span>
    <strong>${n.title}</strong>
    ${labels ? `<p>${n.summary || ""}</p>` : ""}
  `;
  btn.onclick = () => {
    document.querySelectorAll(".safe-card").forEach(c => c.classList.remove("clicked"));
    btn.classList.add("clicked");
    loadReadme(state.selected.scenario.graph.readme,state.selected.scenario.title);
  };
  return btn;
}

function renderActivePath(graph, visibleNodes){
  const box = document.createElement("div");
  box.className = "active-path";

  const byId = Object.fromEntries(graph.nodes.map(n => [n.id, n]));
  const pairs = graph.links
    .filter(([a,b]) => visibleNodes.some(n => n.id===a) && visibleNodes.some(n => n.id===b))
    .filter(([a,b]) => a==="focus" || b==="focus" || a==="symptom" || b==="symptom")
    .slice(0,5);

  box.innerHTML = `
    <div class="active-path-head">
      <span class="badge">Focused dependency path</span>
      <small>${pairs.length} key relationships</small>
    </div>
    <div class="path-row">
      ${pairs.map(([a,b],idx) => `
        <div class="path-step">
          <span class="path-num">${idx+1}</span>
          <div class="path-card"><strong>${byId[a]?.title || a}</strong><small>source</small></div>
          <div class="path-arrow">→</div>
          <div class="path-card target"><strong>${byId[b]?.title || b}</strong><small>target</small></div>
        </div>
      `).join("")}
    </div>
  `;
  return box;
}

function renderArrowLegendHtml(graph, visibleNodes){
  const visible = new Set(visibleNodes.map(n => n.id));
  const byId = Object.fromEntries(graph.nodes.map(n => [n.id, n]));
  const rows = [];
  let step = 1;

  graph.links.forEach(([a,b])=>{
    if(!visible.has(a) || !visible.has(b)) return;
    rows.push(linkDescriptionHtml(byId, a, b, step));
    step++;
  });

  const legend = document.createElement("section");
  legend.className = "safe-arrow-legend";
  legend.innerHTML = `
    <div class="safe-legend-head">
      <div><span class="badge">Numbered arrows</span><h2>What each relationship means</h2></div>
      <small>${rows.length} relationships</small>
    </div>
    <div class="safe-legend-grid">
      ${rows.map(r => `
        <div class="safe-legend-row">
          <span class="safe-step">${r.step}</span>
          <div>
            <strong>${r.short}</strong>
            <p>${r.detail}</p>
          </div>
        </div>
      `).join("")}
    </div>
  `;
  return legend;
}

function linkDescriptionHtml(byId, from, to, step){
  const a = byId[from]?.title || from;
  const b = byId[to]?.title || to;
  let short = `${a} → ${b}`;
  let detail = `Step ${step}: ${a} influences, validates, or depends on ${b}.`;

  if(from === "symptom" || to === "symptom"){
    short = "Symptom points to suspected layer";
    detail = `Step ${step}: Start from the symptom and map it to the suspected failing component.`;
  } else if(from === "recent-change" || to === "recent-change"){
    short = "Recent change correlation";
    detail = `Step ${step}: Check whether deployment, config, IAM, certificate, network, or infra change caused the failure.`;
  } else if(from === "metrics" || to === "metrics"){
    short = "Validate with metrics";
    detail = `Step ${step}: Confirm impact using latency, errors, traffic, saturation, or SLO metrics.`;
  } else if(from === "logs-events" || to === "logs-events"){
    short = "Validate with logs/events";
    detail = `Step ${step}: Use logs, events, audit trails, or pipeline logs to prove the root cause.`;
  } else if(from === "focus" || to === "focus"){
    short = `Direct focus dependency: ${a} ↔ ${b}`;
    detail = `Step ${step}: Inspect this direct dependency before expanding the investigation.`;
  }
  return {step, short, detail};
}


function renderInDiagramArrows(graph, visibleNodes){
  const svg = $("links");
  svg.innerHTML = `<defs>
    <marker id="arrowHead" viewBox="0 0 12 12" refX="10" refY="6" markerWidth="8" markerHeight="8" orient="auto">
      <path d="M 1 1 L 11 6 L 1 11 z" fill="#38bdf8"></path>
    </marker>
    <filter id="arrowGlow">
      <feGaussianBlur stdDeviation="3.2" result="blur"/>
      <feMerge>
        <feMergeNode in="blur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>`;

  const visible = {};
  document.querySelectorAll(".safe-card").forEach(el => visible[el.dataset.id] = el);

  const visibleSet = new Set(visibleNodes.map(n => n.id));
  let step = 1;

  graph.links.forEach(([a,b]) => {
    if(!visibleSet.has(a) || !visibleSet.has(b)) return;
    if(!visible[a] || !visible[b]) return;

    const cls = (a === "focus" || b === "focus") ? "active" :
      (isConnectedToFocus(graph,a) || isConnectedToFocus(graph,b)) ? "related" : "context";

    drawArrow(visible[a], visible[b], cls, step);
    step++;
  });
}

function drawArrow(fromEl, toEl, cls, step){
  const svg = $("links");
  const shell = document.querySelector(".focus-shell").getBoundingClientRect();
  const a = fromEl.getBoundingClientRect();
  const b = toEl.getBoundingClientRect();

  const x1 = a.left - shell.left + a.width / 2;
  const y1 = a.top - shell.top + a.height / 2;
  const x2 = b.left - shell.left + b.width / 2;
  const y2 = b.top - shell.top + b.height / 2;

  const dx = x2 - x1;
  const dy = y2 - y1;
  const curve = Math.max(36, Math.min(140, Math.abs(dx) * 0.35 + Math.abs(dy) * 0.15));

  let d;
  if(Math.abs(dx) >= Math.abs(dy)){
    const c1x = x1 + Math.sign(dx || 1) * curve;
    const c2x = x2 - Math.sign(dx || 1) * curve;
    d = `M ${x1} ${y1} C ${c1x} ${y1}, ${c2x} ${y2}, ${x2} ${y2}`;
  } else {
    const c1y = y1 + Math.sign(dy || 1) * curve;
    const c2y = y2 - Math.sign(dy || 1) * curve;
    d = `M ${x1} ${y1} C ${x1} ${c1y}, ${x2} ${c2y}, ${x2} ${y2}`;
  }

  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", d);
  path.setAttribute("class", `diagram-arrow ${cls}`);
  path.setAttribute("marker-end", "url(#arrowHead)");
  if(cls === "active") path.setAttribute("filter", "url(#arrowGlow)");
  svg.appendChild(path);

  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;

  const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
  g.setAttribute("class", `diagram-arrow-num ${cls}`);
  g.setAttribute("transform", `translate(${mx},${my})`);

  const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
  circle.setAttribute("r", "13");

  const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
  text.setAttribute("text-anchor", "middle");
  text.setAttribute("dominant-baseline", "central");
  text.textContent = step;

  g.appendChild(circle);
  g.appendChild(text);
  svg.appendChild(g);
}

function isConnectedToFocus(graph,id){ return graph.links.some(([a,b])=>(a==="focus"&&b===id)||(b==="focus"&&a===id)); }
function addGroup(x,y,w,h,title){
  const el=document.createElement("div"); el.className="cluster-title";
  el.style.left=x+"px"; el.style.top=y+"px"; el.style.width=w+"px"; el.style.height=h+"px";
  el.innerHTML=`<span>${title}</span>`; $("nodes").appendChild(el);
}
function addDomLink(aEl,bEl,cls){
  const svg=$("links");
  const stage=$("stage").getBoundingClientRect();
  const a=aEl.getBoundingClientRect();
  const b=bEl.getBoundingClientRect();

  const x1=a.left-stage.left+a.width/2;
  const y1=a.top-stage.top+a.height/2;
  const x2=b.left-stage.left+b.width/2;
  const y2=b.top-stage.top+b.height/2;

  const dx = Math.abs(x2-x1);
  const dy = Math.abs(y2-y1);
  const horizontal = dx >= dy;

  let d;
  if(horizontal){
    const mid=Math.max(40,dx/2);
    d=`M ${x1} ${y1} C ${x1+mid} ${y1}, ${x2-mid} ${y2}, ${x2} ${y2}`;
  } else {
    const mid=Math.max(34,dy/2);
    d=`M ${x1} ${y1} C ${x1} ${y1+mid}, ${x2} ${y2-mid}, ${x2} ${y2}`;
  }

  const path=document.createElementNS("http://www.w3.org/2000/svg","path");
  path.setAttribute("d",d);
  path.setAttribute("marker-end","url(#arrow)");
  path.setAttribute("class",`link ${cls}`);
  svg.appendChild(path);
}

async function loadReadme(path,title){
  $("details").classList.add("open");
  $("readmeBadge").textContent=path; $("readmeTitle").textContent=title;
  $("markdown").innerHTML=`<p>Loading <code>${path}</code>...</p>`;
  try{
    const res=await fetch(path); if(!res.ok) throw new Error("missing");
    $("markdown").innerHTML=mdToHtml(await res.text());
  }catch(e){ $("markdown").innerHTML=`<h1>${title}</h1><p>README not found: <code>${path}</code></p>`; }
}
function renderRelated(){
  const q=state.query;
  let items = allScenarios();
  if(state.selected) items = items.filter(x=>x.domain.id===state.selected.domainId && x.scenario.id!==state.selected.scenarioId);
  if(q) items = items.filter(x=>`${x.domain.title} ${x.area.title} ${x.scenario.title} ${x.scenario.summary}`.toLowerCase().includes(q));
  $("relatedScenarios").innerHTML = items.slice(0,8).map(x=>`<div class="scenario-card" onclick="selectScenario('${x.domain.id}','${x.area.id}','${x.scenario.id}',true)">
    <span class="badge">${x.domain.title}</span><h3>${x.scenario.title}</h3><p>${x.scenario.summary}</p>
  </div>`).join("");
}
function mdToHtml(md){
  let html=md.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  html=html.replace(/```([\s\S]*?)```/g,(_,c)=>`<pre><code>${c.trim()}</code></pre>`);
  html=html.replace(/^### (.*)$/gm,"<h3>$1</h3>").replace(/^## (.*)$/gm,"<h2>$1</h2>").replace(/^# (.*)$/gm,"<h1>$1</h1>");
  html=html.replace(/`([^`]+)`/g,"<code>$1</code>");
  html=html.replace(/^- (.*)$/gm,"<li>$1</li>").replace(/(<li>.*<\/li>\n?)+/g,m=>`<ul>${m}</ul>`);
  html=html.replace(/\n\n/g,"</p><p>");
  return `<p>${html}</p>`.replace(/<p><h/g,"<h").replace(/<\/h([123])><\/p>/g,"</h$1>");
}

window.addEventListener("resize", ()=>{
  if(state.selected) renderGraph(state.selected.scenario);
});
document.querySelector(".focus-shell")?.addEventListener("scroll", ()=>{
  if(state.selected) {
    const graph = state.selected.scenario.graph;
    const visibleIds = getVisibleIds(graph);
    const visibleNodes = graph.nodes.filter(n => visibleIds.has(n.id) && !n.id.startsWith("parent-"));
    renderInDiagramArrows(graph, visibleNodes);
  }
});
init();

