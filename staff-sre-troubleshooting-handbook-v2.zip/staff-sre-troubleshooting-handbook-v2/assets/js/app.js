const state = { data:null, selected:null, scale:1, openDomains:new Set(), openAreas:new Set(), query:"" };
const $ = id => document.getElementById(id);

async function init(){
  const res = await fetch("data/handbook.json");
  state.data = await res.json();
  renderStats();
  renderTree();
  wire();
}
function wire(){
  $("searchBox").addEventListener("input", e=>{state.query=e.target.value.toLowerCase().trim(); renderTree(); renderRelated();});
  $("collapseAllBtn").onclick=()=>{state.openDomains.clear(); state.openAreas.clear(); renderTree();};
  $("detailsBtn").onclick=()=>$("details").classList.toggle("open");
  $("closeDetails").onclick=()=>$("details").classList.remove("open");
  $("fitBtn").onclick=()=>setScale(.86);
  $("zoomInBtn").onclick=()=>setScale(state.scale+.1);
  $("zoomOutBtn").onclick=()=>setScale(Math.max(.55,state.scale-.1));
  $("resetBtn").onclick=()=>{ if(state.selected) selectScenario(state.selected.domainId,state.selected.areaId,state.selected.scenarioId,false); };
  $("showLabels").onchange=()=>{ if(state.selected) renderGraph(state.selected.scenario); };
}
function setScale(v){ state.scale=Number(v.toFixed(2)); $("stage").style.transform=`scale(${state.scale})`; }
function allScenarios(){
  return state.data.domains.flatMap(d=>d.areas.flatMap(a=>a.scenarios.map(s=>({domain:d,area:a,scenario:s}))));
}
function renderStats(){
  const domains=state.data.domains.length;
  const scenarios=allScenarios().length;
  const components=new Set(allScenarios().flatMap(x=>x.scenario.graph.nodes.map(n=>n.title))).size;
  $("domainCount").textContent=domains; $("scenarioCount").textContent=scenarios; $("componentCount").textContent=components;
}
function renderTree(){
  const q=state.query;
  $("tree").innerHTML = state.data.domains.map(d=>{
    const domainOpen = state.openDomains.has(d.id) || q;
    const areasHtml = d.areas.map(a=>{
      const matchingScenarios=a.scenarios.filter(s=>!q || `${d.title} ${a.title} ${s.title} ${s.summary}`.toLowerCase().includes(q));
      if(q && !matchingScenarios.length) return "";
      const areaKey=`${d.id}:${a.id}`;
      const areaOpen=state.openAreas.has(areaKey) || q;
      return `<div class="area ${areaOpen?'open':''}">
        <button class="area-btn ${isAreaSelected(d.id,a.id)?'active':''}" onclick="toggleArea('${d.id}','${a.id}')">
          <span><strong>${a.title}</strong><small>${matchingScenarios.length || a.scenarios.length} issues</small></span><span class="chev">›</span>
        </button>
        <div class="scenario-list">
          ${matchingScenarios.map(s=>`<button class="scenario-btn ${isSelected(s.id)?'active':''}" onclick="selectScenario('${d.id}','${a.id}','${s.id}',true)">
            ${s.title}
          </button>`).join("")}
        </div>
      </div>`;
    }).join("");
    if(q && !areasHtml.trim()) return "";
    return `<div class="tree-domain ${domainOpen?'open':''}">
      <button class="domain-btn ${isDomainSelected(d.id)?'active':''}" onclick="toggleDomain('${d.id}')">
        <span><strong>${d.title}</strong><span class="domain-meta">${d.areas.length} areas</span></span><span class="chev">›</span>
      </button>
      <div class="area-list">${areasHtml}</div>
    </div>`;
  }).join("");
}
function toggleDomain(id){ state.openDomains.has(id)?state.openDomains.delete(id):state.openDomains.add(id); renderTree(); }
function toggleArea(did,aid){ const k=`${did}:${aid}`; state.openAreas.has(k)?state.openAreas.delete(k):state.openAreas.add(k); state.openDomains.add(did); renderTree(); }
function findScenario(did,aid,sid){
  const d=state.data.domains.find(x=>x.id===did); const a=d.areas.find(x=>x.id===aid); const s=a.scenarios.find(x=>x.id===sid);
  return {domain:d,area:a,scenario:s};
}
function isSelected(sid){ return state.selected && state.selected.scenarioId===sid; }
function isDomainSelected(did){ return state.selected && state.selected.domainId===did; }
function isAreaSelected(did,aid){ return state.selected && state.selected.domainId===did && state.selected.areaId===aid; }

async function selectScenario(did,aid,sid,loadMd=true){
  const found=findScenario(did,aid,sid);
  state.selected={domainId:did,areaId:aid,scenarioId:sid, ...found};
  state.openDomains.add(did); state.openAreas.add(`${did}:${aid}`);
  $("emptyState").classList.add("hidden"); $("stage").classList.remove("hidden");
  $("crumb").textContent=`${found.domain.title} / ${found.area.title}`;
  $("pageTitle").textContent=found.scenario.title;
  $("pageSummary").textContent=found.scenario.summary;
  renderTree(); renderGraph(found.scenario); renderRelated();
  if(loadMd) await loadReadme(found.scenario.graph.readme, found.scenario.title);
}
function renderGraph(scenario){
  const graph=scenario.graph;
  const nodes=$("nodes"), links=$("links");
  nodes.innerHTML=""; links.innerHTML=`<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="rgba(148,163,184,.78)"></path></marker></defs>`;
  addGroup(40,40,1040,560,scenario.title+" dependency hierarchy");
  const byId=Object.fromEntries(graph.nodes.map(n=>[n.id,n]));
  graph.nodes.forEach(n=>addNode(n, n.id==="focus"?"primary": isConnectedToFocus(graph,n.id)?"related":"context"));
  graph.links.forEach(([a,b])=>{
    if(!byId[a]||!byId[b]) return;
    let cls = "context";
    if(a.startsWith("parent-") || b.startsWith("parent-")) cls="related";
    if(a==="focus"||b==="focus") cls="active";
    else if(isConnectedToFocus(graph,a)||isConnectedToFocus(graph,b)) cls="related";
    addLink(byId[a],byId[b],cls);
  });
}
function isConnectedToFocus(graph,id){ return graph.links.some(([a,b])=>(a==="focus"&&b===id)||(b==="focus"&&a===id)); }
function addGroup(x,y,w,h,title){
  const el=document.createElement("div"); el.className="cluster-title";
  el.style.left=x+"px"; el.style.top=y+"px"; el.style.width=w+"px"; el.style.height=h+"px";
  el.innerHTML=`<span>${title}</span>`; $("nodes").appendChild(el);
}
function addNode(n,cls){
  const el=document.createElement("div"); el.className=`node ${cls}`; el.style.left=n.x+"px"; el.style.top=n.y+"px"; el.style.width=(n.w||180)+"px"; el.style.height=(n.h||88)+"px";
  const labels=$("showLabels").checked;
  el.innerHTML=`<span class="chip ${n.type}">${n.type}</span><h3>${n.title}</h3>${labels?`<p>${n.summary}</p>`:""}`;
  el.onclick=()=>loadReadme(state.selected.scenario.graph.readme,state.selected.scenario.title);
  $("nodes").appendChild(el);
}
function addLink(a,b,cls){
  const x1=a.x+(a.w||180), y1=a.y+(a.h||88)/2, x2=b.x, y2=b.y+(b.h||88)/2;
  const mid=Math.max(45,Math.abs(x2-x1)/2);
  const path=document.createElementNS("http://www.w3.org/2000/svg","path");
  path.setAttribute("d",`M ${x1} ${y1} C ${x1+mid} ${y1}, ${x2-mid} ${y2}, ${x2} ${y2}`);
  path.setAttribute("marker-end","url(#arrow)");
  path.setAttribute("class",`link ${cls}`);
  $("links").appendChild(path);
}
async function loadReadme(path,title){
  $("details").classList.add("open");
  $("readmeBadge").textContent=path; $("readmeTitle").textContent=title;
  $("markdown").innerHTML=`<p>Loading <code>${path}</code>...</p>`;
  try{
    const res=await fetch(path); if(!res.ok) throw new Error("missing");
    $("markdown").innerHTML=mdToHtml(await res.text());
  }catch(e){ $("markdown").innerHTML=`<h1>${title}</h1><p>README not found: <code>${path}</code></p>`; }
}
function renderRelated(){
  const q=state.query;
  let items = allScenarios();
  if(state.selected) items = items.filter(x=>x.domain.id===state.selected.domainId && x.scenario.id!==state.selected.scenarioId);
  if(q) items = items.filter(x=>`${x.domain.title} ${x.area.title} ${x.scenario.title} ${x.scenario.summary}`.toLowerCase().includes(q));
  $("relatedScenarios").innerHTML = items.slice(0,8).map(x=>`<div class="scenario-card" onclick="selectScenario('${x.domain.id}','${x.area.id}','${x.scenario.id}',true)">
    <span class="badge">${x.domain.title}</span><h3>${x.scenario.title}</h3><p>${x.scenario.summary}</p>
  </div>`).join("");
}
function mdToHtml(md){
  let html=md.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  html=html.replace(/```([\s\S]*?)```/g,(_,c)=>`<pre><code>${c.trim()}</code></pre>`);
  html=html.replace(/^### (.*)$/gm,"<h3>$1</h3>").replace(/^## (.*)$/gm,"<h2>$1</h2>").replace(/^# (.*)$/gm,"<h1>$1</h1>");
  html=html.replace(/`([^`]+)`/g,"<code>$1</code>");
  html=html.replace(/^- (.*)$/gm,"<li>$1</li>").replace(/(<li>.*<\/li>\n?)+/g,m=>`<ul>${m}</ul>`);
  html=html.replace(/\n\n/g,"</p><p>");
  return `<p>${html}</p>`.replace(/<p><h/g,"<h").replace(/<\/h([123])><\/p>/g,"</h$1>");
}
init();
