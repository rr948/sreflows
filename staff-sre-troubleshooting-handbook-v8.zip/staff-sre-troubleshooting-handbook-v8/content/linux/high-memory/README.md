# High Memory / OOM

## Purpose

This runbook covers **High Memory / OOM** under **Linux / Host issues**.

## Symptom

Memory pressure and OOM killer.

## Fast triage

1. Confirm blast radius: one pod/host/pipeline/account, one AZ/zone, or global.
2. Check recent changes: deployment, config, cert, IAM, route, autoscaling, secrets.
3. Follow the diagram from **Symptom → Focus Component → Metrics/Logs/Events**.
4. Mitigate first if user impact is high.
5. Preserve evidence for postmortem.

## Handy commands

```bash
uptime
top -H
ps -eo pid,ppid,stat,pcpu,pmem,cmd --sort=-pcpu | head
free -m
vmstat 1
df -h
df -i
ss -tulpen
journalctl -xe
```

## Root cause checklist

- Configuration mismatch
- Resource saturation
- Dependency outage
- IAM/RBAC/policy denial
- Network/DNS/TLS path failure
- Bad rollout or incompatible version
- Capacity or quota limit
- Missing observability or wrong alert threshold

## Staff SRE prevention

- Add SLO or burn-rate alert if user-facing.
- Add dashboard for the exact failure mode.
- Add safe rollback or automated mitigation.
- Add policy guardrail where humans repeatedly make mistakes.
- Add runbook ownership, escalation and test/gameday schedule.

## Interview answer structure

Use this order:

```text
Impact → scope → signals → layer isolation → commands → root cause → mitigation → prevention → platform improvement
```


## Diagram arrow descriptions

1. **Direct focus dependency**: Inspect **Dependency** because it directly affects the focus component.
2. **Direct focus dependency**: Inspect **Config / Policy** because it directly affects the focus component.
3. **Direct focus dependency**: Inspect **Owner / Runbook** because it directly affects the focus component.
4. **Symptom → suspected layer**: Start from the observed symptom and map it to **High Memory / OOM**.
5. **Recent change correlation**: Check whether deployment, config, IAM, certificate, network, or infra change relates to **High Memory / OOM**.
6. **Metrics validation**: Use latency, errors, traffic, saturation, or SLO metrics to validate **High Memory / OOM**.
7. **Logs/events validation**: Use logs, events, audit trails, or pipeline logs to prove behavior around **High Memory / OOM**.
8. **Direct focus dependency**: Inspect **Dependency** because it directly affects the focus component.
9. **Dependency → Config / Policy**: This relationship shows dependency, validation, or control flow between these components.
10. **Config / Policy → Owner / Runbook**: This relationship shows dependency, validation, or control flow between these components.
