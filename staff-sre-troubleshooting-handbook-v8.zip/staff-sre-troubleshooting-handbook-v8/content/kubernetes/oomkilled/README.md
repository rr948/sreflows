# OOMKilled / Memory Pressure

## Purpose

This runbook covers **OOMKilled / Memory Pressure** under **Kubernetes / Nodes / Capacity**.

## Symptom

Workload killed due to memory pressure.

## Fast triage

1. Confirm blast radius: one pod/host/pipeline/account, one AZ/zone, or global.
2. Check recent changes: deployment, config, cert, IAM, route, autoscaling, secrets.
3. Follow the diagram from **Symptom → Focus Component → Metrics/Logs/Events**.
4. Mitigate first if user impact is high.
5. Preserve evidence for postmortem.

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
kubectl get svc,ep,endpointslice -A
kubectl describe node <node>
```

## Root cause checklist

- Configuration mismatch
- Resource saturation
- Dependency outage
- IAM/RBAC/policy denial
- Network/DNS/TLS path failure
- Bad rollout or incompatible version
- Capacity or quota limit
- Missing observability or wrong alert threshold

## Staff SRE prevention

- Add SLO or burn-rate alert if user-facing.
- Add dashboard for the exact failure mode.
- Add safe rollback or automated mitigation.
- Add policy guardrail where humans repeatedly make mistakes.
- Add runbook ownership, escalation and test/gameday schedule.

## Interview answer structure

Use this order:

```text
Impact → scope → signals → layer isolation → commands → root cause → mitigation → prevention → platform improvement
```


## Diagram arrow descriptions

1. **Direct focus dependency**: Inspect **Memory Limit** because it directly affects the focus component.
2. **Direct focus dependency**: Inspect **Node Memory** because it directly affects the focus component.
3. **Direct focus dependency**: Inspect **OOM Killer** because it directly affects the focus component.
4. **Symptom → suspected layer**: Start from the observed symptom and map it to **Pod Memory**.
5. **Recent change correlation**: Check whether deployment, config, IAM, certificate, network, or infra change relates to **Pod Memory**.
6. **Metrics validation**: Use latency, errors, traffic, saturation, or SLO metrics to validate **Pod Memory**.
7. **Logs/events validation**: Use logs, events, audit trails, or pipeline logs to prove behavior around **Pod Memory**.
8. **Direct focus dependency**: Inspect **Memory Limit** because it directly affects the focus component.
9. **Memory Limit → Node Memory**: This relationship shows dependency, validation, or control flow between these components.
10. **Node Memory → OOM Killer**: This relationship shows dependency, validation, or control flow between these components.
