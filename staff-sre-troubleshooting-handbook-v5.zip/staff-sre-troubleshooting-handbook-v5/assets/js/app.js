const state = { data:null, selected:null, scale:1, openDomains:new Set(), openAreas:new Set(), query:"" };
const $ = id => document.getElementById(id);

async function init(){
  const res = await fetch("data/handbook.json");
  state.data = await res.json();
  renderStats();
  renderTree();
  wire();
}
function wire(){
  $("searchBox").addEventListener("input", e=>{state.query=e.target.value.toLowerCase().trim(); renderTree(); renderRelated();});
  $("sidebarToggle").onclick=()=>document.body.classList.toggle("sidebar-collapsed");
  $("collapseAllBtn").onclick=()=>{state.openDomains.clear(); state.openAreas.clear(); renderTree();};
  $("detailsBtn").onclick=()=>$("details").classList.toggle("open");
  $("closeDetails").onclick=()=>$("details").classList.remove("open");
  $("fitBtn").onclick=()=>setScale(.86);
  $("zoomInBtn").onclick=()=>setScale(state.scale+.1);
  $("zoomOutBtn").onclick=()=>setScale(Math.max(.55,state.scale-.1));
  $("resetBtn").onclick=()=>{ if(state.selected) selectScenario(state.selected.domainId,state.selected.areaId,state.selected.scenarioId,false); };
  $("showLabels").onchange=()=>{ if(state.selected) renderGraph(state.selected.scenario); };
}
function setScale(v){ state.scale=Number(v.toFixed(2)); $("stage").style.transform=`scale(${state.scale})`; }
function allScenarios(){
  return state.data.domains.flatMap(d=>d.areas.flatMap(a=>a.scenarios.map(s=>({domain:d,area:a,scenario:s}))));
}
function renderStats(){
  const domains=state.data.domains.length;
  const scenarios=allScenarios().length;
  const components=new Set(allScenarios().flatMap(x=>x.scenario.graph.nodes.map(n=>n.title))).size;
  $("domainCount").textContent=domains; $("scenarioCount").textContent=scenarios; $("componentCount").textContent=components;
}
function renderTree(){
  const q=state.query;
  $("tree").innerHTML = state.data.domains.map(d=>{
    const domainOpen = state.openDomains.has(d.id) || q;
    const areasHtml = d.areas.map(a=>{
      const matchingScenarios=a.scenarios.filter(s=>!q || `${d.title} ${a.title} ${s.title} ${s.summary}`.toLowerCase().includes(q));
      if(q && !matchingScenarios.length) return "";
      const areaKey=`${d.id}:${a.id}`;
      const areaOpen=state.openAreas.has(areaKey) || q;
      return `<div class="area ${areaOpen?'open':''}">
        <button class="area-btn ${isAreaSelected(d.id,a.id)?'active':''}" onclick="toggleArea('${d.id}','${a.id}')">
          <span><strong>${a.title}</strong><small>${matchingScenarios.length || a.scenarios.length} issues</small></span><span class="chev">›</span>
        </button>
        <div class="scenario-list">
          ${matchingScenarios.map(s=>`<button class="scenario-btn ${isSelected(s.id)?'active':''}" onclick="selectScenario('${d.id}','${a.id}','${s.id}',true)">
            ${s.title}
          </button>`).join("")}
        </div>
      </div>`;
    }).join("");
    if(q && !areasHtml.trim()) return "";
    return `<div class="tree-domain ${domainOpen?'open':''}">
      <button class="domain-btn ${isDomainSelected(d.id)?'active':''}" onclick="toggleDomain('${d.id}')">
        <span><strong>${d.title}</strong><span class="domain-meta">${d.areas.length} areas</span></span><span class="chev">›</span>
      </button>
      <div class="area-list">${areasHtml}</div>
    </div>`;
  }).join("");
}
function toggleDomain(id){ state.openDomains.has(id)?state.openDomains.delete(id):state.openDomains.add(id); renderTree(); }
function toggleArea(did,aid){ const k=`${did}:${aid}`; state.openAreas.has(k)?state.openAreas.delete(k):state.openAreas.add(k); state.openDomains.add(did); renderTree(); }
function findScenario(did,aid,sid){
  const d=state.data.domains.find(x=>x.id===did); const a=d.areas.find(x=>x.id===aid); const s=a.scenarios.find(x=>x.id===sid);
  return {domain:d,area:a,scenario:s};
}
function isSelected(sid){ return state.selected && state.selected.scenarioId===sid; }
function isDomainSelected(did){ return state.selected && state.selected.domainId===did; }
function isAreaSelected(did,aid){ return state.selected && state.selected.domainId===did && state.selected.areaId===aid; }

async function selectScenario(did,aid,sid,loadMd=true){
  const found=findScenario(did,aid,sid);
  state.selected={domainId:did,areaId:aid,scenarioId:sid, ...found};
  state.openDomains.add(did); state.openAreas.add(`${did}:${aid}`);
  $("emptyState").classList.add("hidden"); $("stage").classList.remove("hidden");
  $("crumb").textContent=`${found.domain.title} / ${found.area.title}`;
  $("pageTitle").textContent=found.scenario.title;
  $("pageSummary").textContent=found.scenario.summary;
  renderTree(); renderGraph(found.scenario); renderRelated();
  if(loadMd) await loadReadme(found.scenario.graph.readme, found.scenario.title);
}
function renderGraph(scenario){
  const graph=scenario.graph;
  const nodes=$("nodes"), links=$("links");
  nodes.innerHTML="";
  links.innerHTML="";

  nodes.classList.add("hierarchy-mode");

  const visibleIds = getVisibleIds(graph);
  const containerMap = buildContainerMap(graph, visibleIds);

  const rootBoxes = (graph.hierarchyBoxes || []).filter(b => b.level === 0);
  if(rootBoxes.length){
    rootBoxes.forEach(box => nodes.appendChild(renderBox(box, graph, containerMap, visibleIds)));
  } else {
    const fallback = document.createElement("div");
    fallback.className = "diagram-root-box";
    graph.nodes.filter(n => visibleIds.has(n.id)).forEach(n => fallback.appendChild(renderNodeCard(n, graph)));
    nodes.appendChild(fallback);
  }

  requestAnimationFrame(()=>renderContainerLinks(graph));
}

function getVisibleIds(graph){
  const ids = new Set(["focus", "symptom", "recent-change", "metrics", "logs-events"]);
  graph.links.forEach(([a,b])=>{
    if(a==="focus") ids.add(b);
    if(b==="focus") ids.add(a);
    if(a.startsWith("parent-") || b.startsWith("parent-")){
      ids.add(a); ids.add(b);
    }
  });
  // Parent chain is represented as hierarchy boxes, not separate clickable nodes.
  [...ids].forEach(id => { if(id.startsWith("parent-")) ids.delete(id); });
  return ids;
}

function buildContainerMap(graph, visibleIds){
  const map = {};
  graph.nodes.forEach(n=>{
    if(!visibleIds.has(n.id)) return;
    const key = n.container || "default";
    if(!map[key]) map[key]=[];
    map[key].push(n);
  });
  return map;
}

function childBoxes(parentBox, graph){
  const boxes = graph.hierarchyBoxes || [];
  return boxes
    .filter(b => b.level === parentBox.level + 1)
    .filter(b => {
      if(parentBox.level === 0) return true;
      // simple inclusion by declared grid/class; keeps structure readable
      return true;
    });
}

function renderBox(box, graph, containerMap, visibleIds){
  const el = document.createElement("div");
  el.className = `diagram-box level-${box.level} box-${box.class || "default"}`;
  el.dataset.boxId = box.id;

  const head = document.createElement("div");
  head.className = "diagram-box-head";
  head.innerHTML = `<span>${box.title}</span><small>${box.level === 0 ? "parent" : "child"}</small>`;
  el.appendChild(head);

  const body = document.createElement("div");
  body.className = "diagram-box-body";

  const direct = containerMap[box.id] || [];
  direct.forEach(n => body.appendChild(renderNodeCard(n, graph)));

  const children = childBoxes(box, graph)
    .filter(child => (containerMap[child.id] || []).length || hasDescendantContent(child, graph, containerMap));

  children.forEach(child => body.appendChild(renderBox(child, graph, containerMap, visibleIds)));

  if(!direct.length && !children.length){
    const empty = document.createElement("div");
    empty.className = "box-empty-note";
    empty.textContent = "Context layer";
    body.appendChild(empty);
  }

  el.appendChild(body);
  return el;
}

function hasDescendantContent(box, graph, containerMap){
  const boxes = graph.hierarchyBoxes || [];
  const descendants = boxes.filter(b => b.level > box.level);
  return descendants.some(d => (containerMap[d.id] || []).length);
}

function renderNodeCard(n, graph){
  const el = document.createElement("button");
  const importance = n.id === "focus" ? "primary" :
    isConnectedToFocus(graph,n.id) ? "related" :
    ["symptom","recent-change","metrics","logs-events"].includes(n.id) ? "signal" : "context";

  el.className = `diagram-card ${importance} type-${n.type || "platform"}`;
  el.dataset.id = n.id;
  el.dataset.container = n.container || "";

  const labels = $("showLabels").checked;
  el.innerHTML = `
    <span class="card-chip">${n.type || "component"}</span>
    <strong>${n.title}</strong>
    ${labels ? `<p>${n.summary || ""}</p>` : ""}
  `;
  el.onclick = (ev) => {
    ev.stopPropagation();
    loadReadme(state.selected.scenario.graph.readme,state.selected.scenario.title);
    highlightCard(n.id);
  };
  return el;
}

function highlightCard(id){
  document.querySelectorAll(".diagram-card").forEach(c => c.classList.remove("clicked"));
  const el = document.querySelector(`.diagram-card[data-id="${CSS.escape(id)}"]`);
  if(el) el.classList.add("clicked");
}

function renderContainerLinks(graph){
  const links=$("links");
  links.innerHTML=`<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="rgba(148,163,184,.78)"></path></marker></defs>`;

  const visible = {};
  document.querySelectorAll(".diagram-card").forEach(el => visible[el.dataset.id]=el);

  graph.links.forEach(([a,b])=>{
    if(a.startsWith("parent-") || b.startsWith("parent-")) return;
    if(!visible[a] || !visible[b]) return;

    const cls = (a==="focus"||b==="focus") ? "active" :
      (isConnectedToFocus(graph,a)||isConnectedToFocus(graph,b)) ? "related" : "context";
    addDomLink(visible[a], visible[b], cls);
  });
}

function isConnectedToFocus(graph,id){ return graph.links.some(([a,b])=>(a==="focus"&&b===id)||(b==="focus"&&a===id)); }
function addGroup(x,y,w,h,title){
  const el=document.createElement("div"); el.className="cluster-title";
  el.style.left=x+"px"; el.style.top=y+"px"; el.style.width=w+"px"; el.style.height=h+"px";
  el.innerHTML=`<span>${title}</span>`; $("nodes").appendChild(el);
}
function addDomLink(aEl,bEl,cls){
  const svg=$("links");
  const stage=$("stage").getBoundingClientRect();
  const a=aEl.getBoundingClientRect();
  const b=bEl.getBoundingClientRect();

  const x1=a.left-stage.left+a.width/2;
  const y1=a.top-stage.top+a.height/2;
  const x2=b.left-stage.left+b.width/2;
  const y2=b.top-stage.top+b.height/2;

  const dx = Math.abs(x2-x1);
  const dy = Math.abs(y2-y1);
  const horizontal = dx >= dy;

  let d;
  if(horizontal){
    const mid=Math.max(40,dx/2);
    d=`M ${x1} ${y1} C ${x1+mid} ${y1}, ${x2-mid} ${y2}, ${x2} ${y2}`;
  } else {
    const mid=Math.max(34,dy/2);
    d=`M ${x1} ${y1} C ${x1} ${y1+mid}, ${x2} ${y2-mid}, ${x2} ${y2}`;
  }

  const path=document.createElementNS("http://www.w3.org/2000/svg","path");
  path.setAttribute("d",d);
  path.setAttribute("marker-end","url(#arrow)");
  path.setAttribute("class",`link ${cls}`);
  svg.appendChild(path);
}

async function loadReadme(path,title){
  $("details").classList.add("open");
  $("readmeBadge").textContent=path; $("readmeTitle").textContent=title;
  $("markdown").innerHTML=`<p>Loading <code>${path}</code>...</p>`;
  try{
    const res=await fetch(path); if(!res.ok) throw new Error("missing");
    $("markdown").innerHTML=mdToHtml(await res.text());
  }catch(e){ $("markdown").innerHTML=`<h1>${title}</h1><p>README not found: <code>${path}</code></p>`; }
}
function renderRelated(){
  const q=state.query;
  let items = allScenarios();
  if(state.selected) items = items.filter(x=>x.domain.id===state.selected.domainId && x.scenario.id!==state.selected.scenarioId);
  if(q) items = items.filter(x=>`${x.domain.title} ${x.area.title} ${x.scenario.title} ${x.scenario.summary}`.toLowerCase().includes(q));
  $("relatedScenarios").innerHTML = items.slice(0,8).map(x=>`<div class="scenario-card" onclick="selectScenario('${x.domain.id}','${x.area.id}','${x.scenario.id}',true)">
    <span class="badge">${x.domain.title}</span><h3>${x.scenario.title}</h3><p>${x.scenario.summary}</p>
  </div>`).join("");
}
function mdToHtml(md){
  let html=md.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  html=html.replace(/```([\s\S]*?)```/g,(_,c)=>`<pre><code>${c.trim()}</code></pre>`);
  html=html.replace(/^### (.*)$/gm,"<h3>$1</h3>").replace(/^## (.*)$/gm,"<h2>$1</h2>").replace(/^# (.*)$/gm,"<h1>$1</h1>");
  html=html.replace(/`([^`]+)`/g,"<code>$1</code>");
  html=html.replace(/^- (.*)$/gm,"<li>$1</li>").replace(/(<li>.*<\/li>\n?)+/g,m=>`<ul>${m}</ul>`);
  html=html.replace(/\n\n/g,"</p><p>");
  return `<p>${html}</p>`.replace(/<p><h/g,"<h").replace(/<\/h([123])><\/p>/g,"</h$1>");
}

window.addEventListener("resize", ()=>{
  if(state.selected) renderGraph(state.selected.scenario);
});
init();

