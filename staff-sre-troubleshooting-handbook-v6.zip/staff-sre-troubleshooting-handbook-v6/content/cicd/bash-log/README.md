# Bash log parsing

## Purpose

This runbook covers **Bash log parsing** under **CI/CD: Bash, Helm, ArgoCD, Jenkins / Delivery issues**.

## Symptom

Shell script for log processing fails or misses data.

## Fast triage

1. Confirm blast radius: one pod/host/pipeline/account, one AZ/zone, or global.
2. Check recent changes: deployment, config, cert, IAM, route, autoscaling, secrets.
3. Follow the diagram from **Symptom → Focus Component → Metrics/Logs/Events**.
4. Mitigate first if user impact is high.
5. Preserve evidence for postmortem.

## Handy commands

```bash
git log --oneline -n 10
helm template ./chart -f values.yaml
helm status <release> -n <ns>
argocd app get <app>
jenkins-cli list-jobs
```

## Root cause checklist

- Configuration mismatch
- Resource saturation
- Dependency outage
- IAM/RBAC/policy denial
- Network/DNS/TLS path failure
- Bad rollout or incompatible version
- Capacity or quota limit
- Missing observability or wrong alert threshold

## Staff SRE prevention

- Add SLO or burn-rate alert if user-facing.
- Add dashboard for the exact failure mode.
- Add safe rollback or automated mitigation.
- Add policy guardrail where humans repeatedly make mistakes.
- Add runbook ownership, escalation and test/gameday schedule.

## Interview answer structure

Use this order:

```text
Impact → scope → signals → layer isolation → commands → root cause → mitigation → prevention → platform improvement
```
