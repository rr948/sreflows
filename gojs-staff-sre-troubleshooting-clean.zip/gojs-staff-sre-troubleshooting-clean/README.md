# GoJS Staff SRE Troubleshooting Handbook - Expanded

## Coverage

- 19 domains/tools
- 89 repeated troubleshooting scenarios
- GoJS nested infrastructure boundaries
- Shared-state highlighting of related nodes and links
- README runbook rendering on the right

## Run

```bash
cd gojs-staff-sre-troubleshooting-expanded
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Tools covered

- Kubernetes
- Linux
- Docker
- Terraform
- AWS
- GCP
- Observability
- Windows
- Bash
- Helm
- ArgoCD
- Jenkins
- SRE Principles
- Vault
- Consul
- Networking
- TLS Certificates
- Databases
- CI/CD


## Clean Diagram Update

- Removed visible role labels like symptom/focus/dependency/validation from boxes.
- Kept colors for meaning, but node text is now infrastructure-oriented.
- Group names are now domain-specific instead of repeated generic templates.
- Link labels are reduced to small numbered bubbles.
- Relationship panel is hidden to keep the UI cleaner.
