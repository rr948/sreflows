# Connection pool exhausted

## Purpose

App cannot get DB connection

## What to inspect

- Focus component: **Connection Pool**
- Connected dependencies: Max Connections, App Pool, DB Limit
- Validation signals: pg_stat_activity

## Handy commands

```bash
SELECT * FROM pg_stat_activity;
EXPLAIN ANALYZE <query>;
SHOW max_connections;
```

## Relationship descriptions

- 1. Connection pool exhausted → Connection Pool: 1 symptom maps to focus
- 2. Connection Pool → Max Connections: 2 inspect dependency
- 3. Connection Pool → App Pool: 3 inspect dependency
- 4. Connection Pool → DB Limit: 4 inspect dependency
- 5. Connection Pool → pg_stat_activity: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
