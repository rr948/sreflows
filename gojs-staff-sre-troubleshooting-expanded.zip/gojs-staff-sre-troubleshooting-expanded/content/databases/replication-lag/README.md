# Replication lag

## Purpose

Replica behind primary

## What to inspect

- Focus component: **Replica**
- Connected dependencies: WAL/Binlog, Network, IO
- Validation signals: replication status

## Handy commands

```bash
SELECT * FROM pg_stat_activity;
EXPLAIN ANALYZE <query>;
SHOW max_connections;
```

## Relationship descriptions

- 1. Replication lag → Replica: 1 symptom maps to focus
- 2. Replica → WAL/Binlog: 2 inspect dependency
- 3. Replica → Network: 3 inspect dependency
- 4. Replica → IO: 4 inspect dependency
- 5. Replica → replication status: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
