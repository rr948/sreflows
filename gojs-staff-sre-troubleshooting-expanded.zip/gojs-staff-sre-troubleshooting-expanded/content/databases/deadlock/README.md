# Deadlock / lock wait

## Purpose

Transactions block each other

## What to inspect

- Focus component: **Lock**
- Connected dependencies: Transaction, Query, Isolation Level
- Validation signals: lock tables

## Handy commands

```bash
SELECT * FROM pg_stat_activity;
EXPLAIN ANALYZE <query>;
SHOW max_connections;
```

## Relationship descriptions

- 1. Deadlock / lock wait → Lock: 1 symptom maps to focus
- 2. Lock → Transaction: 2 inspect dependency
- 3. Lock → Query: 3 inspect dependency
- 4. Lock → Isolation Level: 4 inspect dependency
- 5. Lock → lock tables: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
