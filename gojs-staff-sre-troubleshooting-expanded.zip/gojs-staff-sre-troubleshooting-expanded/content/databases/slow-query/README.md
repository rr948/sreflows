# Slow query

## Purpose

DB query latency increases

## What to inspect

- Focus component: **Slow Query**
- Connected dependencies: Index, Lock, Execution Plan
- Validation signals: EXPLAIN

## Handy commands

```bash
SELECT * FROM pg_stat_activity;
EXPLAIN ANALYZE <query>;
SHOW max_connections;
```

## Relationship descriptions

- 1. Slow query → Slow Query: 1 symptom maps to focus
- 2. Slow Query → Index: 2 inspect dependency
- 3. Slow Query → Lock: 3 inspect dependency
- 4. Slow Query → Execution Plan: 4 inspect dependency
- 5. Slow Query → EXPLAIN: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
