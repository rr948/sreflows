# Windows network issue

## Purpose

DNS route firewall issue

## What to inspect

- Focus component: **Network Stack**
- Connected dependencies: DNS Client, Route, Firewall
- Validation signals: Get-NetTCPConnection

## Handy commands

```bash
Get-Service
Get-EventLog -LogName System -Newest 50
Get-NetTCPConnection | ? State -eq Established
```

## Relationship descriptions

- 1. Windows network issue → Network Stack: 1 symptom maps to focus
- 2. Network Stack → DNS Client: 2 inspect dependency
- 3. Network Stack → Route: 3 inspect dependency
- 4. Network Stack → Firewall: 4 inspect dependency
- 5. Network Stack → Get-NetTCPConnection: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
