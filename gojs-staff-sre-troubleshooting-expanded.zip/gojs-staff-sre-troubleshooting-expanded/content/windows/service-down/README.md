# Windows service down

## Purpose

Windows service stopped

## What to inspect

- Focus component: **Windows Service**
- Connected dependencies: Service Account, Event Log, Dependency Service
- Validation signals: Get-Service

## Handy commands

```bash
Get-Service
Get-EventLog -LogName System -Newest 50
Get-NetTCPConnection | ? State -eq Established
```

## Relationship descriptions

- 1. Windows service down → Windows Service: 1 symptom maps to focus
- 2. Windows Service → Service Account: 2 inspect dependency
- 3. Windows Service → Event Log: 3 inspect dependency
- 4. Windows Service → Dependency Service: 4 inspect dependency
- 5. Windows Service → Get-Service: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
