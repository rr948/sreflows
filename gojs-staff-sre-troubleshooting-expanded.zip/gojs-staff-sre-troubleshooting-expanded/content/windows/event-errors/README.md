# Event log errors

## Purpose

System or app event errors

## What to inspect

- Focus component: **Event Viewer**
- Connected dependencies: System Log, Application Log, Security Log
- Validation signals: Get-EventLog

## Handy commands

```bash
Get-Service
Get-EventLog -LogName System -Newest 50
Get-NetTCPConnection | ? State -eq Established
```

## Relationship descriptions

- 1. Event log errors → Event Viewer: 1 symptom maps to focus
- 2. Event Viewer → System Log: 2 inspect dependency
- 3. Event Viewer → Application Log: 3 inspect dependency
- 4. Event Viewer → Security Log: 4 inspect dependency
- 5. Event Viewer → Get-EventLog: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
