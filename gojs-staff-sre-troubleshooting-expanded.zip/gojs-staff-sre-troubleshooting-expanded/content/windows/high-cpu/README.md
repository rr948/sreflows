# Windows high CPU

## Purpose

Process or service CPU saturation

## What to inspect

- Focus component: **Process**
- Connected dependencies: Thread, Service, Perf Counter
- Validation signals: Get-Process

## Handy commands

```bash
Get-Service
Get-EventLog -LogName System -Newest 50
Get-NetTCPConnection | ? State -eq Established
```

## Relationship descriptions

- 1. Windows high CPU → Process: 1 symptom maps to focus
- 2. Process → Thread: 2 inspect dependency
- 3. Process → Service: 3 inspect dependency
- 4. Process → Perf Counter: 4 inspect dependency
- 5. Process → Get-Process: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
