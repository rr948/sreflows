# Wrong exit code

## Purpose

Script succeeds or fails incorrectly

## What to inspect

- Focus component: **Exit Code**
- Connected dependencies: set -euo pipefail, Pipeline Failure, Trap
- Validation signals: bash -x

## Handy commands

```bash
bash -x script.sh
grep -R 'ERROR' logs/
awk '{print $1}' access.log | sort | uniq -c | sort -nr
jq '.' file.json
```

## Relationship descriptions

- 1. Wrong exit code → Exit Code: 1 symptom maps to focus
- 2. Exit Code → set -euo pipefail: 2 inspect dependency
- 3. Exit Code → Pipeline Failure: 3 inspect dependency
- 4. Exit Code → Trap: 4 inspect dependency
- 5. Exit Code → bash -x: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
