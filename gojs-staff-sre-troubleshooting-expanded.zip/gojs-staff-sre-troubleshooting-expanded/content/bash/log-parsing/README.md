# Log parsing issue

## Purpose

Script misses or misparses logs

## What to inspect

- Focus component: **grep/awk/sed**
- Connected dependencies: Regex, Field Separator, Sort/uniq
- Validation signals: sample log

## Handy commands

```bash
bash -x script.sh
grep -R 'ERROR' logs/
awk '{print $1}' access.log | sort | uniq -c | sort -nr
jq '.' file.json
```

## Relationship descriptions

- 1. Log parsing issue → grep/awk/sed: 1 symptom maps to focus
- 2. grep/awk/sed → Regex: 2 inspect dependency
- 3. grep/awk/sed → Field Separator: 3 inspect dependency
- 4. grep/awk/sed → Sort/uniq: 4 inspect dependency
- 5. grep/awk/sed → sample log: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
