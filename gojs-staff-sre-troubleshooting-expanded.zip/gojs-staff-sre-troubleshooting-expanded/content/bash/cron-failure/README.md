# Cron job failure

## Purpose

Works manually but fails in cron

## What to inspect

- Focus component: **Cron Environment**
- Connected dependencies: PATH, Working Dir, User
- Validation signals: cron logs

## Handy commands

```bash
bash -x script.sh
grep -R 'ERROR' logs/
awk '{print $1}' access.log | sort | uniq -c | sort -nr
jq '.' file.json
```

## Relationship descriptions

- 1. Cron job failure → Cron Environment: 1 symptom maps to focus
- 2. Cron Environment → PATH: 2 inspect dependency
- 3. Cron Environment → Working Dir: 3 inspect dependency
- 4. Cron Environment → User: 4 inspect dependency
- 5. Cron Environment → cron logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
