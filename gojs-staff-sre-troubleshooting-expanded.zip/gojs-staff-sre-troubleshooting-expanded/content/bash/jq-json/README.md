# jq JSON parsing failure

## Purpose

Script fails on JSON input

## What to inspect

- Focus component: **jq Filter**
- Connected dependencies: Null Field, Array Path, Escaping
- Validation signals: jq -r

## Handy commands

```bash
bash -x script.sh
grep -R 'ERROR' logs/
awk '{print $1}' access.log | sort | uniq -c | sort -nr
jq '.' file.json
```

## Relationship descriptions

- 1. jq JSON parsing failure → jq Filter: 1 symptom maps to focus
- 2. jq Filter → Null Field: 2 inspect dependency
- 3. jq Filter → Array Path: 3 inspect dependency
- 4. jq Filter → Escaping: 4 inspect dependency
- 5. jq Filter → jq -r: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
