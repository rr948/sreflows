# Health degraded

## Purpose

Synced app is degraded

## What to inspect

- Focus component: **Health Check**
- Connected dependencies: Deployment, Service, Ingress
- Validation signals: ArgoCD Events

## Handy commands

```bash
argocd app list
argocd app get <app>
argocd app diff <app>
argocd app sync <app>
```

## Relationship descriptions

- 1. Health degraded → Health Check: 1 symptom maps to focus
- 2. Health Check → Deployment: 2 inspect dependency
- 3. Health Check → Service: 3 inspect dependency
- 4. Health Check → Ingress: 4 inspect dependency
- 5. Health Check → ArgoCD Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
