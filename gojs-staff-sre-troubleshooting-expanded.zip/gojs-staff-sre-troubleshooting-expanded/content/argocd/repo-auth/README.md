# Repo auth failure

## Purpose

ArgoCD cannot read repo

## What to inspect

- Focus component: **Repository Credentials**
- Connected dependencies: SSH Key, Token, Repo URL
- Validation signals: argocd repo list

## Handy commands

```bash
argocd app list
argocd app get <app>
argocd app diff <app>
argocd app sync <app>
```

## Relationship descriptions

- 1. Repo auth failure → Repository Credentials: 1 symptom maps to focus
- 2. Repository Credentials → SSH Key: 2 inspect dependency
- 3. Repository Credentials → Token: 3 inspect dependency
- 4. Repository Credentials → Repo URL: 4 inspect dependency
- 5. Repository Credentials → argocd repo list: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
