# Application OutOfSync

## Purpose

GitOps drift or sync mismatch

## What to inspect

- Focus component: **ArgoCD Application**
- Connected dependencies: Git Revision, Live State, Diff
- Validation signals: argocd app diff

## Handy commands

```bash
argocd app list
argocd app get <app>
argocd app diff <app>
argocd app sync <app>
```

## Relationship descriptions

- 1. Application OutOfSync → ArgoCD Application: 1 symptom maps to focus
- 2. ArgoCD Application → Git Revision: 2 inspect dependency
- 3. ArgoCD Application → Live State: 3 inspect dependency
- 4. ArgoCD Application → Diff: 4 inspect dependency
- 5. ArgoCD Application → argocd app diff: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
