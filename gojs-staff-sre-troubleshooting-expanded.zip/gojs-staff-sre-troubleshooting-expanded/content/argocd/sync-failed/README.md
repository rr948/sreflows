# Sync failed

## Purpose

ArgoCD cannot apply manifests

## What to inspect

- Focus component: **Sync Operation**
- Connected dependencies: RBAC, Webhook, K8s API
- Validation signals: argocd app get

## Handy commands

```bash
argocd app list
argocd app get <app>
argocd app diff <app>
argocd app sync <app>
```

## Relationship descriptions

- 1. Sync failed → Sync Operation: 1 symptom maps to focus
- 2. Sync Operation → RBAC: 2 inspect dependency
- 3. Sync Operation → Webhook: 3 inspect dependency
- 4. Sync Operation → K8s API: 4 inspect dependency
- 5. Sync Operation → argocd app get: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
