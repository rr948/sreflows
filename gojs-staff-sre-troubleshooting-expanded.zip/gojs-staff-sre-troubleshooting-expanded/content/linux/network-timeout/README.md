# Network timeout

## Purpose

Routing DNS firewall or packet issue

## What to inspect

- Focus component: **Network Path**
- Connected dependencies: DNS, Route Table, Listener Port
- Validation signals: tcpdump

## Handy commands

```bash
uptime
top -H
free -m
vmstat 1
df -h
ss -tulpen
journalctl -xe
```

## Relationship descriptions

- 1. Network timeout → Network Path: 1 symptom maps to focus
- 2. Network Path → DNS: 2 inspect dependency
- 3. Network Path → Route Table: 3 inspect dependency
- 4. Network Path → Listener Port: 4 inspect dependency
- 5. Network Path → tcpdump: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
