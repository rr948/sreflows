# High CPU

## Purpose

Host or process CPU saturation

## What to inspect

- Focus component: **Top Process / Thread**
- Connected dependencies: Run Queue, Kernel Scheduler, Hot Syscalls
- Validation signals: pidstat / perf

## Handy commands

```bash
uptime
top -H
free -m
vmstat 1
df -h
ss -tulpen
journalctl -xe
```

## Relationship descriptions

- 1. High CPU → Top Process / Thread: 1 symptom maps to focus
- 2. Top Process / Thread → Run Queue: 2 inspect dependency
- 3. Top Process / Thread → Kernel Scheduler: 3 inspect dependency
- 4. Top Process / Thread → Hot Syscalls: 4 inspect dependency
- 5. Top Process / Thread → pidstat / perf: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
