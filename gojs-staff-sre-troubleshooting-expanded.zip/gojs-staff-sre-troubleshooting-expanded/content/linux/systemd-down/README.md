# systemd service down

## Purpose

Service crashed or failed

## What to inspect

- Focus component: **systemd Unit**
- Connected dependencies: ExecStart, Environment, Journal Logs
- Validation signals: systemctl status

## Handy commands

```bash
uptime
top -H
free -m
vmstat 1
df -h
ss -tulpen
journalctl -xe
```

## Relationship descriptions

- 1. systemd service down → systemd Unit: 1 symptom maps to focus
- 2. systemd Unit → ExecStart: 2 inspect dependency
- 3. systemd Unit → Environment: 3 inspect dependency
- 4. systemd Unit → Journal Logs: 4 inspect dependency
- 5. systemd Unit → systemctl status: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
