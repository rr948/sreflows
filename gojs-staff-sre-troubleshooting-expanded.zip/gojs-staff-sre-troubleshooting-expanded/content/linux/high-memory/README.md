# High Memory / OOM

## Purpose

Memory pressure or OOM killer

## What to inspect

- Focus component: **Memory Pressure**
- Connected dependencies: Top RSS Process, Swap, Page Cache
- Validation signals: dmesg OOM

## Handy commands

```bash
uptime
top -H
free -m
vmstat 1
df -h
ss -tulpen
journalctl -xe
```

## Relationship descriptions

- 1. High Memory / OOM → Memory Pressure: 1 symptom maps to focus
- 2. Memory Pressure → Top RSS Process: 2 inspect dependency
- 3. Memory Pressure → Swap: 3 inspect dependency
- 4. Memory Pressure → Page Cache: 4 inspect dependency
- 5. Memory Pressure → dmesg OOM: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
