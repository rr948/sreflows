# High load average

## Purpose

Load high due CPU IO blocked tasks

## What to inspect

- Focus component: **Load Average**
- Connected dependencies: CPU Queue, Disk IO, D-state Tasks
- Validation signals: vmstat / iostat

## Handy commands

```bash
uptime
top -H
free -m
vmstat 1
df -h
ss -tulpen
journalctl -xe
```

## Relationship descriptions

- 1. High load average → Load Average: 1 symptom maps to focus
- 2. Load Average → CPU Queue: 2 inspect dependency
- 3. Load Average → Disk IO: 3 inspect dependency
- 4. Load Average → D-state Tasks: 4 inspect dependency
- 5. Load Average → vmstat / iostat: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
