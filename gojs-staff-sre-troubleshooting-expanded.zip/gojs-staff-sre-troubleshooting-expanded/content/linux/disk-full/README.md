# Disk or inode full

## Purpose

Filesystem full or inode exhaustion

## What to inspect

- Focus component: **Filesystem**
- Connected dependencies: Large Directory, Inodes, Logs
- Validation signals: df / du

## Handy commands

```bash
uptime
top -H
free -m
vmstat 1
df -h
ss -tulpen
journalctl -xe
```

## Relationship descriptions

- 1. Disk or inode full → Filesystem: 1 symptom maps to focus
- 2. Filesystem → Large Directory: 2 inspect dependency
- 3. Filesystem → Inodes: 3 inspect dependency
- 4. Filesystem → Logs: 4 inspect dependency
- 5. Filesystem → df / du: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
