# Service unhealthy

## Purpose

Consul check marks service unhealthy

## What to inspect

- Focus component: **Health Check**
- Connected dependencies: Service Registration, Check Script, Network
- Validation signals: consul health checks

## Handy commands

```bash
consul members
consul operator raft list-peers
consul catalog services
consul health checks
```

## Relationship descriptions

- 1. Service unhealthy → Health Check: 1 symptom maps to focus
- 2. Health Check → Service Registration: 2 inspect dependency
- 3. Health Check → Check Script: 3 inspect dependency
- 4. Health Check → Network: 4 inspect dependency
- 5. Health Check → consul health checks: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
