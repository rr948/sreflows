# Consul DNS failure

## Purpose

Service discovery via DNS fails

## What to inspect

- Focus component: **Consul DNS**
- Connected dependencies: Port 8600, Service Catalog, Agent
- Validation signals: dig @127.0.0.1

## Handy commands

```bash
consul members
consul operator raft list-peers
consul catalog services
consul health checks
```

## Relationship descriptions

- 1. Consul DNS failure → Consul DNS: 1 symptom maps to focus
- 2. Consul DNS → Port 8600: 2 inspect dependency
- 3. Consul DNS → Service Catalog: 3 inspect dependency
- 4. Consul DNS → Agent: 4 inspect dependency
- 5. Consul DNS → dig @127.0.0.1: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
