# KV config missing

## Purpose

Application cannot read KV

## What to inspect

- Focus component: **KV Path**
- Connected dependencies: ACL Token, Path, Bootstrap
- Validation signals: consul kv get

## Handy commands

```bash
consul members
consul operator raft list-peers
consul catalog services
consul health checks
```

## Relationship descriptions

- 1. KV config missing → KV Path: 1 symptom maps to focus
- 2. KV Path → ACL Token: 2 inspect dependency
- 3. KV Path → Path: 3 inspect dependency
- 4. KV Path → Bootstrap: 4 inspect dependency
- 5. KV Path → consul kv get: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
