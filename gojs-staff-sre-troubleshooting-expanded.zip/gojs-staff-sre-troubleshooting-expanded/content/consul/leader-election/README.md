# Leader election issue

## Purpose

Consul cluster unstable

## What to inspect

- Focus component: **Consul Leader**
- Connected dependencies: Peers, Raft, Network
- Validation signals: consul operator raft

## Handy commands

```bash
consul members
consul operator raft list-peers
consul catalog services
consul health checks
```

## Relationship descriptions

- 1. Leader election issue → Consul Leader: 1 symptom maps to focus
- 2. Consul Leader → Peers: 2 inspect dependency
- 3. Consul Leader → Raft: 3 inspect dependency
- 4. Consul Leader → Network: 4 inspect dependency
- 5. Consul Leader → consul operator raft: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
