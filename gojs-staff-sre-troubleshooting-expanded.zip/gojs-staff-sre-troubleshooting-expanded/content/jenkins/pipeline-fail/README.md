# Pipeline stage failure

## Purpose

Build/test/deploy stage fails

## What to inspect

- Focus component: **Pipeline Stage**
- Connected dependencies: Jenkinsfile, Environment, Artifact
- Validation signals: console log

## Handy commands

```bash
# Check Jenkins console log
# Verify agent status
# Validate credentials ID
```

## Relationship descriptions

- 1. Pipeline stage failure → Pipeline Stage: 1 symptom maps to focus
- 2. Pipeline Stage → Jenkinsfile: 2 inspect dependency
- 3. Pipeline Stage → Environment: 3 inspect dependency
- 4. Pipeline Stage → Artifact: 4 inspect dependency
- 5. Pipeline Stage → console log: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
