# Shared library break

## Purpose

Library version breaks pipeline

## What to inspect

- Focus component: **Shared Library**
- Connected dependencies: Branch/Tag, Function Signature, Sandbox
- Validation signals: replay

## Handy commands

```bash
# Check Jenkins console log
# Verify agent status
# Validate credentials ID
```

## Relationship descriptions

- 1. Shared library break → Shared Library: 1 symptom maps to focus
- 2. Shared Library → Branch/Tag: 2 inspect dependency
- 3. Shared Library → Function Signature: 3 inspect dependency
- 4. Shared Library → Sandbox: 4 inspect dependency
- 5. Shared Library → replay: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
