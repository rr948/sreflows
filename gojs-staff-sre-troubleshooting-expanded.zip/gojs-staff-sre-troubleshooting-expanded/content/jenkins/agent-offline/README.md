# Agent offline

## Purpose

Build stuck because agent offline

## What to inspect

- Focus component: **Jenkins Agent**
- Connected dependencies: Node Label, Connectivity, Executor
- Validation signals: agent logs

## Handy commands

```bash
# Check Jenkins console log
# Verify agent status
# Validate credentials ID
```

## Relationship descriptions

- 1. Agent offline → Jenkins Agent: 1 symptom maps to focus
- 2. Jenkins Agent → Node Label: 2 inspect dependency
- 3. Jenkins Agent → Connectivity: 3 inspect dependency
- 4. Jenkins Agent → Executor: 4 inspect dependency
- 5. Jenkins Agent → agent logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
