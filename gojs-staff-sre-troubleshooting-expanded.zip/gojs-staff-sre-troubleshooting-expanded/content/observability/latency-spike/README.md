# Latency spike

## Purpose

p95 p99 latency increase

## What to inspect

- Focus component: **Slow Endpoint / Span**
- Connected dependencies: Downstream Dependency, Resource Saturation, Deployment
- Validation signals: Trace / Dashboard

## Handy commands

```bash
curl -w '%{http_code} %{time_total}\n' -o /dev/null -s https://service
kubectl top pods -A
grep -i 'error\|timeout' app.log
```

## Relationship descriptions

- 1. Latency spike → Slow Endpoint / Span: 1 symptom maps to focus
- 2. Slow Endpoint / Span → Downstream Dependency: 2 inspect dependency
- 3. Slow Endpoint / Span → Resource Saturation: 3 inspect dependency
- 4. Slow Endpoint / Span → Deployment: 4 inspect dependency
- 5. Slow Endpoint / Span → Trace / Dashboard: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
