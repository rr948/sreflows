# Error rate spike

## Purpose

5xx or app errors increased

## What to inspect

- Focus component: **Error Source**
- Connected dependencies: Recent Deploy, Dependency, Validation Rule
- Validation signals: Logs

## Handy commands

```bash
curl -w '%{http_code} %{time_total}\n' -o /dev/null -s https://service
kubectl top pods -A
grep -i 'error\|timeout' app.log
```

## Relationship descriptions

- 1. Error rate spike → Error Source: 1 symptom maps to focus
- 2. Error Source → Recent Deploy: 2 inspect dependency
- 3. Error Source → Dependency: 3 inspect dependency
- 4. Error Source → Validation Rule: 4 inspect dependency
- 5. Error Source → Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
