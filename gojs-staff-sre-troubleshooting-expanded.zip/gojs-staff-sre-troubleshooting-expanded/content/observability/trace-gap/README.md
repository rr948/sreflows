# Trace gaps

## Purpose

Distributed traces missing spans

## What to inspect

- Focus component: **Instrumentation**
- Connected dependencies: Propagators, Sampler, Collector
- Validation signals: OTel Logs

## Handy commands

```bash
curl -w '%{http_code} %{time_total}\n' -o /dev/null -s https://service
kubectl top pods -A
grep -i 'error\|timeout' app.log
```

## Relationship descriptions

- 1. Trace gaps → Instrumentation: 1 symptom maps to focus
- 2. Instrumentation → Propagators: 2 inspect dependency
- 3. Instrumentation → Sampler: 3 inspect dependency
- 4. Instrumentation → Collector: 4 inspect dependency
- 5. Instrumentation → OTel Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
