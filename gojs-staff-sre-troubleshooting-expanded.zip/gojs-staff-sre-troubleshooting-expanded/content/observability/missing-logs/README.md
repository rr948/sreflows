# Missing logs

## Purpose

Logs absent or delayed

## What to inspect

- Focus component: **Log Pipeline**
- Connected dependencies: Agent, Parser, Index / Tenant
- Validation signals: Agent Logs

## Handy commands

```bash
curl -w '%{http_code} %{time_total}\n' -o /dev/null -s https://service
kubectl top pods -A
grep -i 'error\|timeout' app.log
```

## Relationship descriptions

- 1. Missing logs → Log Pipeline: 1 symptom maps to focus
- 2. Log Pipeline → Agent: 2 inspect dependency
- 3. Log Pipeline → Parser: 3 inspect dependency
- 4. Log Pipeline → Index / Tenant: 4 inspect dependency
- 5. Log Pipeline → Agent Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
