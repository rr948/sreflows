# DNS Resolution Failure

## Purpose

Pod cannot resolve DNS

## What to inspect

- Focus component: **CoreDNS**
- Connected dependencies: kube-dns Service, NetworkPolicy, Upstream DNS
- Validation signals: CoreDNS Logs

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. DNS Resolution Failure → CoreDNS: 1 symptom maps to focus
- 2. CoreDNS → kube-dns Service: 2 inspect dependency
- 3. CoreDNS → NetworkPolicy: 3 inspect dependency
- 4. CoreDNS → Upstream DNS: 4 inspect dependency
- 5. CoreDNS → CoreDNS Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
