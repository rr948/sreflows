# PVC Pending

## Purpose

PVC cannot bind volume

## What to inspect

- Focus component: **PVC**
- Connected dependencies: StorageClass, PV / CSI, Zone / Node Affinity
- Validation signals: Events

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. PVC Pending → PVC: 1 symptom maps to focus
- 2. PVC → StorageClass: 2 inspect dependency
- 3. PVC → PV / CSI: 3 inspect dependency
- 4. PVC → Zone / Node Affinity: 4 inspect dependency
- 5. PVC → Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
