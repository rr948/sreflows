# HPA not scaling

## Purpose

Autoscaler does not react

## What to inspect

- Focus component: **HPA**
- Connected dependencies: Metrics API, Deployment, Resource Requests
- Validation signals: HPA Events

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. HPA not scaling → HPA: 1 symptom maps to focus
- 2. HPA → Metrics API: 2 inspect dependency
- 3. HPA → Deployment: 3 inspect dependency
- 4. HPA → Resource Requests: 4 inspect dependency
- 5. HPA → HPA Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
