# Node NotReady

## Purpose

Node condition is unhealthy

## What to inspect

- Focus component: **kubelet**
- Connected dependencies: Container Runtime, CNI Plugin, Disk / Memory Pressure
- Validation signals: Node Events

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. Node NotReady → kubelet: 1 symptom maps to focus
- 2. kubelet → Container Runtime: 2 inspect dependency
- 3. kubelet → CNI Plugin: 3 inspect dependency
- 4. kubelet → Disk / Memory Pressure: 4 inspect dependency
- 5. kubelet → Node Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
