# CrashLoopBackOff

## Purpose

Pod repeatedly crashes after start

## What to inspect

- Focus component: **Pod**
- Connected dependencies: Previous Logs, Probe / Entrypoint, ConfigMap / Secret
- Validation signals: Events

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. CrashLoopBackOff → Pod: 1 symptom maps to focus
- 2. Pod → Previous Logs: 2 inspect dependency
- 3. Pod → Probe / Entrypoint: 3 inspect dependency
- 4. Pod → ConfigMap / Secret: 4 inspect dependency
- 5. Pod → Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
