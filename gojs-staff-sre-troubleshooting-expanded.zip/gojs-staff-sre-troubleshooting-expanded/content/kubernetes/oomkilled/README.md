# OOMKilled

## Purpose

Pod killed by memory pressure

## What to inspect

- Focus component: **Pod Memory**
- Connected dependencies: Memory Limit, Node Memory, OOM Killer
- Validation signals: Container Logs

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. OOMKilled → Pod Memory: 1 symptom maps to focus
- 2. Pod Memory → Memory Limit: 2 inspect dependency
- 3. Pod Memory → Node Memory: 3 inspect dependency
- 4. Pod Memory → OOM Killer: 4 inspect dependency
- 5. Pod Memory → Container Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
