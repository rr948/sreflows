# ImagePullBackOff

## Purpose

Image cannot be pulled from registry

## What to inspect

- Focus component: **Image Pull**
- Connected dependencies: Registry, ImagePullSecret, Image Tag
- Validation signals: Events

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. ImagePullBackOff → Image Pull: 1 symptom maps to focus
- 2. Image Pull → Registry: 2 inspect dependency
- 3. Image Pull → ImagePullSecret: 3 inspect dependency
- 4. Image Pull → Image Tag: 4 inspect dependency
- 5. Image Pull → Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
