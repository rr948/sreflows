# Service has no endpoints

## Purpose

Service has no backend endpoints

## What to inspect

- Focus component: **Service Selector**
- Connected dependencies: EndpointSlice, Pod Labels, Readiness
- Validation signals: kubectl describe svc

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. Service has no endpoints → Service Selector: 1 symptom maps to focus
- 2. Service Selector → EndpointSlice: 2 inspect dependency
- 3. Service Selector → Pod Labels: 3 inspect dependency
- 4. Service Selector → Readiness: 4 inspect dependency
- 5. Service Selector → kubectl describe svc: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
