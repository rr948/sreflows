# Pod Pending

## Purpose

Pod cannot schedule

## What to inspect

- Focus component: **Scheduler**
- Connected dependencies: Node Capacity, Taints / Affinity, PVC / Zone
- Validation signals: Events

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl get events -A --sort-by=.lastTimestamp
kubectl logs <pod> -n <ns> --previous
```

## Relationship descriptions

- 1. Pod Pending → Scheduler: 1 symptom maps to focus
- 2. Scheduler → Node Capacity: 2 inspect dependency
- 3. Scheduler → Taints / Affinity: 3 inspect dependency
- 4. Scheduler → PVC / Zone: 4 inspect dependency
- 5. Scheduler → Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
