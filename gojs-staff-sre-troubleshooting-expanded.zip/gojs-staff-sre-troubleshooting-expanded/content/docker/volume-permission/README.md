# Volume permission issue

## Purpose

Cannot read/write mounted volume

## What to inspect

- Focus component: **Volume Mount**
- Connected dependencies: UID/GID, Host Path, SELinux/AppArmor
- Validation signals: docker inspect

## Handy commands

```bash
docker ps -a
docker logs <container>
docker inspect <container>
docker stats
docker network ls
```

## Relationship descriptions

- 1. Volume permission issue → Volume Mount: 1 symptom maps to focus
- 2. Volume Mount → UID/GID: 2 inspect dependency
- 3. Volume Mount → Host Path: 3 inspect dependency
- 4. Volume Mount → SELinux/AppArmor: 4 inspect dependency
- 5. Volume Mount → docker inspect: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
