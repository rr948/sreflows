# Port not accessible

## Purpose

Published port unreachable

## What to inspect

- Focus component: **Port Mapping**
- Connected dependencies: Container Listener, Bridge Network, Host Firewall
- Validation signals: docker inspect

## Handy commands

```bash
docker ps -a
docker logs <container>
docker inspect <container>
docker stats
docker network ls
```

## Relationship descriptions

- 1. Port not accessible → Port Mapping: 1 symptom maps to focus
- 2. Port Mapping → Container Listener: 2 inspect dependency
- 3. Port Mapping → Bridge Network: 3 inspect dependency
- 4. Port Mapping → Host Firewall: 4 inspect dependency
- 5. Port Mapping → docker inspect: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
