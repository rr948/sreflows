# Container exits

## Purpose

Container starts then exits

## What to inspect

- Focus component: **Container Process**
- Connected dependencies: Entrypoint, Env Variables, Mounted Files
- Validation signals: docker logs

## Handy commands

```bash
docker ps -a
docker logs <container>
docker inspect <container>
docker stats
docker network ls
```

## Relationship descriptions

- 1. Container exits → Container Process: 1 symptom maps to focus
- 2. Container Process → Entrypoint: 2 inspect dependency
- 3. Container Process → Env Variables: 3 inspect dependency
- 4. Container Process → Mounted Files: 4 inspect dependency
- 5. Container Process → docker logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
