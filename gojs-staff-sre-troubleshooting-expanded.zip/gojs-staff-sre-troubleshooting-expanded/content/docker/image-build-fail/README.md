# Image build failure

## Purpose

Docker build fails

## What to inspect

- Focus component: **Dockerfile**
- Connected dependencies: Base Image, Build Context, Layer Cache
- Validation signals: build logs

## Handy commands

```bash
docker ps -a
docker logs <container>
docker inspect <container>
docker stats
docker network ls
```

## Relationship descriptions

- 1. Image build failure → Dockerfile: 1 symptom maps to focus
- 2. Dockerfile → Base Image: 2 inspect dependency
- 3. Dockerfile → Build Context: 3 inspect dependency
- 4. Dockerfile → Layer Cache: 4 inspect dependency
- 5. Dockerfile → build logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
