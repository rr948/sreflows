# Vault token denied

## Purpose

Token lacks policy or expired

## What to inspect

- Focus component: **Token Policy**
- Connected dependencies: Policy, TTL, Auth Method
- Validation signals: vault token lookup

## Handy commands

```bash
vault status
vault auth list
vault secrets list
vault token lookup
```

## Relationship descriptions

- 1. Vault token denied → Token Policy: 1 symptom maps to focus
- 2. Token Policy → Policy: 2 inspect dependency
- 3. Token Policy → TTL: 3 inspect dependency
- 4. Token Policy → Auth Method: 4 inspect dependency
- 5. Token Policy → vault token lookup: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
