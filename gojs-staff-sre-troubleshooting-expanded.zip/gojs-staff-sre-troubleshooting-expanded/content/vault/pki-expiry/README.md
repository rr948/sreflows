# PKI certificate expiry

## Purpose

Certificate expired or rotation failed

## What to inspect

- Focus component: **PKI Role**
- Connected dependencies: Issuer, TTL, Renewal
- Validation signals: vault pki

## Handy commands

```bash
vault status
vault auth list
vault secrets list
vault token lookup
```

## Relationship descriptions

- 1. PKI certificate expiry → PKI Role: 1 symptom maps to focus
- 2. PKI Role → Issuer: 2 inspect dependency
- 3. PKI Role → TTL: 3 inspect dependency
- 4. PKI Role → Renewal: 4 inspect dependency
- 5. PKI Role → vault pki: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
