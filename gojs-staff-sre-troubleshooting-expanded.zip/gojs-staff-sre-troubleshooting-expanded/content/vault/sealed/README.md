# Vault sealed

## Purpose

Vault is sealed and clients fail

## What to inspect

- Focus component: **Seal State**
- Connected dependencies: Unseal Keys, Auto-unseal, Storage Backend
- Validation signals: vault status

## Handy commands

```bash
vault status
vault auth list
vault secrets list
vault token lookup
```

## Relationship descriptions

- 1. Vault sealed → Seal State: 1 symptom maps to focus
- 2. Seal State → Unseal Keys: 2 inspect dependency
- 3. Seal State → Auto-unseal: 3 inspect dependency
- 4. Seal State → Storage Backend: 4 inspect dependency
- 5. Seal State → vault status: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
