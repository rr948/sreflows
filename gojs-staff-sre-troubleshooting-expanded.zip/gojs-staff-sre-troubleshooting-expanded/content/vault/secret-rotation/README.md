# Secret rotation failure

## Purpose

Secret rotation failed

## What to inspect

- Focus component: **Secret Engine**
- Connected dependencies: Lease, Rotation Config, Backend
- Validation signals: vault audit

## Handy commands

```bash
vault status
vault auth list
vault secrets list
vault token lookup
```

## Relationship descriptions

- 1. Secret rotation failure → Secret Engine: 1 symptom maps to focus
- 2. Secret Engine → Lease: 2 inspect dependency
- 3. Secret Engine → Rotation Config: 3 inspect dependency
- 4. Secret Engine → Backend: 4 inspect dependency
- 5. Secret Engine → vault audit: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
