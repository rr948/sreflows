# GKE node pool issue

## Purpose

Node pool unavailable

## What to inspect

- Focus component: **Node Pool**
- Connected dependencies: Quota, Autoscaler, Node Health
- Validation signals: GKE Events

## Handy commands

```bash
gcloud auth list
gcloud projects get-iam-policy <project>
gcloud logging read 'severity>=ERROR' --limit 20
```

## Relationship descriptions

- 1. GKE node pool issue → Node Pool: 1 symptom maps to focus
- 2. Node Pool → Quota: 2 inspect dependency
- 3. Node Pool → Autoscaler: 3 inspect dependency
- 4. Node Pool → Node Health: 4 inspect dependency
- 5. Node Pool → GKE Events: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
