# GKE LB unhealthy

## Purpose

GKE backend unhealthy

## What to inspect

- Focus component: **Backend Service**
- Connected dependencies: NEG, Health Check, Pod Readiness
- Validation signals: LB Logs

## Handy commands

```bash
gcloud auth list
gcloud projects get-iam-policy <project>
gcloud logging read 'severity>=ERROR' --limit 20
```

## Relationship descriptions

- 1. GKE LB unhealthy → Backend Service: 1 symptom maps to focus
- 2. Backend Service → NEG: 2 inspect dependency
- 3. Backend Service → Health Check: 3 inspect dependency
- 4. Backend Service → Pod Readiness: 4 inspect dependency
- 5. Backend Service → LB Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
