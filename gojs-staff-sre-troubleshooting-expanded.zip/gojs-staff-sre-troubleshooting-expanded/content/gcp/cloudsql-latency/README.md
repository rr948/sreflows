# Cloud SQL latency

## Purpose

Cloud SQL slow or saturated

## What to inspect

- Focus component: **Cloud SQL**
- Connected dependencies: Connection Pool, CPU / IO, Slow Query
- Validation signals: Cloud Monitoring

## Handy commands

```bash
gcloud auth list
gcloud projects get-iam-policy <project>
gcloud logging read 'severity>=ERROR' --limit 20
```

## Relationship descriptions

- 1. Cloud SQL latency → Cloud SQL: 1 symptom maps to focus
- 2. Cloud SQL → Connection Pool: 2 inspect dependency
- 3. Cloud SQL → CPU / IO: 3 inspect dependency
- 4. Cloud SQL → Slow Query: 4 inspect dependency
- 5. Cloud SQL → Cloud Monitoring: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
