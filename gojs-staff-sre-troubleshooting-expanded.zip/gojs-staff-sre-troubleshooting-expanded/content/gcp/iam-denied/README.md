# GCP IAM denied

## Purpose

Service account lacks permission

## What to inspect

- Focus component: **IAM Binding**
- Connected dependencies: Service Account, Role, Org Policy
- Validation signals: Audit Logs

## Handy commands

```bash
gcloud auth list
gcloud projects get-iam-policy <project>
gcloud logging read 'severity>=ERROR' --limit 20
```

## Relationship descriptions

- 1. GCP IAM denied → IAM Binding: 1 symptom maps to focus
- 2. IAM Binding → Service Account: 2 inspect dependency
- 3. IAM Binding → Role: 3 inspect dependency
- 4. IAM Binding → Org Policy: 4 inspect dependency
- 5. IAM Binding → Audit Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
