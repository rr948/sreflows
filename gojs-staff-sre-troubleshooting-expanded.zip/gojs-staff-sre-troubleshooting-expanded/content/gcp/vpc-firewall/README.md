# GCP firewall block

## Purpose

Firewall or route blocks traffic

## What to inspect

- Focus component: **Firewall Rule**
- Connected dependencies: VPC Route, Subnet, Target Tag
- Validation signals: VPC Flow Logs

## Handy commands

```bash
gcloud auth list
gcloud projects get-iam-policy <project>
gcloud logging read 'severity>=ERROR' --limit 20
```

## Relationship descriptions

- 1. GCP firewall block → Firewall Rule: 1 symptom maps to focus
- 2. Firewall Rule → VPC Route: 2 inspect dependency
- 3. Firewall Rule → Subnet: 3 inspect dependency
- 4. Firewall Rule → Target Tag: 4 inspect dependency
- 5. Firewall Rule → VPC Flow Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
