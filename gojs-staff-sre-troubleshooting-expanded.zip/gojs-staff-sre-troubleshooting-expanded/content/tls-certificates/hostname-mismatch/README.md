# Hostname mismatch

## Purpose

Cert SAN does not match host

## What to inspect

- Focus component: **SAN**
- Connected dependencies: CN/SAN, Ingress Host, Client Hostname
- Validation signals: curl -vk

## Handy commands

```bash
openssl s_client -connect host:443 -servername host
openssl x509 -in cert.pem -text -noout
curl -vk https://host
```

## Relationship descriptions

- 1. Hostname mismatch → SAN: 1 symptom maps to focus
- 2. SAN → CN/SAN: 2 inspect dependency
- 3. SAN → Ingress Host: 3 inspect dependency
- 4. SAN → Client Hostname: 4 inspect dependency
- 5. SAN → curl -vk: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
