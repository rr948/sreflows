# Certificate expired

## Purpose

TLS cert expired or untrusted

## What to inspect

- Focus component: **Certificate**
- Connected dependencies: Issuer, SAN, Trust Store
- Validation signals: openssl s_client

## Handy commands

```bash
openssl s_client -connect host:443 -servername host
openssl x509 -in cert.pem -text -noout
curl -vk https://host
```

## Relationship descriptions

- 1. Certificate expired → Certificate: 1 symptom maps to focus
- 2. Certificate → Issuer: 2 inspect dependency
- 3. Certificate → SAN: 3 inspect dependency
- 4. Certificate → Trust Store: 4 inspect dependency
- 5. Certificate → openssl s_client: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
