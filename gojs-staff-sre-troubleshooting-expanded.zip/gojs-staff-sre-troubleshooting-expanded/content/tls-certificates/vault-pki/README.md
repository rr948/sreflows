# Vault PKI issue

## Purpose

Vault-issued cert invalid

## What to inspect

- Focus component: **Vault PKI**
- Connected dependencies: Role, Issuer, TTL
- Validation signals: vault read pki

## Handy commands

```bash
openssl s_client -connect host:443 -servername host
openssl x509 -in cert.pem -text -noout
curl -vk https://host
```

## Relationship descriptions

- 1. Vault PKI issue → Vault PKI: 1 symptom maps to focus
- 2. Vault PKI → Role: 2 inspect dependency
- 3. Vault PKI → Issuer: 3 inspect dependency
- 4. Vault PKI → TTL: 4 inspect dependency
- 5. Vault PKI → vault read pki: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
