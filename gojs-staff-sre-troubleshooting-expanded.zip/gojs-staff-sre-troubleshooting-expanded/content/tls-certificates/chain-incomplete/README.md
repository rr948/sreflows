# Incomplete chain

## Purpose

Server misses intermediate cert

## What to inspect

- Focus component: **Certificate Chain**
- Connected dependencies: Intermediate, Root CA, Bundle
- Validation signals: openssl verify

## Handy commands

```bash
openssl s_client -connect host:443 -servername host
openssl x509 -in cert.pem -text -noout
curl -vk https://host
```

## Relationship descriptions

- 1. Incomplete chain → Certificate Chain: 1 symptom maps to focus
- 2. Certificate Chain → Intermediate: 2 inspect dependency
- 3. Certificate Chain → Root CA: 3 inspect dependency
- 4. Certificate Chain → Bundle: 4 inspect dependency
- 5. Certificate Chain → openssl verify: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
