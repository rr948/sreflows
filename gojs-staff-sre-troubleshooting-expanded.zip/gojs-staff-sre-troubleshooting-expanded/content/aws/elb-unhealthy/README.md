# ELB unhealthy targets

## Purpose

Load balancer targets unhealthy

## What to inspect

- Focus component: **Target Group**
- Connected dependencies: Health Check, Security Group, Backend Port
- Validation signals: Target Health

## Handy commands

```bash
aws sts get-caller-identity
aws cloudtrail lookup-events --max-results 10
aws ec2 describe-security-groups
aws cloudwatch describe-alarms
```

## Relationship descriptions

- 1. ELB unhealthy targets → Target Group: 1 symptom maps to focus
- 2. Target Group → Health Check: 2 inspect dependency
- 3. Target Group → Security Group: 3 inspect dependency
- 4. Target Group → Backend Port: 4 inspect dependency
- 5. Target Group → Target Health: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
