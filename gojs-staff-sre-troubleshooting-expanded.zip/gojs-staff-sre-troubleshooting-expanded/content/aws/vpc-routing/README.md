# VPC routing issue

## Purpose

Subnet route table SG or NACL issue

## What to inspect

- Focus component: **Network Path**
- Connected dependencies: Route Table, Security Group, NACL
- Validation signals: VPC Flow Logs

## Handy commands

```bash
aws sts get-caller-identity
aws cloudtrail lookup-events --max-results 10
aws ec2 describe-security-groups
aws cloudwatch describe-alarms
```

## Relationship descriptions

- 1. VPC routing issue → Network Path: 1 symptom maps to focus
- 2. Network Path → Route Table: 2 inspect dependency
- 3. Network Path → Security Group: 3 inspect dependency
- 4. Network Path → NACL: 4 inspect dependency
- 5. Network Path → VPC Flow Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
