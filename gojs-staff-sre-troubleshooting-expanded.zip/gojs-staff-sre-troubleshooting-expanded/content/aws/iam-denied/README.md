# IAM AccessDenied

## Purpose

AWS API permission denied

## What to inspect

- Focus component: **IAM Policy**
- Connected dependencies: Principal, Policy Statement, SCP / Boundary
- Validation signals: CloudTrail

## Handy commands

```bash
aws sts get-caller-identity
aws cloudtrail lookup-events --max-results 10
aws ec2 describe-security-groups
aws cloudwatch describe-alarms
```

## Relationship descriptions

- 1. IAM AccessDenied → IAM Policy: 1 symptom maps to focus
- 2. IAM Policy → Principal: 2 inspect dependency
- 3. IAM Policy → Policy Statement: 3 inspect dependency
- 4. IAM Policy → SCP / Boundary: 4 inspect dependency
- 5. IAM Policy → CloudTrail: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
