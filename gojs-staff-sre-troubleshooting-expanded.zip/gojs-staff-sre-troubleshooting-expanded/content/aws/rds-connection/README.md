# RDS connection saturation

## Purpose

DB connection limit or latency

## What to inspect

- Focus component: **RDS Connections**
- Connected dependencies: Connection Pool, Security Group, Slow Queries
- Validation signals: CloudWatch

## Handy commands

```bash
aws sts get-caller-identity
aws cloudtrail lookup-events --max-results 10
aws ec2 describe-security-groups
aws cloudwatch describe-alarms
```

## Relationship descriptions

- 1. RDS connection saturation → RDS Connections: 1 symptom maps to focus
- 2. RDS Connections → Connection Pool: 2 inspect dependency
- 3. RDS Connections → Security Group: 3 inspect dependency
- 4. RDS Connections → Slow Queries: 4 inspect dependency
- 5. RDS Connections → CloudWatch: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
