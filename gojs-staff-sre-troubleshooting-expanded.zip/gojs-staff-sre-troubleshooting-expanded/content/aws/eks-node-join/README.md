# EKS node join failure

## Purpose

Node cannot join EKS

## What to inspect

- Focus component: **Node Bootstrap**
- Connected dependencies: IAM Role, aws-auth, Subnet / SG
- Validation signals: kubelet Logs

## Handy commands

```bash
aws sts get-caller-identity
aws cloudtrail lookup-events --max-results 10
aws ec2 describe-security-groups
aws cloudwatch describe-alarms
```

## Relationship descriptions

- 1. EKS node join failure → Node Bootstrap: 1 symptom maps to focus
- 2. Node Bootstrap → IAM Role: 2 inspect dependency
- 3. Node Bootstrap → aws-auth: 3 inspect dependency
- 4. Node Bootstrap → Subnet / SG: 4 inspect dependency
- 5. Node Bootstrap → kubelet Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
