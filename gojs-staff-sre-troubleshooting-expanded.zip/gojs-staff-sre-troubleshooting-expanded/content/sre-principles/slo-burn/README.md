# Fast SLO burn

## Purpose

Error budget burns too quickly

## What to inspect

- Focus component: **SLO Burn Rate**
- Connected dependencies: SLI, Alert Window, User Journey
- Validation signals: SLO Dashboard

## Handy commands

```bash
# Check SLO dashboard
# Calculate burn rate
# Review incident timeline
```

## Relationship descriptions

- 1. Fast SLO burn → SLO Burn Rate: 1 symptom maps to focus
- 2. SLO Burn Rate → SLI: 2 inspect dependency
- 3. SLO Burn Rate → Alert Window: 3 inspect dependency
- 4. SLO Burn Rate → User Journey: 4 inspect dependency
- 5. SLO Burn Rate → SLO Dashboard: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
