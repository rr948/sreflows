# Capacity risk

## Purpose

Traffic growth threatens reliability

## What to inspect

- Focus component: **Capacity Model**
- Connected dependencies: Load Test, Autoscaling, Quota
- Validation signals: forecast

## Handy commands

```bash
# Check SLO dashboard
# Calculate burn rate
# Review incident timeline
```

## Relationship descriptions

- 1. Capacity risk → Capacity Model: 1 symptom maps to focus
- 2. Capacity Model → Load Test: 2 inspect dependency
- 3. Capacity Model → Autoscaling: 3 inspect dependency
- 4. Capacity Model → Quota: 4 inspect dependency
- 5. Capacity Model → forecast: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
