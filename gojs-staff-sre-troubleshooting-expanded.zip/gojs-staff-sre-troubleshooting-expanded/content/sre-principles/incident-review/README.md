# Weak postmortem

## Purpose

Postmortem misses prevention

## What to inspect

- Focus component: **Postmortem**
- Connected dependencies: Timeline, Contributing Factors, Action Items
- Validation signals: review notes

## Handy commands

```bash
# Check SLO dashboard
# Calculate burn rate
# Review incident timeline
```

## Relationship descriptions

- 1. Weak postmortem → Postmortem: 1 symptom maps to focus
- 2. Postmortem → Timeline: 2 inspect dependency
- 3. Postmortem → Contributing Factors: 3 inspect dependency
- 4. Postmortem → Action Items: 4 inspect dependency
- 5. Postmortem → review notes: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
