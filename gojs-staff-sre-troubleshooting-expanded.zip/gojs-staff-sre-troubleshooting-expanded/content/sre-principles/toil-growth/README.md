# Toil growth

## Purpose

Manual repetitive work increasing

## What to inspect

- Focus component: **Toil Source**
- Connected dependencies: Runbook, Automation Candidate, Ownership
- Validation signals: toil log

## Handy commands

```bash
# Check SLO dashboard
# Calculate burn rate
# Review incident timeline
```

## Relationship descriptions

- 1. Toil growth → Toil Source: 1 symptom maps to focus
- 2. Toil Source → Runbook: 2 inspect dependency
- 3. Toil Source → Automation Candidate: 3 inspect dependency
- 4. Toil Source → Ownership: 4 inspect dependency
- 5. Toil Source → toil log: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
