# Values mismatch

## Purpose

Wrong values produce bad manifests

## What to inspect

- Focus component: **values.yaml**
- Connected dependencies: Template, Release Values, Override Order
- Validation signals: helm template

## Handy commands

```bash
helm lint ./chart
helm template ./chart -f values.yaml
helm status <release> -n <ns>
helm history <release> -n <ns>
```

## Relationship descriptions

- 1. Values mismatch → values.yaml: 1 symptom maps to focus
- 2. values.yaml → Template: 2 inspect dependency
- 3. values.yaml → Release Values: 3 inspect dependency
- 4. values.yaml → Override Order: 4 inspect dependency
- 5. values.yaml → helm template: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
