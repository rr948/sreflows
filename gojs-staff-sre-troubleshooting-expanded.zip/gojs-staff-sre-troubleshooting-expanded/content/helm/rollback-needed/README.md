# Helm rollback needed

## Purpose

Bad release must be rolled back

## What to inspect

- Focus component: **Release Revision**
- Connected dependencies: History, Previous Values, Workload Health
- Validation signals: helm rollback

## Handy commands

```bash
helm lint ./chart
helm template ./chart -f values.yaml
helm status <release> -n <ns>
helm history <release> -n <ns>
```

## Relationship descriptions

- 1. Helm rollback needed → Release Revision: 1 symptom maps to focus
- 2. Release Revision → History: 2 inspect dependency
- 3. Release Revision → Previous Values: 3 inspect dependency
- 4. Release Revision → Workload Health: 4 inspect dependency
- 5. Release Revision → helm rollback: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
