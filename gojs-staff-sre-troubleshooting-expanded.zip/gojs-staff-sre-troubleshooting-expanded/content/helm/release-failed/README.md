# Helm release failed

## Purpose

Install or upgrade fails

## What to inspect

- Focus component: **Helm Release**
- Connected dependencies: Hooks, CRDs, K8s API Error
- Validation signals: helm status

## Handy commands

```bash
helm lint ./chart
helm template ./chart -f values.yaml
helm status <release> -n <ns>
helm history <release> -n <ns>
```

## Relationship descriptions

- 1. Helm release failed → Helm Release: 1 symptom maps to focus
- 2. Helm Release → Hooks: 2 inspect dependency
- 3. Helm Release → CRDs: 3 inspect dependency
- 4. Helm Release → K8s API Error: 4 inspect dependency
- 5. Helm Release → helm status: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
