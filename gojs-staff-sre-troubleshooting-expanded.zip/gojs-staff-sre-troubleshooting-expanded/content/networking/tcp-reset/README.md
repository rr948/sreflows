# TCP reset

## Purpose

Connection reset between services

## What to inspect

- Focus component: **TCP Path**
- Connected dependencies: Listener, Firewall, Application Reset
- Validation signals: tcpdump

## Handy commands

```bash
dig example.com
ip route
ss -tulpen
tcpdump -nn -i any port 443
mtr <host>
```

## Relationship descriptions

- 1. TCP reset → TCP Path: 1 symptom maps to focus
- 2. TCP Path → Listener: 2 inspect dependency
- 3. TCP Path → Firewall: 3 inspect dependency
- 4. TCP Path → Application Reset: 4 inspect dependency
- 5. TCP Path → tcpdump: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
