# DNS timeout

## Purpose

DNS lookup times out

## What to inspect

- Focus component: **DNS Resolver**
- Connected dependencies: Search Domain, Upstream DNS, Firewall
- Validation signals: dig/nslookup

## Handy commands

```bash
dig example.com
ip route
ss -tulpen
tcpdump -nn -i any port 443
mtr <host>
```

## Relationship descriptions

- 1. DNS timeout → DNS Resolver: 1 symptom maps to focus
- 2. DNS Resolver → Search Domain: 2 inspect dependency
- 3. DNS Resolver → Upstream DNS: 3 inspect dependency
- 4. DNS Resolver → Firewall: 4 inspect dependency
- 5. DNS Resolver → dig/nslookup: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
