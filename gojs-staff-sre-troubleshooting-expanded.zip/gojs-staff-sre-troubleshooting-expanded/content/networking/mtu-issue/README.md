# MTU issue

## Purpose

Large packets fail or TLS hangs

## What to inspect

- Focus component: **MTU Path**
- Connected dependencies: Fragmentation, Tunnel, MSS
- Validation signals: ping -M do

## Handy commands

```bash
dig example.com
ip route
ss -tulpen
tcpdump -nn -i any port 443
mtr <host>
```

## Relationship descriptions

- 1. MTU issue → MTU Path: 1 symptom maps to focus
- 2. MTU Path → Fragmentation: 2 inspect dependency
- 3. MTU Path → Tunnel: 3 inspect dependency
- 4. MTU Path → MSS: 4 inspect dependency
- 5. MTU Path → ping -M do: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
