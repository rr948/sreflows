# Packet loss

## Purpose

Intermittent packet loss

## What to inspect

- Focus component: **Network Path**
- Connected dependencies: NIC, Route, Provider
- Validation signals: mtr/tcpdump

## Handy commands

```bash
dig example.com
ip route
ss -tulpen
tcpdump -nn -i any port 443
mtr <host>
```

## Relationship descriptions

- 1. Packet loss → Network Path: 1 symptom maps to focus
- 2. Network Path → NIC: 2 inspect dependency
- 3. Network Path → Route: 3 inspect dependency
- 4. Network Path → Provider: 4 inspect dependency
- 5. Network Path → mtr/tcpdump: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
