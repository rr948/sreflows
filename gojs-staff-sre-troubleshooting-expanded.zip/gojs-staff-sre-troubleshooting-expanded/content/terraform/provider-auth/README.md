# Provider Auth Failure

## Purpose

Cloud provider auth failure

## What to inspect

- Focus component: **Provider Auth**
- Connected dependencies: Credentials, IAM Role, Backend Config
- Validation signals: terraform providers

## Handy commands

```bash
terraform fmt -recursive
terraform validate
terraform plan
terraform state list
terraform plan -refresh-only
```

## Relationship descriptions

- 1. Provider Auth Failure → Provider Auth: 1 symptom maps to focus
- 2. Provider Auth → Credentials: 2 inspect dependency
- 3. Provider Auth → IAM Role: 3 inspect dependency
- 4. Provider Auth → Backend Config: 4 inspect dependency
- 5. Provider Auth → terraform providers: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
