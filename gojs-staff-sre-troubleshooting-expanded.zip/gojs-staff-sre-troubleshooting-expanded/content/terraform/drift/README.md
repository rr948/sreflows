# Infrastructure Drift

## Purpose

Real infra differs from state

## What to inspect

- Focus component: **Drift**
- Connected dependencies: Manual Change, Provider Refresh, State Resource
- Validation signals: refresh-only plan

## Handy commands

```bash
terraform fmt -recursive
terraform validate
terraform plan
terraform state list
terraform plan -refresh-only
```

## Relationship descriptions

- 1. Infrastructure Drift → Drift: 1 symptom maps to focus
- 2. Drift → Manual Change: 2 inspect dependency
- 3. Drift → Provider Refresh: 3 inspect dependency
- 4. Drift → State Resource: 4 inspect dependency
- 5. Drift → refresh-only plan: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
