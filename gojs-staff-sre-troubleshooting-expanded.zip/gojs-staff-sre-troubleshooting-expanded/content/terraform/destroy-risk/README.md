# Unexpected destroy

## Purpose

Plan wants to destroy critical resource

## What to inspect

- Focus component: **Lifecycle Rule**
- Connected dependencies: Resource Address, State Mapping, Module Change
- Validation signals: terraform plan

## Handy commands

```bash
terraform fmt -recursive
terraform validate
terraform plan
terraform state list
terraform plan -refresh-only
```

## Relationship descriptions

- 1. Unexpected destroy → Lifecycle Rule: 1 symptom maps to focus
- 2. Lifecycle Rule → Resource Address: 2 inspect dependency
- 3. Lifecycle Rule → State Mapping: 3 inspect dependency
- 4. Lifecycle Rule → Module Change: 4 inspect dependency
- 5. Lifecycle Rule → terraform plan: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
