# State Lock Stuck

## Purpose

Remote backend lock blocks operations

## What to inspect

- Focus component: **State Lock**
- Connected dependencies: Lock Owner, Remote Backend, Interrupted Apply
- Validation signals: Backend Logs

## Handy commands

```bash
terraform fmt -recursive
terraform validate
terraform plan
terraform state list
terraform plan -refresh-only
```

## Relationship descriptions

- 1. State Lock Stuck → State Lock: 1 symptom maps to focus
- 2. State Lock → Lock Owner: 2 inspect dependency
- 3. State Lock → Remote Backend: 3 inspect dependency
- 4. State Lock → Interrupted Apply: 4 inspect dependency
- 5. State Lock → Backend Logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
