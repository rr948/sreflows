# Module Version Break

## Purpose

Module upgrade breaks plan

## What to inspect

- Focus component: **Module Version**
- Connected dependencies: Inputs, Outputs, Provider Constraint
- Validation signals: terraform plan

## Handy commands

```bash
terraform fmt -recursive
terraform validate
terraform plan
terraform state list
terraform plan -refresh-only
```

## Relationship descriptions

- 1. Module Version Break → Module Version: 1 symptom maps to focus
- 2. Module Version → Inputs: 2 inspect dependency
- 3. Module Version → Outputs: 3 inspect dependency
- 4. Module Version → Provider Constraint: 4 inspect dependency
- 5. Module Version → terraform plan: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
