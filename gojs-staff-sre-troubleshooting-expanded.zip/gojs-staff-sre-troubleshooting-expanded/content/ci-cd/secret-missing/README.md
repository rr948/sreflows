# Pipeline secret missing

## Purpose

Pipeline cannot access secret

## What to inspect

- Focus component: **Secret Store**
- Connected dependencies: Credential ID, Scope, Rotation
- Validation signals: pipeline env

## Handy commands

```bash
git log --oneline -n 10
kubectl rollout history deploy/app
helm history <release>
# check pipeline logs
```

## Relationship descriptions

- 1. Pipeline secret missing → Secret Store: 1 symptom maps to focus
- 2. Secret Store → Credential ID: 2 inspect dependency
- 3. Secret Store → Scope: 3 inspect dependency
- 4. Secret Store → Rotation: 4 inspect dependency
- 5. Secret Store → pipeline env: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
