# Deployment failed

## Purpose

Pipeline deploy stage fails

## What to inspect

- Focus component: **Deployment Stage**
- Connected dependencies: Artifact, Manifest, Cluster Auth
- Validation signals: pipeline logs

## Handy commands

```bash
git log --oneline -n 10
kubectl rollout history deploy/app
helm history <release>
# check pipeline logs
```

## Relationship descriptions

- 1. Deployment failed → Deployment Stage: 1 symptom maps to focus
- 2. Deployment Stage → Artifact: 2 inspect dependency
- 3. Deployment Stage → Manifest: 3 inspect dependency
- 4. Deployment Stage → Cluster Auth: 4 inspect dependency
- 5. Deployment Stage → pipeline logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
