# Artifact missing

## Purpose

Expected artifact not found

## What to inspect

- Focus component: **Artifact Repository**
- Connected dependencies: Build ID, Promotion, Retention
- Validation signals: repo logs

## Handy commands

```bash
git log --oneline -n 10
kubectl rollout history deploy/app
helm history <release>
# check pipeline logs
```

## Relationship descriptions

- 1. Artifact missing → Artifact Repository: 1 symptom maps to focus
- 2. Artifact Repository → Build ID: 2 inspect dependency
- 3. Artifact Repository → Promotion: 3 inspect dependency
- 4. Artifact Repository → Retention: 4 inspect dependency
- 5. Artifact Repository → repo logs: 5 validate evidence

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```

## Prevention ideas

- Add alert or dashboard for this exact failure mode.
- Add runbook ownership.
- Add automation or policy guardrail if the issue repeats.
- Add rollback or safe mitigation path.
