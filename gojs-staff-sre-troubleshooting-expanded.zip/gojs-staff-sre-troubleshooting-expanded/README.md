# GoJS Staff SRE Troubleshooting Handbook - Expanded

## Coverage

- 19 domains/tools
- 89 repeated troubleshooting scenarios
- GoJS nested infrastructure boundaries
- Shared-state highlighting of related nodes and links
- README runbook rendering on the right

## Run

```bash
cd gojs-staff-sre-troubleshooting-expanded
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Tools covered

- Kubernetes
- Linux
- Docker
- Terraform
- AWS
- GCP
- Observability
- Windows
- Bash
- Helm
- ArgoCD
- Jenkins
- SRE Principles
- Vault
- Consul
- Networking
- TLS Certificates
- Databases
- CI/CD
