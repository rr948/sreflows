# GoJS Staff SRE Troubleshooting Handbook

This version combines two GoJS ideas:

- Regrouping-style nested infrastructure boundaries
- Shared-state-style relationship highlighting

## Run

Use a local web server:

```bash
cd gojs-sre-troubleshooting-handbook
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Notes

This uses GoJS from CDN:

```html
<script src="https://cdn.jsdelivr.net/npm/gojs/release/go.js"></script>
```

For offline use, download GoJS and replace the script path with a local file.


## Fixed Version Notes

- Fixed menu/diagram rendering bug caused by using DOM `$()` instead of GoJS `$go()` for `SubGraphExpanderButton`.
- First scenario now loads automatically.
- Added GoJS CDN load guard.
- Expand/collapse buttons now operate on all groups.
