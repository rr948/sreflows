# Container network failure

## Purpose

This runbook covers **Container network failure** under **Docker / Runtime**.

## Symptom

Bridge/DNS/port mapping issue.

## Fast triage

1. Confirm blast radius: one pod/host/pipeline/account, one AZ/zone, or global.
2. Check recent changes: deployment, config, cert, IAM, route, autoscaling, secrets.
3. Follow the diagram from **Symptom → Focus Component → Metrics/Logs/Events**.
4. Mitigate first if user impact is high.
5. Preserve evidence for postmortem.

## Handy commands

```bash
docker ps -a
docker logs <container>
docker inspect <container>
docker stats
docker network ls
docker compose ps
```

## Root cause checklist

- Configuration mismatch
- Resource saturation
- Dependency outage
- IAM/RBAC/policy denial
- Network/DNS/TLS path failure
- Bad rollout or incompatible version
- Capacity or quota limit
- Missing observability or wrong alert threshold

## Staff SRE prevention

- Add SLO or burn-rate alert if user-facing.
- Add dashboard for the exact failure mode.
- Add safe rollback or automated mitigation.
- Add policy guardrail where humans repeatedly make mistakes.
- Add runbook ownership, escalation and test/gameday schedule.

## Interview answer structure

Use this order:

```text
Impact → scope → signals → layer isolation → commands → root cause → mitigation → prevention → platform improvement
```

## Diagram arrow descriptions

- Step 1: Direct focus dependency. Inspect Dependency because it directly affects the focus component.
- Step 2: Direct focus dependency. Inspect Config / Policy because it directly affects the focus component.
- Step 3: Direct focus dependency. Inspect Owner / Runbook because it directly affects the focus component.
- Step 4: Symptom points to suspected layer. Start from the observed symptom and map it to Container network failure.
- Step 5: Recent change correlation. Check whether a deployment, config, IAM, certificate, network, or infrastructure change affected Container network failure.
- Step 6: Metrics validation. Use latency, errors, traffic, saturation, resource, or SLO metrics to validate Container network failure.
- Step 7: Logs and events validation. Use logs, Kubernetes events, audit trails, or pipeline logs to prove behavior around Container network failure.
- Step 8: Direct focus dependency. Inspect Dependency because it directly affects the focus component.
- Step 9: Dependency to Config / Policy. This relationship shows dependency, validation, or control flow.
- Step 10: Config / Policy to Owner / Runbook. This relationship shows dependency, validation, or control flow.
