# Staff SRE Troubleshooting Handbook

## Major design

This version is not a cluttered all-components diagram.

It uses:

- Left hierarchical menu: Domain → Area → Repeated Issue
- Focused diagram per selected issue
- Only required components in the diagram
- Active primary component and dependency lines
- Right-side README.md runbook rendering
- Search across repeated incidents
- Mobile-friendly responsive layout

## Run locally

Markdown files are loaded through `fetch()`, so use a local server:

```bash
cd staff-sre-troubleshooting-handbook
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Edit

- Tree and diagrams: `data/handbook.json`
- UI: `assets/css/base.css`
- Behavior: `assets/js/app.js`
- Runbooks: `content/<domain>/<scenario>/README.md`
