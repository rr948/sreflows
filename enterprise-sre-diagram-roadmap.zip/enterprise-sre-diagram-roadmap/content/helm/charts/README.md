# Charts

## Purpose

This page documents **Charts** for enterprise SRE / DevOps usage.

Use it for:
- Production troubleshooting
- Interview revision
- Runbook creation
- Ownership and handover
- Staff-level architecture discussion

## What it does

`Charts` is part of the **Helm** roadmap. Understand the normal behavior first, then debug symptoms using metrics, logs, events, configuration, and recent changes.

## Handy commands

```bash
# Status / discovery
# Replace placeholders with your real service, namespace, node, account, or project.

# Inspect
# Review logs
# Check events / metrics
# Validate config
```

## Troubleshooting checklist

- Scope: single host, single pod, one AZ/zone, region-wide, or global?
- Impact: user-facing outage, latency, errors, failed deploy, or degraded capacity?
- Recent change: deployment, config, certificate, IAM, network, autoscaling, secret rotation?
- Data: metrics, logs, events, traces, audit records.
- Mitigation: rollback, scale, restart safely, fail over, disable bad dependency.
- Prevention: alert, dashboard, runbook, test, policy, automation.

## SRE interview angle

Explain:
1. Symptom and impact
2. How you isolated the layer
3. Commands and signals used
4. Root cause
5. Immediate mitigation
6. Long-term prevention
7. Trade-offs and ownership model
