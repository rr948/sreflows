# Kubernetes Scheduler

## Purpose

The scheduler assigns Pending Pods to suitable Nodes based on resources, constraints, taints, affinity, topology, and volume constraints.

## Handy commands

```bash
kubectl get pods -A | grep Pending
kubectl describe pod <pod>
kubectl get events -A | grep -i sched
kubectl describe node <node>
kubectl top nodes
```

## Troubleshooting

- Insufficient CPU or memory
- Taints without tolerations
- Node selector mismatch
- Affinity/anti-affinity too strict
- PVC zone mismatch
- Too many pods per node

## Enterprise controls

- Standard requests/limits
- Cluster autoscaler
- Pod priority classes
- Capacity dashboards
- Scheduling failure alerting
