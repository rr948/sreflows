# Service

## Purpose

A Service gives stable networking to Pods. It maps selectors to endpoints and provides virtual IP based service discovery.

## Handy commands

```bash
kubectl get svc,ep,endpointslice -A
kubectl describe svc <svc> -n <ns>
kubectl get pods -n <ns> --show-labels
kubectl run tmp --rm -it --image=busybox -- nslookup <svc>.<ns>.svc.cluster.local
kubectl run tmp --rm -it --image=curlimages/curl -- curl -v http://<svc>.<ns>:<port>
```

## Troubleshooting

- Empty endpoints usually means selector mismatch or pods not ready.
- DNS resolves but connection fails: check port, targetPort, NetworkPolicy.
- Service works inside cluster but not outside: check Ingress/Gateway/LB.

## Enterprise controls

- Naming standards
- Endpoint and DNS dashboards
- NetworkPolicy baseline
- Service ownership labels
