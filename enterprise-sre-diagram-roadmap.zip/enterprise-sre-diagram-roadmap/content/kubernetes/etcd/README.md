# etcd

## Purpose

`etcd` stores Kubernetes cluster state. It is strongly consistent and critical for API Server reliability.

## Handy commands

```bash
kubectl -n kube-system get pods | grep etcd
kubectl -n kube-system logs etcd-<node>
etcdctl endpoint health
etcdctl endpoint status --write-out=table
etcdctl snapshot save backup.db
```

## Troubleshooting

- High etcd latency causes slow Kubernetes API.
- Disk latency is a common root cause.
- Quota/full database can break writes.
- Always validate backup and restore process.

## Enterprise controls

- Scheduled encrypted snapshots
- Restore game days
- Dedicated fast disk
- Alerting on leader changes, fsync latency, DB size, and health
