# Pod

## Purpose

A Pod is the smallest Kubernetes deployable unit. It groups one or more containers, shared network namespace, volumes, probes, and lifecycle settings.

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl logs <pod> -n <ns> --previous
kubectl exec -it <pod> -n <ns> -- sh
kubectl get events -n <ns> --sort-by=.lastTimestamp
```

## Troubleshooting

- CrashLoopBackOff: check previous logs and exit code.
- ImagePullBackOff: check image name, registry auth, tag.
- Pending: check scheduling, PVC, resource pressure.
- Running but not ready: check readiness probe and dependencies.

## Enterprise controls

- Standard probes
- Requests and limits
- SecurityContext
- PodDisruptionBudget
- Structured logs and correlation IDs
