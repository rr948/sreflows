# kubelet

## Purpose

`kubelet` is the node agent. It watches PodSpecs and ensures containers are running through the container runtime.

## Handy commands

```bash
systemctl status kubelet
journalctl -u kubelet -n 200
kubectl describe node <node>
kubectl get pods -A -o wide --field-selector spec.nodeName=<node>
crictl ps -a
crictl logs <container-id>
```

## Troubleshooting

- Node NotReady
- Image pull failure
- CNI failure
- DiskPressure / MemoryPressure
- Container runtime not responding

## Enterprise controls

- Node health alerts
- Graceful drain automation
- Golden AMI/image baseline
- Runtime and kubelet version governance
