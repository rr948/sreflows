# CNI Plugin

## Purpose

The CNI plugin provides pod networking, IP allocation, routing, and often NetworkPolicy enforcement.

## Handy commands

```bash
kubectl get pods -n kube-system -o wide
kubectl logs -n kube-system -l k8s-app=calico-node
kubectl get netpol -A
ip addr
ip route
iptables-save | head
```

## Troubleshooting

- Pod cannot get IP
- Cross-node pod traffic fails
- NetworkPolicy blocks traffic
- IP exhaustion
- MTU mismatch

## Enterprise controls

- IP capacity planning
- NetworkPolicy design
- CNI health alerts
- MTU and route validation
