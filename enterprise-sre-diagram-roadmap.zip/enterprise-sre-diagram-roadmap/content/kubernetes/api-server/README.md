# Kubernetes API Server

## Purpose

The API Server is the front door of Kubernetes. Every `kubectl` request, controller reconciliation, scheduler decision, GitOps sync, and admission policy flows through it.

## Production signals

- API latency
- 5xx response rate
- Admission webhook latency/failures
- Authentication and authorization failures
- etcd request latency

## Handy commands

```bash
kubectl cluster-info
kubectl get --raw=/readyz?verbose
kubectl get --raw=/livez?verbose
kubectl auth can-i get pods --all-namespaces
kubectl get apiservices
kubectl get validatingwebhookconfiguration,mutatingwebhookconfiguration
```

## Troubleshooting

- If `kubectl` is slow, check API server latency and etcd latency.
- If resources cannot be created, check admission webhooks.
- If users get forbidden errors, check RBAC.
- If APIService is unavailable, aggregated APIs may fail.

## Staff-level angle

For enterprise clusters, API Server reliability is a platform dependency. Protect it with admission timeout limits, audited RBAC, API Priority and Fairness, etcd backup strategy, and control-plane SLOs.
