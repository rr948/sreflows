# HPA / Autoscaling

## Purpose

Horizontal Pod Autoscaler scales workloads using CPU, memory, or custom metrics.

## Handy commands

```bash
kubectl get hpa -A
kubectl describe hpa <hpa> -n <ns>
kubectl top pods -n <ns>
kubectl get --raw /apis/metrics.k8s.io/v1beta1/nodes
kubectl logs -n kube-system deploy/metrics-server
```

## Troubleshooting

- Metrics unavailable
- Requests missing
- Scaling too slowly
- Max replicas too low
- Dependency saturation even after scaling

## Enterprise controls

- Autoscaling policies
- Load testing
- SLO-based scaling
- Capacity dashboards
