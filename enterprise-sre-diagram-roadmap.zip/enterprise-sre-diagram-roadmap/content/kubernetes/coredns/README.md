# CoreDNS

## Purpose

CoreDNS provides DNS-based service discovery inside Kubernetes.

## Handy commands

```bash
kubectl -n kube-system get deploy coredns
kubectl -n kube-system logs deploy/coredns
kubectl get configmap coredns -n kube-system -o yaml
kubectl run dns-test --rm -it --image=busybox -- nslookup kubernetes.default
```

## Troubleshooting

- DNS timeout
- Wrong search path
- CoreDNS crashloop
- Upstream DNS failure
- NetworkPolicy blocks DNS

## Enterprise controls

- DNS latency and error alerts
- Autoscale CoreDNS
- Validate upstream DNS
- Protect kube-dns service
