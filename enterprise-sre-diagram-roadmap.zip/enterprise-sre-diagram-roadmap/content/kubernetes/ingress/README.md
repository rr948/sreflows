# Ingress / Gateway

## Purpose

Ingress or Gateway exposes HTTP/HTTPS routes from outside the cluster to Services.

## Handy commands

```bash
kubectl get ingress -A
kubectl describe ingress <name> -n <ns>
kubectl get gateway,httproute -A
kubectl logs -n ingress-nginx deploy/ingress-nginx-controller
curl -vk https://host/path
```

## Troubleshooting

- DNS points to wrong load balancer.
- TLS secret missing or expired.
- Backend service has no endpoints.
- Path or host rule mismatch.
- Ingress controller unhealthy.

## Enterprise controls

- Certificate rotation
- WAF / rate limiting
- Standard gateway classes
- Route ownership and approval
