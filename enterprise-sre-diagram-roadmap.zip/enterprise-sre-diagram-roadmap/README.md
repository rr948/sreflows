# Enterprise SRE Diagram Roadmap

This is an offline, multi-file enterprise SRE/DevOps roadmap portal.

## Features

- Interactive diagram per tool
- Kubernetes architecture diagram with clickable components
- Right-side README.md rendering
- Separate content files under `content/`
- Tool navigation
- Component list view
- Handy commands view
- Search
- Zoom and highlight related components

## Run locally

Because README files are loaded with `fetch()`, open it through a local web server:

```bash
cd enterprise-sre-diagram-roadmap
python -m http.server 8080
```

Then open:

```text
http://localhost:8080
```

## Customize

Edit:

```text
data/roadmap.json
content/<tool>/<component>/README.md
assets/css/base.css
assets/js/app.js
```
