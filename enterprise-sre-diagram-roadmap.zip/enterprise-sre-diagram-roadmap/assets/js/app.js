const state = {
  data: null,
  tool: null,
  selected: null,
  scale: 1,
  view: "diagram",
  query: ""
};

const toolSelect = document.getElementById("toolSelect");
const toolNav = document.getElementById("toolNav");
const toolTitle = document.getElementById("toolTitle");
const toolDescription = document.getElementById("toolDescription");
const diagram = document.getElementById("diagram");
const linkLayer = document.getElementById("linkLayer");
const diagramScaler = document.getElementById("diagramScaler");
const markdownBody = document.getElementById("markdownBody");
const detailsTitle = document.getElementById("detailsTitle");
const detailsBadge = document.getElementById("detailsBadge");
const globalSearch = document.getElementById("globalSearch");
const detailsPanel = document.getElementById("detailsPanel");
const listView = document.getElementById("listView");
const commandsView = document.getElementById("commandsView");
const diagramWrap = document.getElementById("diagramWrap");

async function init() {
  const res = await fetch("data/roadmap.json");
  state.data = await res.json();
  state.tool = state.data.tools[0].id;
  renderToolControls();
  renderAll();
}

function currentTool() {
  return state.data.tools.find(t => t.id === state.tool);
}

function renderToolControls() {
  toolSelect.innerHTML = state.data.tools.map(t => `<option value="${t.id}">${t.name}</option>`).join("");
  toolSelect.value = state.tool;

  toolNav.innerHTML = state.data.tools.map(t => `
    <button class="tool-btn ${state.tool === t.id ? "active" : ""}" onclick="selectTool('${t.id}')">
      <span><strong>${t.name}</strong><small>${t.components.length} components</small></span>
      <small>›</small>
    </button>
  `).join("");
}

function selectTool(id) {
  state.tool = id;
  state.selected = null;
  state.query = "";
  globalSearch.value = "";
  toolSelect.value = id;
  renderToolControls();
  renderAll();
}

toolSelect.addEventListener("change", e => selectTool(e.target.value));

globalSearch.addEventListener("input", e => {
  state.query = e.target.value.toLowerCase().trim();
  renderAll();
});

document.querySelectorAll(".view-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".view-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    state.view = btn.dataset.view;
    renderAll();
  });
});

document.getElementById("zoomInBtn").onclick = () => setScale(state.scale + .1);
document.getElementById("zoomOutBtn").onclick = () => setScale(Math.max(.55, state.scale - .1));
document.getElementById("fitBtn").onclick = () => setScale(.82);
document.getElementById("resetBtn").onclick = () => { state.selected = null; renderAll(); };
document.getElementById("showLinks").onchange = () => renderLinks();
document.getElementById("toggleDetailsBtn").onclick = () => detailsPanel.classList.toggle("open");
document.getElementById("closeDetailsBtn").onclick = () => detailsPanel.classList.remove("open");

function setScale(v) {
  state.scale = Number(v.toFixed(2));
  diagramScaler.style.transform = `scale(${state.scale})`;
}

function renderAll() {
  const t = currentTool();
  toolTitle.textContent = t.name;
  toolDescription.textContent = t.description;

  diagramWrap.classList.toggle("hidden", state.view !== "diagram");
  listView.classList.toggle("hidden", state.view !== "list");
  commandsView.classList.toggle("hidden", state.view !== "commands");

  if (state.view === "diagram") renderDiagram();
  if (state.view === "list") renderList();
  if (state.view === "commands") renderCommands();
}

function filteredComponents() {
  const t = currentTool();
  if (!state.query) return t.components;
  return t.components.filter(c =>
    `${c.title} ${c.summary} ${c.type} ${c.readme}`.toLowerCase().includes(state.query)
  );
}

function renderDiagram() {
  const t = currentTool();
  const visible = new Set(filteredComponents().map(c => c.id));

  diagram.innerHTML = "";

  for (const g of t.groups || []) {
    const el = document.createElement("div");
    el.className = "group";
    el.style.left = g.x + "px";
    el.style.top = g.y + "px";
    el.style.width = g.w + "px";
    el.style.height = g.h + "px";
    el.innerHTML = `<div class="group-title">${g.title}</div>`;
    diagram.appendChild(el);
  }

  for (const c of t.components) {
    const el = document.createElement("div");
    const isVisible = visible.has(c.id);
    const isConnected = !state.selected || isRelated(c.id);
    el.className = `component ${state.selected === c.id ? "selected" : ""} ${(!isVisible || !isConnected) ? "dimmed" : ""}`;
    el.style.left = c.x + "px";
    el.style.top = c.y + "px";
    el.style.width = (c.w || 170) + "px";
    el.style.height = (c.h || 82) + "px";
    el.dataset.id = c.id;
    el.innerHTML = `
      <span class="type-chip type-${c.type}">${c.type}</span>
      <h3>${c.title}</h3>
      <p>${c.summary}</p>
    `;
    el.onclick = () => selectComponent(c.id);
    diagram.appendChild(el);
  }

  renderLinks();
}

function renderLinks() {
  const t = currentTool();
  const show = document.getElementById("showLinks").checked;
  if (!show) {
    linkLayer.innerHTML = "";
    return;
  }
  const byId = Object.fromEntries(t.components.map(c => [c.id, c]));
  linkLayer.innerHTML = `
    <defs>
      <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M 0 0 L 10 5 L 0 10 z" fill="rgba(148,163,184,.65)"></path>
      </marker>
    </defs>
  `;
  for (const [from, to] of (t.links || [])) {
    const a = byId[from], b = byId[to];
    if (!a || !b) continue;

    const x1 = a.x + (a.w || 170);
    const y1 = a.y + ((a.h || 82) / 2);
    const x2 = b.x;
    const y2 = b.y + ((b.h || 82) / 2);
    const mid = Math.max(40, Math.abs(x2 - x1) / 2);
    const d = `M ${x1} ${y1} C ${x1 + mid} ${y1}, ${x2 - mid} ${y2}, ${x2} ${y2}`;

    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    const active = state.selected && (state.selected === from || state.selected === to);
    path.setAttribute("d", d);
    path.setAttribute("marker-end", "url(#arrow)");
    path.setAttribute("class", `link ${active ? "active" : ""} ${state.selected && !active ? "dimmed" : ""}`);
    linkLayer.appendChild(path);
  }
}

function isRelated(id) {
  const t = currentTool();
  if (id === state.selected) return true;
  return (t.links || []).some(([a,b]) => (a === state.selected && b === id) || (b === state.selected && a === id));
}

async function selectComponent(id) {
  state.selected = id;
  const t = currentTool();
  const c = t.components.find(x => x.id === id);
  detailsPanel.classList.add("open");
  detailsTitle.textContent = c.title;
  detailsBadge.textContent = `${t.name} / README.md`;
  markdownBody.innerHTML = `<p>Loading ${c.readme}...</p>`;
  renderAll();

  try {
    const res = await fetch(c.readme);
    if (!res.ok) throw new Error("README not found");
    const md = await res.text();
    markdownBody.innerHTML = markdownToHtml(md);
  } catch (e) {
    markdownBody.innerHTML = `<h1>${c.title}</h1><p>README file not found: <code>${c.readme}</code></p>`;
  }
}

function renderList() {
  const t = currentTool();
  listView.innerHTML = `
    <h2>${t.name} Components</h2>
    <div class="component-list">
      ${filteredComponents().map(c => `
        <div class="list-card" onclick="selectComponent('${c.id}')">
          <span class="type-chip type-${c.type}">${c.type}</span>
          <h3>${c.title}</h3>
          <p>${c.summary}</p>
          <small>${c.readme}</small>
        </div>
      `).join("")}
    </div>
  `;
}

function renderCommands() {
  const t = currentTool();
  commandsView.innerHTML = `
    <h2>${t.name} Handy Commands</h2>
    <div class="markdown">
      ${t.components.map(c => `
        <h3>${c.title}</h3>
        <pre><code>${commandFor(t.id, c.id)}</code></pre>
      `).join("")}
    </div>
  `;
}

function commandFor(tool, component) {
  const map = {
    kubernetes: {
      "api-server": "kubectl cluster-info\nkubectl get --raw=/readyz?verbose\nkubectl auth can-i get pods --all-namespaces",
      "etcd": "kubectl -n kube-system get pods | grep etcd\nkubectl -n kube-system logs etcd-<node>\netcdctl endpoint health",
      "scheduler": "kubectl -n kube-system logs -l component=kube-scheduler\nkubectl get events -A | grep -i sched",
      "kubelet": "systemctl status kubelet\njournalctl -u kubelet -n 200\nkubectl describe node <node>",
      "pod": "kubectl get pods -A -o wide\nkubectl describe pod <pod>\nkubectl logs <pod> --previous",
      "service": "kubectl get svc,ep,endpointslice -A\nkubectl describe svc <svc>\nkubectl run tmp --rm -it --image=busybox -- nslookup <svc>"
    },
    terraform: {
      "state": "terraform state list\nterraform plan -refresh-only\nterraform import <addr> <id>",
      "modules": "terraform init\nterraform get -update\nterraform graph"
    },
    linux: {
      "process": "ps -ef\ntop -H\nstrace -p <pid>",
      "memory": "free -m\nvmstat 1\ndmesg | grep -i oom",
      "network": "ip addr\nip route\nss -tulpen\ntcpdump -nn -i any port 443"
    }
  };
  return (map[tool] && map[tool][component]) || defaultCommand(tool, component);
}

function defaultCommand(tool, component) {
  return `# ${tool} / ${component}\n# Add your enterprise runbook commands here.\n# Example:\n# check status\n# inspect configuration\n# review logs\n# validate metrics\n# rollback or remediate safely`;
}

function markdownToHtml(md) {
  let html = md
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  html = html.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code.trim()}</code></pre>`);
  html = html.replace(/^### (.*)$/gm, "<h3>$1</h3>");
  html = html.replace(/^## (.*)$/gm, "<h2>$1</h2>");
  html = html.replace(/^# (.*)$/gm, "<h1>$1</h1>");
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
  html = html.replace(/^\- (.*)$/gm, "<li>$1</li>");
  html = html.replace(/(<li>.*<\/li>\n?)+/g, match => `<ul>${match}</ul>`);
  html = html.replace(/\n\n/g, "</p><p>");
  return `<p>${html}</p>`.replace(/<p><h/g, "<h").replace(/<\/h([123])><\/p>/g, "</h$1>");
}

init();
