# Service

## Purpose

A Service provides stable virtual networking to Pods.

## Handy commands

```bash
kubectl get svc,ep,endpointslice -A
kubectl describe svc <svc> -n <ns>
kubectl get pods -n <ns> --show-labels
kubectl run tmp --rm -it --image=busybox -- nslookup <svc>.<ns>.svc.cluster.local
```

## Troubleshooting

- Empty endpoints mean selector mismatch or pods not ready.
- DNS resolves but connection fails: check targetPort and NetworkPolicy.
- External traffic issue: check Ingress/Gateway/LB.
