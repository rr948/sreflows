# Pod

## Purpose

A Pod is the smallest deployable unit in Kubernetes.

## Handy commands

```bash
kubectl get pods -A -o wide
kubectl describe pod <pod> -n <ns>
kubectl logs <pod> -n <ns> --previous
kubectl exec -it <pod> -n <ns> -- sh
```

## Troubleshooting

- CrashLoopBackOff: check previous logs and exit code.
- ImagePullBackOff: check registry, tag and secret.
- Pending: check scheduling, PVC and resources.
- Running not ready: check readiness probe and dependencies.
