# etcd

## Purpose

etcd stores Kubernetes cluster state and is critical for API reliability.

## Handy commands

```bash
kubectl -n kube-system get pods | grep etcd
kubectl -n kube-system logs etcd-<node>
etcdctl endpoint health
etcdctl endpoint status --write-out=table
etcdctl snapshot save backup.db
```

## Troubleshooting

- Watch disk latency and fsync duration.
- Check leader changes.
- Check DB size and quota.
- Validate snapshot restore process.
