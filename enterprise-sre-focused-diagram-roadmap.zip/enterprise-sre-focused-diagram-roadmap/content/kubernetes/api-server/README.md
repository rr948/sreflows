# API Server

## Purpose

The Kubernetes API Server is the front door for cluster operations.

## Handy commands

```bash
kubectl cluster-info
kubectl get --raw=/readyz?verbose
kubectl get --raw=/livez?verbose
kubectl auth can-i get pods --all-namespaces
kubectl get apiservices
kubectl get validatingwebhookconfiguration,mutatingwebhookconfiguration
```

## Troubleshooting

- Check API latency and 5xx errors.
- Check admission webhook timeout/failure.
- Check RBAC for forbidden errors.
- Check etcd latency if all API calls are slow.

## Enterprise guardrails

- Admission timeout standards.
- RBAC least privilege.
- API Priority and Fairness.
- Control-plane SLO dashboard.
