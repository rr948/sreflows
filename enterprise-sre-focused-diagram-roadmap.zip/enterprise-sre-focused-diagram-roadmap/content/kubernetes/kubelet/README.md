# kubelet

## Purpose

kubelet is the node agent that manages pod lifecycle.

## Handy commands

```bash
systemctl status kubelet
journalctl -u kubelet -n 200
kubectl describe node <node>
crictl ps -a
crictl logs <container-id>
```

## Troubleshooting

- Node NotReady.
- Runtime unavailable.
- CNI setup failure.
- DiskPressure or MemoryPressure.
