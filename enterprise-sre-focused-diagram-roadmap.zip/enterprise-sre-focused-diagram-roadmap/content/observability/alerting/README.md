# Alerting

## Purpose

This README is rendered when you click **Alerting** in the focused enterprise diagram.

## Production focus

- Understand normal behavior.
- Check dependencies connected to this component.
- Validate recent changes.
- Use metrics, logs, events, traces and configuration.
- Mitigate safely before deep root cause analysis.

## Handy commands

```bash
# Discovery
kubectl get all -A

# Describe / events
kubectl describe <resource> <name> -n <namespace>
kubectl get events -A --sort-by=.lastTimestamp

# Logs
kubectl logs <pod> -n <namespace> --previous

# Connectivity
kubectl run debug --rm -it --image=curlimages/curl -- sh
```

## Troubleshooting checklist

- Scope: namespace, node, cluster, zone, region.
- Symptom: latency, error, failed deployment, DNS, scheduling, storage, auth.
- Layer: app, service, ingress, pod, node, CNI, control plane, cloud.
- Mitigation: rollback, scale, restart safely, fail over, disable bad dependency.
- Prevention: alert, dashboard, policy, test, automation, runbook.

## Staff-level interview angle

Explain impact, signals, isolation logic, commands, root cause, mitigation, prevention, and platform guardrails.
