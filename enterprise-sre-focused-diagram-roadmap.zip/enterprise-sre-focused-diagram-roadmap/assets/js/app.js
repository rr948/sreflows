const state = {
  data: null,
  toolId: "kubernetes",
  expandedAreaId: null,
  selectedId: null,
  mode: "overview",
  scale: 1,
  query: ""
};

const $ = id => document.getElementById(id);
const toolSelect = $("toolSelect");
const toolNav = $("toolNav");
const areaNav = $("areaNav");
const toolTitle = $("toolTitle");
const toolDescription = $("toolDescription");
const nodeLayer = $("nodeLayer");
const linkLayer = $("linkLayer");
const diagramStage = $("diagramStage");
const markdown = $("markdown");
const detailsTitle = $("detailsTitle");
const readmePath = $("readmePath");
const detailsPanel = $("detailsPanel");
const searchBox = $("searchBox");
const modeBadge = $("modeBadge");

async function init() {
  const res = await fetch("data/roadmap.json");
  state.data = await res.json();
  state.expandedAreaId = currentTool().areas[0].id;
  renderControls();
  render();
}

function currentTool() {
  return state.data.tools.find(t => t.id === state.toolId);
}

function allComponents(tool=currentTool()) {
  const map = new Map();
  for (const area of tool.areas) {
    for (const c of area.components) {
      if (!map.has(c.id)) map.set(c.id, {...c, areaId: area.id});
    }
  }
  return [...map.values()];
}

function componentById(id) {
  return allComponents().find(c => c.id === id);
}

function currentArea() {
  return currentTool().areas.find(a => a.id === state.expandedAreaId);
}

function renderControls() {
  const tools = state.data.tools;
  toolSelect.innerHTML = tools.map(t => `<option value="${t.id}">${t.name}</option>`).join("");
  toolSelect.value = state.toolId;
  toolNav.innerHTML = tools.map(t => `
    <button class="nav-btn ${state.toolId === t.id ? "active" : ""}" onclick="selectTool('${t.id}')">
      <span><strong>${t.name}</strong><small>${componentCount(t)} components</small></span>
      <small>›</small>
    </button>
  `).join("");
  renderAreaNav();
}

function componentCount(tool) {
  return allComponents(tool).length;
}

function renderAreaNav() {
  const tool = currentTool();
  areaNav.innerHTML = tool.areas.map(a => `
    <button class="area-btn ${state.expandedAreaId === a.id ? "active" : ""}" onclick="expandArea('${a.id}')">
      <span><strong>${a.title}</strong><small>${a.summary}</small></span>
      <small>${a.components.length}</small>
    </button>
  `).join("");
}

function selectTool(id) {
  state.toolId = id;
  const tool = currentTool();
  state.expandedAreaId = tool.areas[0].id;
  state.selectedId = null;
  state.mode = "overview";
  state.query = "";
  searchBox.value = "";
  toolSelect.value = id;
  renderControls();
  setModeButton("overview");
  render();
}

function expandArea(id) {
  state.expandedAreaId = id;
  state.selectedId = null;
  state.mode = "overview";
  setModeButton("overview");
  renderAreaNav();
  render();
}

toolSelect.addEventListener("change", e => selectTool(e.target.value));
searchBox.addEventListener("input", e => {
  state.query = e.target.value.toLowerCase().trim();
  render();
});

$("overviewBtn").onclick = () => setMode("overview");
$("focusBtn").onclick = () => setMode("focus");
$("neighborsBtn").onclick = () => setMode("neighbors");
$("resetBtn").onclick = () => {
  state.selectedId = null;
  state.mode = "overview";
  setModeButton("overview");
  render();
};
$("fitBtn").onclick = () => setScale(.86);
$("zoomInBtn").onclick = () => setScale(state.scale + .1);
$("zoomOutBtn").onclick = () => setScale(Math.max(.55, state.scale - .1));
$("animatedLines").onchange = () => render();
$("detailsToggle").onclick = () => detailsPanel.classList.toggle("open");
$("closeDetails").onclick = () => detailsPanel.classList.remove("open");

function setMode(mode) {
  state.mode = mode;
  setModeButton(mode);
  render();
}

function setModeButton(mode) {
  document.querySelectorAll(".mode").forEach(b => b.classList.remove("active"));
  const btn = mode === "overview" ? $("overviewBtn") : mode === "focus" ? $("focusBtn") : $("neighborsBtn");
  btn.classList.add("active");
}

function setScale(v) {
  state.scale = Number(v.toFixed(2));
  diagramStage.style.transform = `scale(${state.scale})`;
}

function visibleExpandedComponents() {
  const area = currentArea();
  const q = state.query;
  if (!q) return area.components;
  return area.components.filter(c => `${c.title} ${c.summary} ${c.type}`.toLowerCase().includes(q));
}

function connectedIds(id) {
  const ids = new Set([id]);
  for (const [a,b] of currentTool().links) {
    if (a === id) ids.add(b);
    if (b === id) ids.add(a);
  }
  return ids;
}

function render() {
  const tool = currentTool();
  toolTitle.textContent = tool.name;
  toolDescription.textContent = tool.description;
  modeBadge.textContent = state.mode === "overview" ? "Overview: one area expanded" :
    state.mode === "focus" ? "Focus: selected component emphasized" : "Connected only";
  renderAreaNav();
  renderNodes();
  renderLinks();
}

function renderNodes() {
  const tool = currentTool();
  nodeLayer.innerHTML = "";

  if (state.mode === "overview" && !state.selectedId) {
    renderOverview();
    return;
  }

  renderFocusedArea();
}

function renderOverview() {
  const tool = currentTool();
  const expanded = currentArea();

  for (const area of tool.areas) {
    if (area.id !== expanded.id) {
      const pos = area.collapsed;
      const el = document.createElement("div");
      el.className = "area-card";
      el.style.left = pos.x + "px";
      el.style.top = pos.y + "px";
      el.style.width = pos.w + "px";
      el.style.height = pos.h + "px";
      el.innerHTML = `
        <span class="badge">Collapsed</span>
        <h3>${area.title}</h3>
        <p>${area.summary}</p>
        <div class="count">${area.components.length} subcomponents · click to expand</div>
      `;
      el.onclick = () => expandArea(area.id);
      nodeLayer.appendChild(el);
    }
  }

  addGroup(expanded);
  for (const c of visibleExpandedComponents()) addComponent(c, "normal");
}

function renderFocusedArea() {
  const expanded = currentArea();
  addGroup(expanded);

  const focusSet = state.selectedId ? connectedIds(state.selectedId) : null;

  for (const c of expanded.components) {
    const qMatch = !state.query || `${c.title} ${c.summary} ${c.type}`.toLowerCase().includes(state.query);
    if (!qMatch) continue;

    let cls = "normal";
    if (state.selectedId) {
      if (c.id === state.selectedId) cls = "focus-primary";
      else if (focusSet.has(c.id)) cls = "related";
      else if (state.mode === "neighbors") cls = "hidden-node";
      else cls = "dimmed";
    }
    addComponent(c, cls);
  }

  // show connected components from other areas only when selected
  if (state.selectedId) {
    const related = connectedIds(state.selectedId);
    const currentIds = new Set(expanded.components.map(c => c.id));
    for (const c of allComponents()) {
      if (currentIds.has(c.id)) continue;
      if (!related.has(c.id)) continue;
      const copy = {...c};
      const idx = [...related].indexOf(c.id);
      copy.x = 930;
      copy.y = 110 + idx * 120;
      copy.w = copy.w || 180;
      copy.h = copy.h || 88;
      addComponent(copy, "related");
    }
  }
}

function addGroup(area) {
  const g = area.group;
  const el = document.createElement("div");
  el.className = "group-box";
  el.style.left = g.x + "px";
  el.style.top = g.y + "px";
  el.style.width = g.w + "px";
  el.style.height = g.h + "px";
  el.innerHTML = `<div class="group-title">${area.title}</div>`;
  nodeLayer.appendChild(el);
}

function addComponent(c, extraClass) {
  const el = document.createElement("div");
  el.className = `component ${extraClass || ""} ${state.selectedId === c.id ? "selected" : ""}`;
  el.style.left = c.x + "px";
  el.style.top = c.y + "px";
  el.style.width = (c.w || 170) + "px";
  el.style.height = (c.h || 86) + "px";
  el.innerHTML = `
    <span class="type-chip type-${c.type}">${c.type}</span>
    <h3>${c.title}</h3>
    <p>${c.summary}</p>
  `;
  el.onclick = () => selectComponent(c.id);
  nodeLayer.appendChild(el);
}

function renderLinks() {
  const tool = currentTool();
  linkLayer.innerHTML = `
    <defs>
      <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M 0 0 L 10 5 L 0 10 z" fill="rgba(148,163,184,.75)"></path>
      </marker>
    </defs>
  `;

  const visible = visibleNodePositions();
  const animated = $("animatedLines").checked;

  for (const [from,to] of tool.links) {
    const a = visible[from], b = visible[to];
    if (!a || !b) continue;

    let cls = "link";
    if (state.selectedId) {
      const active = from === state.selectedId || to === state.selectedId;
      const related = connectedIds(state.selectedId).has(from) && connectedIds(state.selectedId).has(to);
      if (active) cls += " active";
      else if (related && state.mode !== "neighbors") cls += " related";
      else if (state.mode === "neighbors") cls += " hidden-link";
      else cls += " dimmed";
      if (active && animated) cls += " animated";
    } else if (state.mode !== "overview") {
      cls += " dimmed";
    }

    const path = makePath(a,b);
    path.setAttribute("class", cls);
    linkLayer.appendChild(path);
  }
}

function visibleNodePositions() {
  const map = {};
  document.querySelectorAll(".component:not(.hidden-node)").forEach(el => {
    const title = el.querySelector("h3").textContent;
    const c = allComponents().find(x => x.title === title);
    if (!c) return;
    map[c.id] = {
      x: parseFloat(el.style.left),
      y: parseFloat(el.style.top),
      w: parseFloat(el.style.width),
      h: parseFloat(el.style.height)
    };
  });
  return map;
}

function makePath(a,b) {
  const x1 = a.x + a.w;
  const y1 = a.y + a.h/2;
  const x2 = b.x;
  const y2 = b.y + b.h/2;
  const mid = Math.max(50, Math.abs(x2-x1)/2);
  const d = `M ${x1} ${y1} C ${x1+mid} ${y1}, ${x2-mid} ${y2}, ${x2} ${y2}`;
  const path = document.createElementNS("http://www.w3.org/2000/svg","path");
  path.setAttribute("d", d);
  path.setAttribute("marker-end", "url(#arrow)");
  return path;
}

async function selectComponent(id) {
  state.selectedId = id;
  if (state.mode === "overview") {
    state.mode = "focus";
    setModeButton("focus");
  }

  const c = componentById(id);
  if (!c) return;
  detailsPanel.classList.add("open");
  detailsTitle.textContent = c.title;
  readmePath.textContent = c.readme;
  markdown.innerHTML = `<p>Loading <code>${c.readme}</code>...</p>`;
  render();

  try {
    const res = await fetch(c.readme);
    if (!res.ok) throw new Error("not found");
    const md = await res.text();
    markdown.innerHTML = markdownToHtml(md);
  } catch (e) {
    markdown.innerHTML = `<h1>${c.title}</h1><p>README not found: <code>${c.readme}</code></p>`;
  }
}

function markdownToHtml(md) {
  let html = md.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  html = html.replace(/```([\\s\\S]*?)```/g, (_,code)=>`<pre><code>${code.trim()}</code></pre>`);
  html = html.replace(/^### (.*)$/gm,"<h3>$1</h3>");
  html = html.replace(/^## (.*)$/gm,"<h2>$1</h2>");
  html = html.replace(/^# (.*)$/gm,"<h1>$1</h1>");
  html = html.replace(/`([^`]+)`/g,"<code>$1</code>");
  html = html.replace(/^- (.*)$/gm,"<li>$1</li>");
  html = html.replace(/(<li>.*<\/li>\n?)+/g,m=>`<ul>${m}</ul>`);
  html = html.replace(/\n\n/g,"</p><p>");
  return `<p>${html}</p>`.replace(/<p><h/g,"<h").replace(/<\/h([123])><\/p>/g,"</h$1>");
}

init();
