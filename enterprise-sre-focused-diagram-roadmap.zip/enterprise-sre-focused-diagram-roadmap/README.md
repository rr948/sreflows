# Enterprise Focused Diagram Roadmap

## What changed

- Diagram no longer clutters all components.
- Only one major area expands at a time.
- Other major areas collapse into summary cards.
- Selecting a component highlights it strongly.
- Only connected components and required links stay active.
- Connected-only mode hides unrelated components and links.
- README.md renders on the right side.

## Run locally

```bash
cd enterprise-sre-focused-diagram-roadmap
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Edit content

- Diagram/data: `data/roadmap.json`
- UI behavior: `assets/js/app.js`
- Styling: `assets/css/base.css`
- Markdown pages: `content/<tool>/<component>/README.md`
