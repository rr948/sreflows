# MTU Issue

## Purpose

Large packets fail or TLS hangs

## Real flow

- 1. TLS Hang → MTU Path
- 2. MTU Path → Fragmentation
- 3. MTU Path → Tunnel
- 4. MTU Path → MSS
- 5. MTU Path → ping -M do

## Handy commands

```bash
# Add or customize commands for Networking / MTU Issue
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
