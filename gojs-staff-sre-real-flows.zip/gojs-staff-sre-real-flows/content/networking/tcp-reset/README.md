# TCP Reset

## Purpose

Connection reset between services

## Real flow

- 1. Connection Reset → TCP Flow
- 2. TCP Flow → Listener
- 3. TCP Flow → Firewall
- 4. TCP Flow → App Reset
- 5. TCP Flow → tcpdump

## Handy commands

```bash
# Add or customize commands for Networking / TCP Reset
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
