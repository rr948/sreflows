# Incomplete Chain

## Purpose

Missing intermediate cert

## Real flow

- 1. Verify Failed → Chain Bundle
- 2. Chain Bundle → Intermediate
- 3. Chain Bundle → Root CA
- 4. Chain Bundle → Server Bundle
- 5. Chain Bundle → openssl verify

## Handy commands

```bash
# Add or customize commands for TLS Certificates / Incomplete Chain
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
