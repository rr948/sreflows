# Certificate Expired

## Purpose

TLS cert expired/untrusted

## Real flow

- 1. TLS Error → Leaf Certificate
- 2. Leaf Certificate → Issuer
- 3. Leaf Certificate → SAN
- 4. Leaf Certificate → Trust Store
- 5. Leaf Certificate → openssl s_client

## Handy commands

```bash
# Add or customize commands for TLS Certificates / Certificate Expired
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
