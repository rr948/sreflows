# DNS Resolution Failure

## Purpose

Pod cannot resolve service or external DNS.

## Real flow

- 1. Source Pod → /etc/resolv.conf
- 2. /etc/resolv.conf → kube-dns Service
- 3. kube-dns Service → CoreDNS Pods
- 4. CoreDNS Pods → CoreDNS ConfigMap
- 5. CoreDNS Pods → Upstream DNS
- 6. Source Pod → NetworkPolicy UDP/TCP 53
- 7. CoreDNS Pods → CoreDNS Logs

## Handy commands

```bash
# Add or customize commands for Kubernetes / DNS Resolution Failure
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
