# Service has no endpoints

## Purpose

Service exists but has no backend pods.

## Real flow

- 1. Service → Selector
- 2. Selector → Pod Labels
- 3. Pod Labels → Ready Pods
- 4. Readiness Probe → Ready Pods
- 5. Ready Pods → EndpointSlice
- 6. EndpointSlice → Service

## Handy commands

```bash
# Add or customize commands for Kubernetes / Service has no endpoints
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
