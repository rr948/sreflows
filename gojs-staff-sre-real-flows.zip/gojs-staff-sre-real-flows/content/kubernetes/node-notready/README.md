# Node NotReady

## Purpose

Node health is degraded or disconnected.

## Real flow

- 1. Node Condition NotReady → kubelet
- 2. kubelet → containerd / CRI-O
- 3. kubelet → CNI Plugin
- 4. kubelet → DiskPressure / ImageFS
- 5. kubelet → MemoryPressure
- 6. kubelet → kubelet journal

## Handy commands

```bash
# Add or customize commands for Kubernetes / Node NotReady
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
