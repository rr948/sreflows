# PVC Pending

## Purpose

PVC cannot bind to a persistent volume.

## Real flow

- 1. Pod needing volume → PVC
- 2. PVC → StorageClass
- 3. StorageClass → CSI Controller
- 4. CSI Controller → PV
- 5. PV → PVC
- 6. PVC → Zone / Node Affinity
- 7. PVC → PVC Events

## Handy commands

```bash
# Add or customize commands for Kubernetes / PVC Pending
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
