# CrashLoopBackOff

## Purpose

Container repeatedly exits and pod restarts.

## Real flow

- 1. Deployment → ReplicaSet
- 2. ReplicaSet → Pod
- 3. Pod → Container
- 4. Container → Previous Logs
- 5. Container → Liveness / Startup Probe
- 6. Container → ConfigMap / Secret / Env
- 7. Container → Container Runtime
- 8. Pod → Events

## Handy commands

```bash
# Add or customize commands for Kubernetes / CrashLoopBackOff
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
