# High CPU

## Purpose

Host or process CPU saturation.

## Real flow

- 1. CPU Alert → Top Process / Thread
- 2. Top Process / Thread → Run Queue
- 3. Top Process / Thread → Syscalls / strace
- 4. Top Process / Thread → perf top
- 5. Top Process / Thread → Container / cgroup

## Handy commands

```bash
# Add or customize commands for Linux / High CPU
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
