# Network Timeout

## Purpose

Routing, DNS, firewall or packet path issue.

## Real flow

- 1. Application Timeout → DNS Resolver
- 2. DNS Resolver → Route Table
- 3. Route Table → Local / Remote Port
- 4. Local / Remote Port → Firewall
- 5. Local / Remote Port → Packet Capture

## Handy commands

```bash
# Add or customize commands for Linux / Network Timeout
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
