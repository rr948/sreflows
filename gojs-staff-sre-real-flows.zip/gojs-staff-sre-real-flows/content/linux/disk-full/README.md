# Disk or inode full

## Purpose

Filesystem capacity or inode exhaustion.

## Real flow

- 1. Disk Alert → Mount Point
- 2. Mount Point → Large Directories
- 3. Mount Point → Inodes
- 4. Log Growth → Mount Point
- 5. Log Growth → Logrotate / Cleanup

## Handy commands

```bash
# Add or customize commands for Linux / Disk or inode full
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
