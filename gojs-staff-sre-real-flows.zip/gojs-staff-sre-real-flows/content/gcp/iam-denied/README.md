# GCP IAM Denied

## Purpose

Service account permission issue

## Real flow

- 1. PERMISSION_DENIED → Service Account
- 2. Service Account → Role Binding
- 3. Service Account → Org Policy
- 4. Service Account → Resource IAM
- 5. Service Account → Audit Logs

## Handy commands

```bash
# Add or customize commands for Gcp / GCP IAM Denied
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
