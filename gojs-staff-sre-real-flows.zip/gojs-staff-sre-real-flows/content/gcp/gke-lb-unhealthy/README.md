# GKE LB Unhealthy

## Purpose

Backend NEG or health check issue

## Real flow

- 1. HTTP 5xx → Backend Service
- 2. Backend Service → NEG
- 3. Backend Service → Health Check
- 4. Backend Service → Pod Readiness
- 5. Backend Service → Cloud Logging

## Handy commands

```bash
# Add or customize commands for Gcp / GKE LB Unhealthy
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
