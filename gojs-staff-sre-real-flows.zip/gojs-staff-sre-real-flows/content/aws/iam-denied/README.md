# IAM AccessDenied

## Purpose

AWS API call denied by IAM/SCP/boundary.

## Real flow

- 1. AccessDenied → Principal / Role
- 2. Principal / Role → Identity Policy
- 3. Principal / Role → Resource Policy
- 4. Principal / Role → SCP / Boundary
- 5. Principal / Role → CloudTrail

## Handy commands

```bash
# Add or customize commands for AWS / IAM AccessDenied
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
