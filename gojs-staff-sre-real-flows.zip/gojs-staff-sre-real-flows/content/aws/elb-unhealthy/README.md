# ELB unhealthy targets

## Purpose

Load balancer cannot route to backend targets.

## Real flow

- 1. Client 5xx → ALB / NLB
- 2. ALB / NLB → Target Group
- 3. Target Group → Health Check
- 4. Health Check → EC2 / Pod Target
- 5. Security Group → EC2 / Pod Target
- 6. ALB / NLB → CloudWatch Metrics

## Handy commands

```bash
# Add or customize commands for AWS / ELB unhealthy targets
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
