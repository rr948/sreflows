# Vault Sealed

## Purpose

Vault clients fail because sealed

## Real flow

- 1. 503 Sealed → Seal State
- 2. Seal State → Unseal Keys
- 3. Seal State → Auto-unseal
- 4. Seal State → Storage Backend
- 5. Seal State → vault status

## Handy commands

```bash
# Add or customize commands for Vault / Vault Sealed
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
