# Token Denied

## Purpose

Vault token lacks policy/expired

## Real flow

- 1. permission denied → Token
- 2. Token → Policy
- 3. Token → TTL
- 4. Token → Auth Method
- 5. Token → vault token lookup

## Handy commands

```bash
# Add or customize commands for Vault / Token Denied
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
