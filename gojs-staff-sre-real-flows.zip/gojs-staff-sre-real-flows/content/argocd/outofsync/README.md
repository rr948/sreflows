# Application OutOfSync

## Purpose

Git desired state differs from live

## Real flow

- 1. OutOfSync → Application Diff
- 2. Application Diff → Git Revision
- 3. Application Diff → Live State
- 4. Application Diff → Ignore Rules
- 5. Application Diff → argocd app diff

## Handy commands

```bash
# Add or customize commands for Argocd / Application OutOfSync
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
