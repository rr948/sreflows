# Sync Failed

## Purpose

ArgoCD cannot apply manifests

## Real flow

- 1. Sync Error → Sync Task
- 2. Sync Task → RBAC
- 3. Sync Task → Webhook
- 4. Sync Task → API Error
- 5. Sync Task → argocd app get

## Handy commands

```bash
# Add or customize commands for Argocd / Sync Failed
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
