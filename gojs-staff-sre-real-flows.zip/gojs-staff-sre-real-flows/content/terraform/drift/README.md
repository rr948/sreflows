# Infrastructure Drift

## Purpose

Real infrastructure differs from Terraform state.

## Real flow

- 1. Unexpected Plan → Terraform State
- 2. Terraform State → Actual Resource
- 3. Actual Resource → Manual Change
- 4. Terraform State → refresh-only Plan

## Handy commands

```bash
# Add or customize commands for Terraform / Infrastructure Drift
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
