# State Lock Stuck

## Purpose

Remote backend lock blocks Terraform operations.

## Real flow

- 1. terraform apply blocked → State Lock
- 2. State Lock → Lock Owner
- 3. State Lock → State Object
- 4. State Lock → Backend Audit Logs

## Handy commands

```bash
# Add or customize commands for Terraform / State Lock Stuck
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
