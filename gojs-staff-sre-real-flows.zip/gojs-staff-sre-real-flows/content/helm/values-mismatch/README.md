# Values Mismatch

## Purpose

Rendered manifest has wrong values

## Real flow

- 1. Bad Deployment → values.yaml
- 2. values.yaml → Template
- 3. values.yaml → Override Order
- 4. values.yaml → Release Values
- 5. values.yaml → helm template

## Handy commands

```bash
# Add or customize commands for Helm / Values Mismatch
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
