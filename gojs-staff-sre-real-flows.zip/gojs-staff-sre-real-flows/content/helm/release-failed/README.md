# Release Failed

## Purpose

Helm install/upgrade failure

## Real flow

- 1. Upgrade Failed → Release Revision
- 2. Release Revision → Hooks
- 3. Release Revision → CRDs
- 4. Release Revision → API Error
- 5. Release Revision → helm status

## Handy commands

```bash
# Add or customize commands for Helm / Release Failed
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
