# Connection Pool Exhausted

## Purpose

App cannot get DB connection

## Real flow

- 1. DB Timeout → Connection Pool
- 2. Connection Pool → Max Connections
- 3. Connection Pool → App Pool
- 4. Connection Pool → DB Limit
- 5. Connection Pool → pg_stat_activity

## Handy commands

```bash
# Add or customize commands for Databases / Connection Pool Exhausted
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
