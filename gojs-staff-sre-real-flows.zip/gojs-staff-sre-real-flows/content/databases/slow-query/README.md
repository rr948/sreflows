# Slow Query

## Purpose

Query latency increases

## Real flow

- 1. Latency Alert → Query Plan
- 2. Query Plan → Index
- 3. Query Plan → Lock
- 4. Query Plan → Execution Plan
- 5. Query Plan → EXPLAIN

## Handy commands

```bash
# Add or customize commands for Databases / Slow Query
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
