# Latency Spike

## Purpose

p95/p99 latency increases for user path.

## Real flow

- 1. Latency Alert → Slow Endpoint / Span
- 2. Slow Endpoint / Span → Downstream Dependency
- 3. Slow Endpoint / Span → CPU / DB / Queue Saturation
- 4. Slow Endpoint / Span → Recent Deploy
- 5. Slow Endpoint / Span → Dashboard

## Handy commands

```bash
# Add or customize commands for Observability / Latency Spike
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
