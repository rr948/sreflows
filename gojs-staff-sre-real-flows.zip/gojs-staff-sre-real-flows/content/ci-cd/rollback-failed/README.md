# Rollback Failed

## Purpose

Rollback cannot restore service

## Real flow

- 1. Rollback Error → Rollback Step
- 2. Rollback Step → Previous Version
- 3. Rollback Step → DB Migration
- 4. Rollback Step → Config
- 5. Rollback Step → Deployment History

## Handy commands

```bash
# Add or customize commands for CI/CD / Rollback Failed
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
