# Credential Failure

## Purpose

Pipeline cannot access secret/repo

## Real flow

- 1. Auth Error → Credential ID
- 2. Credential ID → Scope
- 3. Credential ID → Plugin
- 4. Credential ID → Rotation
- 5. Credential ID → Console Log

## Handy commands

```bash
# Add or customize commands for Jenkins / Credential Failure
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
