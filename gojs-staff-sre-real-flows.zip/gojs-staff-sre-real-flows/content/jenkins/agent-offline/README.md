# Agent Offline

## Purpose

Build waiting for offline agent

## Real flow

- 1. Build Queued → Agent
- 2. Agent → Label
- 3. Agent → Connectivity
- 4. Agent → Executor
- 5. Agent → Agent Logs

## Handy commands

```bash
# Add or customize commands for Jenkins / Agent Offline
# Start with status → describe/inspect → logs/events → connectivity → rollback
```

## Staff SRE framing

Impact → scope → real component path → evidence → mitigation → prevention.
