# GoJS Staff SRE Real Flows

This version removes the repeated 6-box template.

## What changed

- Scenario-specific real flows
- Tool/issue-specific groups
- No generic repeated Issue → Focus → Dependency template
- Cleaner topology per issue
- 15 domains
- 33 scenarios

## Run

```bash
python -m http.server 8080
```
