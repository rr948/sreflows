let diagram;
let appData;
let selectedScenario;

const $ = id => document.getElementById(id);

async function init() {
  const res = await fetch("data/scenarios.json");
  appData = await res.json();
  initDiagram();
  renderTree();
  wire();
}

function wire(){
  $("menuToggle").onclick = () => document.body.classList.toggle("menu-collapsed");
  $("detailsToggle").onclick = () => $("details").classList.toggle("open");
  $("closeDetails").onclick = () => $("details").classList.remove("open");
  $("zoomFit").onclick = () => diagram.zoomToFit();
  $("expandGroups").onclick = () => diagram.commandHandler.expandSubGraph();
  $("collapseGroups").onclick = () => diagram.commandHandler.collapseSubGraph();
  $("clearHighlight").onclick = clearHighlight;
  $("searchBox").addEventListener("input", renderTree);
}

function initDiagram(){
  const $go = go.GraphObject.make;

  diagram = $go(go.Diagram, "myDiagramDiv", {
    "undoManager.isEnabled": true,
    "commandHandler.archetypeGroupData": { text: "New Group", isGroup: true, category: "group", groupType: "custom" },
    "draggingTool.dragsTree": false,
    "draggingTool.isGridSnapEnabled": true,
    "relinkingTool.isEnabled": true,
    "linkingTool.isEnabled": true,
    layout: $go(go.LayeredDigraphLayout, {
      direction: 0,
      layerSpacing: 55,
      columnSpacing: 35,
      setsPortSpots: false
    }),
    allowDrop: true,
    mouseDrop: e => finishDrop(e, null)
  });

  diagram.addDiagramListener("ChangedSelection", e => {
    const node = diagram.selection.first();
    if(node instanceof go.Node && !node.data.isGroup) {
      highlightRelated(node.data.key);
      loadReadme(node.data.readme, node.data.text);
    }
  });

  diagram.groupTemplate =
    $go(go.Group, "Auto",
      {
        background: "transparent",
        ungroupable: true,
        computesBoundsAfterDrag: true,
        handlesDragDropForMembers: true,
        mouseDrop: finishDrop,
        layout: $go(go.GridLayout, {
          wrappingColumn: 2,
          alignment: go.GridLayout.Position,
          spacing: new go.Size(20, 20)
        })
      },
      new go.Binding("isSubGraphExpanded", "expanded").makeTwoWay(),
      $go(go.Shape, "RoundedRectangle",
        {
          fill: "rgba(15,23,42,0.56)",
          stroke: "rgba(148,163,184,0.36)",
          strokeWidth: 1.4,
          parameter1: 18
        },
        new go.Binding("stroke", "groupType", groupStroke)
      ),
      $go(go.Panel, "Vertical",
        { margin: 12 },
        $go(go.Panel, "Horizontal",
          { stretch: go.GraphObject.Horizontal, margin: new go.Margin(0,0,10,0) },
          $("SubGraphExpanderButton", { margin: 4 }),
          $go(go.TextBlock,
            {
              font: "800 13px Inter, sans-serif",
              stroke: "#e5e7eb",
              margin: new go.Margin(0, 8),
              editable: true
            },
            new go.Binding("text").makeTwoWay()
          )
        ),
        $go(go.Placeholder, { padding: 14 })
      )
    );

  diagram.nodeTemplate =
    $go(go.Node, "Auto",
      {
        locationSpot: go.Spot.Center,
        selectionAdorned: true,
        mouseEnter: (e, obj) => highlightRelated(obj.part.data.key),
        mouseLeave: () => {},
        doubleClick: (e, obj) => loadReadme(obj.part.data.readme, obj.part.data.text)
      },
      new go.Binding("opacity", "dim", d => d ? 0.18 : 1),
      $go(go.Shape, "RoundedRectangle",
        {
          strokeWidth: 1.8,
          parameter1: 16,
          fill: "rgba(2,6,23,0.96)",
          stroke: "#334155",
          portId: "",
          fromLinkable: true,
          toLinkable: true,
          cursor: "pointer"
        },
        new go.Binding("fill", "role", roleFill),
        new go.Binding("stroke", "role", roleStroke),
        new go.Binding("strokeWidth", "highlight", h => h ? 4 : 1.8)
      ),
      $go(go.Panel, "Vertical",
        { margin: new go.Margin(12, 14), width: 150 },
        $go(go.TextBlock,
          {
            font: "900 11px Inter, sans-serif",
            stroke: "#7dd3fc",
            margin: new go.Margin(0,0,6,0)
          },
          new go.Binding("text", "role", r => (r || "component").toUpperCase())
        ),
        $go(go.TextBlock,
          {
            font: "800 14px Inter, sans-serif",
            stroke: "#e5e7eb",
            wrap: go.TextBlock.WrapFit,
            textAlign: "center",
            editable: true
          },
          new go.Binding("text").makeTwoWay()
        ),
        $go(go.TextBlock,
          {
            font: "12px Inter, sans-serif",
            stroke: "#94a3b8",
            wrap: go.TextBlock.WrapFit,
            textAlign: "center",
            margin: new go.Margin(8,0,0,0)
          },
          new go.Binding("text", "desc")
        )
      )
    );

  diagram.linkTemplate =
    $go(go.Link,
      {
        routing: go.Link.AvoidsNodes,
        curve: go.Link.JumpOver,
        corner: 10,
        relinkableFrom: true,
        relinkableTo: true,
        reshapable: true
      },
      new go.Binding("opacity", "dim", d => d ? 0.12 : 1),
      $go(go.Shape,
        { stroke: "rgba(148,163,184,0.55)", strokeWidth: 2.2 },
        new go.Binding("stroke", "highlight", h => h ? "#38bdf8" : "rgba(148,163,184,0.55)"),
        new go.Binding("strokeWidth", "highlight", h => h ? 4 : 2.2)
      ),
      $go(go.Shape,
        { toArrow: "Triangle", fill: "#38bdf8", stroke: null }
      ),
      $go(go.Panel, "Auto",
        $go(go.Shape, "RoundedRectangle",
          { fill: "#020617", stroke: "rgba(56,189,248,0.45)", parameter1: 8 }
        ),
        $go(go.TextBlock,
          {
            margin: new go.Margin(4, 7),
            stroke: "#e5e7eb",
            font: "800 10px Inter, sans-serif",
            editable: true
          },
          new go.Binding("text").makeTwoWay()
        )
      )
    );
}

function groupStroke(type){
  return {
    cluster: "#38bdf8",
    namespace: "#818cf8",
    workload: "#22c55e",
    pod: "#facc15",
    network: "#38bdf8",
    worker: "#22c55e",
    nodepool: "#818cf8",
    host: "#38bdf8",
    kernel: "#fb923c",
    process: "#22c55e",
    platform: "#38bdf8",
    workspace: "#818cf8",
    backend: "#22c55e",
    obs: "#38bdf8",
    signals: "#facc15",
    service: "#22c55e"
  }[type] || "rgba(148,163,184,0.36)";
}

function roleFill(role){
  return {
    symptom: "rgba(127,29,29,0.72)",
    focus: "rgba(8,47,73,0.96)",
    dependency: "rgba(20,83,45,0.78)",
    validation: "rgba(113,63,18,0.72)"
  }[role] || "rgba(2,6,23,0.96)";
}

function roleStroke(role){
  return {
    symptom: "#fb7185",
    focus: "#38bdf8",
    dependency: "#22c55e",
    validation: "#facc15"
  }[role] || "#334155";
}

function finishDrop(e, grp){
  const ok = grp !== null
    ? grp.addMembers(grp.diagram.selection, true)
    : e.diagram.commandHandler.addTopLevelParts(e.diagram.selection, true);
  if(!ok) e.diagram.currentTool.doCancel();
}

function renderTree(){
  const q = $("searchBox").value.toLowerCase().trim();
  $("tree").innerHTML = appData.domains.map(d => {
    const scenarios = d.scenarios.filter(s => !q || `${d.title} ${s.title} ${s.summary}`.toLowerCase().includes(q));
    if(q && !scenarios.length) return "";
    return `
      <div class="domain open">
        <button class="domain-btn" onclick="toggleDomain(this)">
          <span>${d.title}<div class="meta">${scenarios.length} scenarios</div></span>
          <span>›</span>
        </button>
        <div class="scenario-list">
          ${scenarios.map(s => `
            <button class="scenario-btn ${selectedScenario && selectedScenario.id === s.id ? "active" : ""}" onclick="selectScenario('${d.id}','${s.id}')">
              ${s.title}
            </button>
          `).join("")}
        </div>
      </div>
    `;
  }).join("");
}

function toggleDomain(btn){
  btn.closest(".domain").classList.toggle("open");
}

function selectScenario(domainId, scenarioId){
  const domain = appData.domains.find(d => d.id === domainId);
  const scenario = domain.scenarios.find(s => s.id === scenarioId);
  selectedScenario = scenario;

  $("crumb").textContent = `${domain.title} / ${scenario.title}`;
  $("scenarioTitle").textContent = scenario.title;
  $("scenarioSummary").textContent = scenario.summary;

  const nodeDataArray = scenario.nodes.map(n => ({ ...n, highlight: false, dim: false, expanded: true }));
  const linkDataArray = scenario.links.map((l, idx) => ({ ...l, key: idx + 1, highlight: false, dim: false }));

  diagram.model = new go.GraphLinksModel(nodeDataArray, linkDataArray);
  diagram.delayInitialization(() => diagram.zoomToFit());

  $("nodeCount").textContent = scenario.nodes.filter(n => !n.isGroup).length;
  $("groupCount").textContent = scenario.nodes.filter(n => n.isGroup).length;
  $("linkCount").textContent = scenario.links.length;

  renderRelationships(scenario);
  loadReadme(scenario.readme, scenario.title);
  renderTree();
}

function highlightRelated(key){
  if(!selectedScenario) return;
  const connected = new Set([key]);
  selectedScenario.links.forEach(l => {
    if(l.from === key) connected.add(l.to);
    if(l.to === key) connected.add(l.from);
  });

  diagram.startTransaction("highlight");
  diagram.nodes.each(n => {
    if(n.data.isGroup) return;
    diagram.model.setDataProperty(n.data, "highlight", connected.has(n.data.key));
    diagram.model.setDataProperty(n.data, "dim", !connected.has(n.data.key));
  });
  diagram.links.each(l => {
    const active = l.data.from === key || l.data.to === key;
    diagram.model.setDataProperty(l.data, "highlight", active);
    diagram.model.setDataProperty(l.data, "dim", !active);
  });
  diagram.commitTransaction("highlight");
}

function clearHighlight(){
  diagram.startTransaction("clear");
  diagram.nodes.each(n => {
    diagram.model.setDataProperty(n.data, "highlight", false);
    diagram.model.setDataProperty(n.data, "dim", false);
  });
  diagram.links.each(l => {
    diagram.model.setDataProperty(l.data, "highlight", false);
    diagram.model.setDataProperty(l.data, "dim", false);
  });
  diagram.commitTransaction("clear");
}

function renderRelationships(scenario){
  $("relationshipRows").innerHTML = scenario.links.map((l, idx) => {
    const from = scenario.nodes.find(n => n.key === l.from)?.text || l.from;
    const to = scenario.nodes.find(n => n.key === l.to)?.text || l.to;
    return `
      <div class="rel-row">
        <strong>${idx+1}. ${from} → ${to}</strong>
        <p>${l.text}</p>
      </div>
    `;
  }).join("");
}

async function loadReadme(path, title){
  $("details").classList.add("open");
  $("readmePath").textContent = path || "README.md";
  $("readmeTitle").textContent = title || "Runbook";
  if(!path) return;

  try{
    const res = await fetch(path);
    const md = await res.text();
    $("markdown").innerHTML = mdToHtml(md);
  }catch(e){
    $("markdown").innerHTML = `<h1>${title}</h1><p>README not found: <code>${path}</code></p>`;
  }
}

function mdToHtml(md){
  let html = md.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  html = html.replace(/```([\s\S]*?)```/g, (_,c)=>`<pre><code>${c.trim()}</code></pre>`);
  html = html.replace(/^### (.*)$/gm,"<h3>$1</h3>");
  html = html.replace(/^## (.*)$/gm,"<h2>$1</h2>");
  html = html.replace(/^# (.*)$/gm,"<h1>$1</h1>");
  html = html.replace(/`([^`]+)`/g,"<code>$1</code>");
  html = html.replace(/^- (.*)$/gm,"<li>$1</li>");
  html = html.replace(/(<li>.*<\/li>\n?)+/g,m=>`<ul>${m}</ul>`);
  html = html.replace(/\n\n/g,"</p><p>");
  return `<p>${html}</p>`.replace(/<p><h/g,"<h").replace(/<\/h([123])><\/p>/g,"</h$1>");
}

init();
