# Latency Spike

## Purpose

p95/p99 latency increases for a user-facing path.

## Incident flow

- Start from the symptom node.
- Move to the focus component.
- Inspect only connected dependencies.
- Use validation nodes only when they prove the failure.
- Avoid expanding unrelated infrastructure.

## Handy commands

```bash
curl -w '%{http_code} %{time_total}\n' -o /dev/null -s https://service
kubectl top pods -A
kubectl logs deploy/app --since=30m
```

## Relationship descriptions

The relationship numbers in the diagram match the relationship panel below the diagram.

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```
