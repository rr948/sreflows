# High CPU

## Purpose

Host or process CPU saturation.

## Incident flow

- Start from the symptom node.
- Move to the focus component.
- Inspect only connected dependencies.
- Use validation nodes only when they prove the failure.
- Avoid expanding unrelated infrastructure.

## Handy commands

```bash
uptime
top -H
ps -eo pid,ppid,stat,pcpu,pmem,cmd --sort=-pcpu | head
pidstat 1
perf top
```

## Relationship descriptions

The relationship numbers in the diagram match the relationship panel below the diagram.

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```
