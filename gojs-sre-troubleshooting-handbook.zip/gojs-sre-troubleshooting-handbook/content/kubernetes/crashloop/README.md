# CrashLoopBackOff

## Purpose

Pod repeatedly crashes after starting.

## Incident flow

- Start from the symptom node.
- Move to the focus component.
- Inspect only connected dependencies.
- Use validation nodes only when they prove the failure.
- Avoid expanding unrelated infrastructure.

## Handy commands

```bash
kubectl get pods -A
kubectl describe pod <pod> -n <ns>
kubectl logs <pod> -n <ns> --previous
kubectl get events -n <ns> --sort-by=.lastTimestamp
```

## Relationship descriptions

The relationship numbers in the diagram match the relationship panel below the diagram.

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```
