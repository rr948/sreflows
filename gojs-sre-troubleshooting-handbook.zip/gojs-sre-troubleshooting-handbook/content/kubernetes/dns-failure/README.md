# DNS Resolution Failure

## Purpose

Pod cannot resolve Kubernetes service or external DNS name.

## Incident flow

- Start from the symptom node.
- Move to the focus component.
- Inspect only connected dependencies.
- Use validation nodes only when they prove the failure.
- Avoid expanding unrelated infrastructure.

## Handy commands

```bash
kubectl -n kube-system logs deploy/coredns
kubectl get svc kube-dns -n kube-system
kubectl get netpol -A
kubectl run dns-test --rm -it --image=busybox -- nslookup kubernetes.default
```

## Relationship descriptions

The relationship numbers in the diagram match the relationship panel below the diagram.

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```
