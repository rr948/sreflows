# Node NotReady

## Purpose

Node condition is unhealthy or disconnected.

## Incident flow

- Start from the symptom node.
- Move to the focus component.
- Inspect only connected dependencies.
- Use validation nodes only when they prove the failure.
- Avoid expanding unrelated infrastructure.

## Handy commands

```bash
kubectl get nodes
kubectl describe node <node>
systemctl status kubelet
journalctl -u kubelet -n 200
crictl ps -a
```

## Relationship descriptions

The relationship numbers in the diagram match the relationship panel below the diagram.

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```
