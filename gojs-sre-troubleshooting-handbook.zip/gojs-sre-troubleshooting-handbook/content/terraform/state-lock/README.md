# Terraform State Lock Stuck

## Purpose

Remote backend lock blocks Terraform operations.

## Incident flow

- Start from the symptom node.
- Move to the focus component.
- Inspect only connected dependencies.
- Use validation nodes only when they prove the failure.
- Avoid expanding unrelated infrastructure.

## Handy commands

```bash
terraform plan
terraform state list
terraform force-unlock <lock-id>
aws dynamodb get-item --table-name <lock-table>
```

## Relationship descriptions

The relationship numbers in the diagram match the relationship panel below the diagram.

## Staff SRE answer format

```text
Impact → scope → focus component → connected dependency → evidence → mitigation → prevention
```
