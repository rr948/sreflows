# Staff SRE Troubleshooting Handbook

## Major design

This version is not a cluttered all-components diagram.

It uses:

- Left hierarchical menu: Domain → Area → Repeated Issue
- Focused diagram per selected issue
- Only required components in the diagram
- Active primary component and dependency lines
- Right-side README.md runbook rendering
- Search across repeated incidents
- Mobile-friendly responsive layout

## Run locally

Markdown files are loaded through `fetch()`, so use a local server:

```bash
cd staff-sre-troubleshooting-handbook
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Edit

- Tree and diagrams: `data/handbook.json`
- UI: `assets/css/base.css`
- Behavior: `assets/js/app.js`
- Runbooks: `content/<domain>/<scenario>/README.md`


## V2 Enhancements

- Each scenario now has a unique dependency graph.
- Parent hierarchy is visible in the diagram.
- Parent → child relationship chain added.
- Focus component positioned centrally.
- Supporting dependencies arranged dynamically.
- Active dependency paths glow visually.
- Better mental mapping for Staff SRE troubleshooting.


## V3 Enhancements

- Center diagram is now flexible instead of fixed-width/fixed-height positioned boxes.
- Diagram uses hierarchy grid layout: parent chain on top, focus in center, signals on right, causes/context around focus.
- Sidebar can collapse from the top Menu button.
- Unrelated diagram components are hidden instead of dimmed.
- SVG links are recalculated from actual DOM positions.
- Better parent → child → focus troubleshooting mental model.
