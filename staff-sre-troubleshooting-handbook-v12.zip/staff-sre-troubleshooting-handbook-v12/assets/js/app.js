const state = { data:null, selected:null, scale:1, openDomains:new Set(), openAreas:new Set(), query:"" };
const $ = id => document.getElementById(id);

async function init(){
  const res = await fetch("data/handbook.json");
  state.data = await res.json();
  renderStats();
  renderTree();
  wire();
}
function wire(){
  $("searchBox").addEventListener("input", e=>{state.query=e.target.value.toLowerCase().trim(); renderTree(); renderRelated();});
  $("sidebarToggle").onclick=()=>document.body.classList.toggle("sidebar-collapsed");
  $("collapseAllBtn").onclick=()=>{state.openDomains.clear(); state.openAreas.clear(); renderTree();};
  $("detailsBtn").onclick=()=>$("details").classList.toggle("open");
  $("closeDetails").onclick=()=>$("details").classList.remove("open");
  $("fitBtn").onclick=()=>setScale(.86);
  $("zoomInBtn").onclick=()=>setScale(state.scale+.1);
  $("zoomOutBtn").onclick=()=>setScale(Math.max(.55,state.scale-.1));
  $("resetBtn").onclick=()=>{ if(state.selected) selectScenario(state.selected.domainId,state.selected.areaId,state.selected.scenarioId,false); };
  $("showLabels").onchange=()=>{ if(state.selected) renderGraph(state.selected.scenario); };
}
function setScale(v){ state.scale=Number(v.toFixed(2)); $("stage").style.transform=`scale(${state.scale})`; }
function allScenarios(){
  return state.data.domains.flatMap(d=>d.areas.flatMap(a=>a.scenarios.map(s=>({domain:d,area:a,scenario:s}))));
}
function renderStats(){
  const domains=state.data.domains.length;
  const scenarios=allScenarios().length;
  const components=new Set(allScenarios().flatMap(x=>x.scenario.graph.nodes.map(n=>n.title))).size;
  $("domainCount").textContent=domains; $("scenarioCount").textContent=scenarios; $("componentCount").textContent=components;
}
function renderTree(){
  const q=state.query;
  $("tree").innerHTML = state.data.domains.map(d=>{
    const domainOpen = state.openDomains.has(d.id) || q;
    const areasHtml = d.areas.map(a=>{
      const matchingScenarios=a.scenarios.filter(s=>!q || `${d.title} ${a.title} ${s.title} ${s.summary}`.toLowerCase().includes(q));
      if(q && !matchingScenarios.length) return "";
      const areaKey=`${d.id}:${a.id}`;
      const areaOpen=state.openAreas.has(areaKey) || q;
      return `<div class="area ${areaOpen?'open':''}">
        <button class="area-btn ${isAreaSelected(d.id,a.id)?'active':''}" onclick="toggleArea('${d.id}','${a.id}')">
          <span><strong>${a.title}</strong><small>${matchingScenarios.length || a.scenarios.length} issues</small></span><span class="chev">›</span>
        </button>
        <div class="scenario-list">
          ${matchingScenarios.map(s=>`<button class="scenario-btn ${isSelected(s.id)?'active':''}" onclick="selectScenario('${d.id}','${a.id}','${s.id}',true)">
            ${s.title}
          </button>`).join("")}
        </div>
      </div>`;
    }).join("");
    if(q && !areasHtml.trim()) return "";
    return `<div class="tree-domain ${domainOpen?'open':''}">
      <button class="domain-btn ${isDomainSelected(d.id)?'active':''}" onclick="toggleDomain('${d.id}')">
        <span><strong>${d.title}</strong><span class="domain-meta">${d.areas.length} areas</span></span><span class="chev">›</span>
      </button>
      <div class="area-list">${areasHtml}</div>
    </div>`;
  }).join("");
}
function toggleDomain(id){ state.openDomains.has(id)?state.openDomains.delete(id):state.openDomains.add(id); renderTree(); }
function toggleArea(did,aid){ const k=`${did}:${aid}`; state.openAreas.has(k)?state.openAreas.delete(k):state.openAreas.add(k); state.openDomains.add(did); renderTree(); }
function findScenario(did,aid,sid){
  const d=state.data.domains.find(x=>x.id===did); const a=d.areas.find(x=>x.id===aid); const s=a.scenarios.find(x=>x.id===sid);
  return {domain:d,area:a,scenario:s};
}
function isSelected(sid){ return state.selected && state.selected.scenarioId===sid; }
function isDomainSelected(did){ return state.selected && state.selected.domainId===did; }
function isAreaSelected(did,aid){ return state.selected && state.selected.domainId===did && state.selected.areaId===aid; }

async function selectScenario(did,aid,sid,loadMd=true){
  const found=findScenario(did,aid,sid);
  state.selected={domainId:did,areaId:aid,scenarioId:sid, ...found};
  state.openDomains.add(did); state.openAreas.add(`${did}:${aid}`);
  $("emptyState").classList.add("hidden"); $("stage").classList.remove("hidden");
  $("crumb").textContent=`${found.domain.title} / ${found.area.title}`;
  $("pageTitle").textContent=found.scenario.title;
  $("pageSummary").textContent=found.scenario.summary;
  renderTree(); renderGraph(found.scenario); renderRelated();
  if(loadMd) await loadReadme(found.scenario.graph.readme, found.scenario.title);
}
function renderGraph(scenario){
  const graph=scenario.graph;
  const nodes=$("nodes"), links=$("links");
  nodes.innerHTML="";
  links.innerHTML="";
  links.style.display = "none";
  nodes.className = "nodes flow-board-mode";

  const flow = buildScenarioFlow(graph);
  const board = document.createElement("div");
  board.className = "flow-board";

  board.appendChild(renderFlowHeader(scenario, flow));
  board.appendChild(renderPrimaryFlow(graph, flow));
  board.appendChild(renderContextPanel(graph, flow));
  board.appendChild(renderActionPanel(graph, flow));

  nodes.appendChild(board);
}

function buildScenarioFlow(graph){
  const byId = Object.fromEntries(graph.nodes.map(n => [n.id, n]));
  const steps = [];

  const add = (id, reason, required=true) => {
    if(!byId[id]) return;
    if(steps.some(s => s.node.id === id)) return;
    steps.push({ node: byId[id], reason, required });
  };

  // Always start with symptom and focus.
  add("symptom", "Observed production symptom", true);
  add("focus", "Main suspected failing component", true);

  // Add only directly connected non-generic dependencies.
  graph.links.forEach(([a,b]) => {
    if(a.startsWith("parent-") || b.startsWith("parent-")) return;
    if(a === "focus" && !isGenericOptional(b)) add(b, "Direct dependency of the focus component", true);
    if(b === "focus" && !isGenericOptional(a)) add(a, "Direct dependency of the focus component", true);
  });

  // Optional validation components only when they are explicitly connected and useful.
  const optional = [];
  graph.links.forEach(([a,b]) => {
    if(a.startsWith("parent-") || b.startsWith("parent-")) return;
    for(const id of [a,b]){
      if(["metrics","logs-events","recent-change"].includes(id) && byId[id]){
        if(!optional.some(x => x.node.id === id)){
          optional.push({ node: byId[id], reason: optionalReason(id), required:false });
        }
      }
    }
  });

  const hierarchy = usefulHierarchy(graph, steps.map(s => s.node));
  return { steps, optional, hierarchy };
}

function isGenericOptional(id){
  // Hide worker/metrics/logs/recent-change unless specifically shown in optional validation section.
  return ["metrics","logs-events","recent-change","worker-node"].includes(id);
}

function optionalReason(id){
  if(id === "metrics") return "Use only when metrics are available or impact must be quantified";
  if(id === "logs-events") return "Use only when logs/events can prove the failure mode";
  if(id === "recent-change") return "Use only when a deployment/config/infra change happened recently";
  return "Optional validation";
}

function usefulHierarchy(graph, visibleNodes){
  const boxes = graph.hierarchyBoxes || [];
  const containers = new Set(visibleNodes.map(n => n.container).filter(Boolean));
  return boxes.filter(b => containers.has(b.id) || b.level === 0);
}

function renderFlowHeader(scenario, flow){
  const el = document.createElement("section");
  el.className = "flow-top";
  el.innerHTML = `
    <div>
      <span class="badge">Incident flow</span>
      <h2>${scenario.title}</h2>
      <p>${scenario.summary}</p>
    </div>
    <div class="flow-summary">
      <div><strong>${flow.steps.length}</strong><span>required boxes</span></div>
      <div><strong>${flow.optional.length}</strong><span>optional checks</span></div>
      <div><strong>${flow.hierarchy.length}</strong><span>parent layers</span></div>
    </div>
  `;
  return el;
}

function renderPrimaryFlow(graph, flow){
  const el = document.createElement("section");
  el.className = "primary-flow";
  el.innerHTML = `
    <div class="flow-section-title">
      <span>Required connected path</span>
      <small>Only boxes required for this issue</small>
    </div>
    <div class="flow-steps">
      ${flow.steps.map((s, idx) => flowStepHtml(s.node, idx+1, s.reason, idx === 1)).join("")}
    </div>
  `;
  return el;
}

function flowStepHtml(n, step, reason, isFocus){
  return `
    <button class="flow-step ${isFocus ? "focus-step" : ""} type-${n.type || "platform"}" onclick="selectFlowCard('${n.id}')">
      <span class="step-num">${step}</span>
      <span class="step-chip">${n.type || "component"}</span>
      <strong>${n.title}</strong>
      <p>${reason}</p>
    </button>
  `;
}

function renderContextPanel(graph, flow){
  const el = document.createElement("section");
  el.className = "context-layout";

  const hierarchy = flow.hierarchy.filter(h => h.level <= 3);
  const optional = flow.optional;

  el.innerHTML = `
    <div class="hierarchy-panel">
      <div class="flow-section-title">
        <span>Parent hierarchy</span>
        <small>Context only, not clutter</small>
      </div>
      <div class="hierarchy-stack">
        ${hierarchy.map((h, i) => `
          <div class="hierarchy-pill level-${h.level}">
            <span>${i+1}</span>
            <strong>${h.title}</strong>
          </div>
        `).join("")}
      </div>
    </div>

    <div class="optional-panel">
      <div class="flow-section-title">
        <span>Show only when required</span>
        <small>metrics/logs/change checks</small>
      </div>
      <div class="optional-checks">
        ${optional.length ? optional.map((o, idx) => `
          <button class="optional-card type-${o.node.type || "external"}" onclick="selectFlowCard('${o.node.id}')">
            <span class="step-chip">${o.node.type || "check"}</span>
            <strong>${o.node.title}</strong>
            <p>${o.reason}</p>
          </button>
        `).join("") : `<div class="empty-note">No optional checks required for this scenario.</div>`}
      </div>
    </div>
  `;
  return el;
}

function renderActionPanel(graph, flow){
  const el = document.createElement("section");
  el.className = "action-panel";
  const focus = graph.nodes.find(n => n.id === "focus");
  el.innerHTML = `
    <div class="flow-section-title">
      <span>Staff SRE action path</span>
      <small>how to use this flow</small>
    </div>
    <div class="action-grid">
      <div class="action-card"><span>1</span><strong>Scope</strong><p>Confirm blast radius: app, namespace, node, zone, region, or global.</p></div>
      <div class="action-card"><span>2</span><strong>Inspect ${focus ? focus.title : "focus"}</strong><p>Start with the central component instead of browsing unrelated infrastructure.</p></div>
      <div class="action-card"><span>3</span><strong>Validate</strong><p>Open optional checks only if metrics, logs, events, or change history are needed.</p></div>
      <div class="action-card"><span>4</span><strong>Prevent</strong><p>Add alert, runbook, guardrail, dashboard, or automation after mitigation.</p></div>
    </div>
  `;
  return el;
}

function selectFlowCard(id){
  document.querySelectorAll(".flow-step,.optional-card").forEach(x => x.classList.remove("selected"));
  document.querySelectorAll(`[onclick="selectFlowCard('${id}')"]`).forEach(x => x.classList.add("selected"));
  if(state.selected){
    loadReadme(state.selected.scenario.graph.readme,state.selected.scenario.title);
  }
}

function isConnectedToFocus(graph,id){ return graph.links.some(([a,b])=>(a==="focus"&&b===id)||(b==="focus"&&a===id)); }
function addGroup(x,y,w,h,title){
  const el=document.createElement("div"); el.className="cluster-title";
  el.style.left=x+"px"; el.style.top=y+"px"; el.style.width=w+"px"; el.style.height=h+"px";
  el.innerHTML=`<span>${title}</span>`; $("nodes").appendChild(el);
}
function addDomLink(aEl,bEl,cls){
  const svg=$("links");
  const stage=$("stage").getBoundingClientRect();
  const a=aEl.getBoundingClientRect();
  const b=bEl.getBoundingClientRect();

  const x1=a.left-stage.left+a.width/2;
  const y1=a.top-stage.top+a.height/2;
  const x2=b.left-stage.left+b.width/2;
  const y2=b.top-stage.top+b.height/2;

  const dx = Math.abs(x2-x1);
  const dy = Math.abs(y2-y1);
  const horizontal = dx >= dy;

  let d;
  if(horizontal){
    const mid=Math.max(40,dx/2);
    d=`M ${x1} ${y1} C ${x1+mid} ${y1}, ${x2-mid} ${y2}, ${x2} ${y2}`;
  } else {
    const mid=Math.max(34,dy/2);
    d=`M ${x1} ${y1} C ${x1} ${y1+mid}, ${x2} ${y2-mid}, ${x2} ${y2}`;
  }

  const path=document.createElementNS("http://www.w3.org/2000/svg","path");
  path.setAttribute("d",d);
  path.setAttribute("marker-end","url(#arrow)");
  path.setAttribute("class",`link ${cls}`);
  svg.appendChild(path);
}

async function loadReadme(path,title){
  $("details").classList.add("open");
  $("readmeBadge").textContent=path; $("readmeTitle").textContent=title;
  $("markdown").innerHTML=`<p>Loading <code>${path}</code>...</p>`;
  try{
    const res=await fetch(path); if(!res.ok) throw new Error("missing");
    $("markdown").innerHTML=mdToHtml(await res.text());
  }catch(e){ $("markdown").innerHTML=`<h1>${title}</h1><p>README not found: <code>${path}</code></p>`; }
}
function renderRelated(){
  const q=state.query;
  let items = allScenarios();
  if(state.selected) items = items.filter(x=>x.domain.id===state.selected.domainId && x.scenario.id!==state.selected.scenarioId);
  if(q) items = items.filter(x=>`${x.domain.title} ${x.area.title} ${x.scenario.title} ${x.scenario.summary}`.toLowerCase().includes(q));
  $("relatedScenarios").innerHTML = items.slice(0,8).map(x=>`<div class="scenario-card" onclick="selectScenario('${x.domain.id}','${x.area.id}','${x.scenario.id}',true)">
    <span class="badge">${x.domain.title}</span><h3>${x.scenario.title}</h3><p>${x.scenario.summary}</p>
  </div>`).join("");
}
function mdToHtml(md){
  let html=md.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  html=html.replace(/```([\s\S]*?)```/g,(_,c)=>`<pre><code>${c.trim()}</code></pre>`);
  html=html.replace(/^### (.*)$/gm,"<h3>$1</h3>").replace(/^## (.*)$/gm,"<h2>$1</h2>").replace(/^# (.*)$/gm,"<h1>$1</h1>");
  html=html.replace(/`([^`]+)`/g,"<code>$1</code>");
  html=html.replace(/^- (.*)$/gm,"<li>$1</li>").replace(/(<li>.*<\/li>\n?)+/g,m=>`<ul>${m}</ul>`);
  html=html.replace(/\n\n/g,"</p><p>");
  return `<p>${html}</p>`.replace(/<p><h/g,"<h").replace(/<\/h([123])><\/p>/g,"</h$1>");
}

window.addEventListener("resize", ()=>{
  if(state.selected) renderGraph(state.selected.scenario);
});
document.querySelector(".focus-shell")?.addEventListener("scroll", ()=>{
  if(state.selected) {
    const graph = state.selected.scenario.graph;
    const visibleIds = getVisibleIds(graph);
    const visibleNodes = graph.nodes.filter(n => visibleIds.has(n.id) && !n.id.startsWith("parent-"));
    renderInDiagramArrows(graph, visibleNodes);
  }
});
init();

