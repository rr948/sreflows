# Staff SRE Troubleshooting Handbook

## Major design

This version is not a cluttered all-components diagram.

It uses:

- Left hierarchical menu: Domain → Area → Repeated Issue
- Focused diagram per selected issue
- Only required components in the diagram
- Active primary component and dependency lines
- Right-side README.md runbook rendering
- Search across repeated incidents
- Mobile-friendly responsive layout

## Run locally

Markdown files are loaded through `fetch()`, so use a local server:

```bash
cd staff-sre-troubleshooting-handbook
python -m http.server 8080
```

Open:

```text
http://localhost:8080
```

## Edit

- Tree and diagrams: `data/handbook.json`
- UI: `assets/css/base.css`
- Behavior: `assets/js/app.js`
- Runbooks: `content/<domain>/<scenario>/README.md`


## V2 Enhancements

- Each scenario now has a unique dependency graph.
- Parent hierarchy is visible in the diagram.
- Parent → child relationship chain added.
- Focus component positioned centrally.
- Supporting dependencies arranged dynamically.
- Active dependency paths glow visually.
- Better mental mapping for Staff SRE troubleshooting.


## V3 Enhancements

- Center diagram is now flexible instead of fixed-width/fixed-height positioned boxes.
- Diagram uses hierarchy grid layout: parent chain on top, focus in center, signals on right, causes/context around focus.
- Sidebar can collapse from the top Menu button.
- Unrelated diagram components are hidden instead of dimmed.
- SVG links are recalculated from actual DOM positions.
- Better parent → child → focus troubleshooting mental model.


## V4 Enhancements

- Added visual hierarchy boxes inside the diagram.
- Kubernetes scenarios now show nested containers such as:
  - Kubernetes Cluster
  - Namespace
  - Workload Controller
  - Pod / Container
  - Worker Node
  - Traffic Path
  - Service Discovery
  - Pod Network / CNI
  - Storage Layer
- Abstract parent nodes are no longer shown as cluttered boxes; parent hierarchy is shown as nested containers.
- Focus and related components appear inside the right hierarchy container.
- Unrelated components remain hidden.


## V5 Fixes

- Fixed broken diagram rendering from V4.
- Component cards are clickable again.
- Replaced fixed equal-size boxes with flexible nested hierarchy containers.
- Topic/component cards now have variable size:
  - focus cards are larger
  - related cards are medium
  - signal/context cards are smaller
- Diagrams render as clean nested boxes rather than cluttered absolute-position layouts.
- Links are recalculated from rendered card positions.


## V7 Repair

- Removed fragile SVG overlay from the main rendering path.
- Diagram now always renders using safe HTML hierarchy boxes.
- Cards are clickable.
- Numbered relationships are shown as reliable HTML flow arrows.
- Arrow meanings are shown in a numbered legend.
- This version prioritizes stable rendering and usability.


## V8 Enhancements

- Arrows are shown inside the same diagram again.
- Numbered arrow bubbles are displayed directly on the diagram.
- Detailed arrow descriptions moved into each scenario README.md.
- Removed the large external arrow legend from the page to keep the UI clean.


## V9 Fixes

- Diagram now renders only cards that participate in arrow relationships.
- Empty/unconnected hierarchy boxes are hidden.
- Arrow descriptions in README files are rewritten as simple Markdown bullets for reliable rendering.


## V10 Fix

- Empty pod/container hierarchy boxes are now removed completely.
- Hierarchy visibility is now recursive and strict:
  - show only boxes with connected cards
  - or parents of boxes with connected cards
- Unused pod/container shells are pruned after rendering.


## V11 Change

- Removed SVG from diagrams.
- Diagram connections are now pure HTML/CSS connector rows.
- Connector rows are clickable and highlight the connected cards.
- This avoids SVG rendering issues while keeping numbered arrows and readable flow.


## V12 UI Redesign

- Replaced diagram/arrows with an Incident Flow Board.
- Shows only required connected steps.
- Worker nodes, metrics, logs, and recent-change boxes are hidden unless the scenario needs them.
- Parent hierarchy is shown as compact context pills, not cluttered boxes.
- Optional checks are separated from the required troubleshooting path.
- No floating arrows, no SVG, no disconnected subcomponents.
